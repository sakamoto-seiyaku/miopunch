<h1 align="center">p2panda-core</h1>

<div align="center">
  <img src="https://raw.githubusercontent.com/p2panda/.github/main/assets/panda-left.gif" width="auto" height="30px">
  <strong>Extensible, secure and distributed data-types</strong>
  <img src="https://raw.githubusercontent.com/p2panda/.github/main/assets/panda-right.gif" width="auto" height="30px">
</div>

<div align="center">
  <h3>
    <a href="https://docs.rs/p2panda-core">
      Documentation
    </a>
    <span> | </span>
    <a href="https://github.com/p2panda/p2panda/releases">
      Releases
    </a>
    <span> | </span>
    <a href="https://p2panda.org">
      Website
    </a>
  </h3>
</div>

Highly extensible data-types of the p2panda protocol for secure, distributed and efficient exchange
of data, supporting networks from the internet to packet radio, LoRa or BLE.

The primary data structure is an append-only log implementation which supports history deletion,
multi-writer causal-ordering, fork-tolerance, compatibility with any CRDT and is extensible
depending on your application requirements.

> 🚧 This library is under active development and the APIs are not yet considered stable for
> production use. Core data types and user-facing APIs may still undergo breaking changes. Stability
> guarantees will improve with the release of v1.0.0.

## Features

- Cryptographic signatures for authorship verification and tamper-proof messages
- Authors can maintain one or many logs
- Single-writer logs which can be combined to support multi-writer collaboration
- Compatible with any application data and CRDT
- Compatible with any networking scenario (for example packet radio or mesh-networks)
- Fork-tolerant
- Off-chain handling of payloads, can be deleted independently of log structure
- Pruning of outdated messages
- Highly extensible with custom features, for example prefix-deletion, ephemeral "self-destructing"
  messages, etc.

## Examples

### Create and sign operation

```rust
use p2panda_core::{Header, SigningKey};

let signing_key = SigningKey::generate();

let header = Header::builder()
    .body(b"Hello, Panda!")
    .build(&signing_key, ());
```

### Custom extensions

Custom functionality can be added using extensions, for example, access-control tokens,
self-destructing messages, or key-agreement schemes for group encryption.

```rust
use p2panda_core::{Header, SigningKey};
use serde::{Serialize, Deserialize};

// Extend our operations with an "expiry" field we can use to implement
// "ephemeral messages" in our application, which get automatically deleted
// after the expiration timestamp is due.
#[derive(Clone, Debug, Default, Hash, Eq, PartialEq, Serialize, Deserialize)]
pub struct Expiry(u64);

// Multiple extensions can be combined in a custom type.
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
struct CustomExtensions {
    expiry: Expiry,
}

let signing_key = SigningKey::generate();

let header = Header::builder()
    .body(b"Hello, Panda!")
    .build(&signing_key, CustomExtensions {
        expiry: Expiry(1787246716),
    });
```

## License

Licensed under either of [Apache License, Version 2.0] or [MIT license] at your option.

Unless you explicitly state otherwise, any contribution intentionally submitted for inclusion in
p2panda by you, as defined in the Apache-2.0 license, shall be dual licensed as above, without any
additional terms or conditions.

[Apache License, Version 2.0]: https://github.com/p2panda/p2panda/blob/main/LICENSES/Apache-2.0.txt
[MIT license]: https://github.com/p2panda/p2panda/blob/main/LICENSES/MIT.txt

---

_This project has received funding from the European Union’s Horizon 2020 research and innovation
programme within the framework of the NGI-POINTER Project funded under grant agreement No 871528,
NGI-ASSURE No 957073, NGI0-ENTRUST No 101069594 and NGI0-COMMONS No 101135429._

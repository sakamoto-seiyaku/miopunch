# Changelog

All notable changes to iroh-relay will be documented in this file.

## [1.2.0](https://github.com/n0-computer/iroh/compare/v1.1.0..1.2.0) - 2026-09-09

### ⛰️  Features

- Switch to n0-dns-resolver and make fallback nameservers configurable ([#4419](https://github.com/n0-computer/iroh/issues/4419)) - ([1a68838](https://github.com/n0-computer/iroh/commit/1a68838b34c6c4646ada9fafaf65b29f9577a446))

### ⚙️ Miscellaneous Tasks

- *(*)* Upgrade to `noq`, `noq-proto`, `noq-udp` v1.3.0 ([#4518](https://github.com/n0-computer/iroh/issues/4518)) - ([cb5d12b](https://github.com/n0-computer/iroh/commit/cb5d12b5019966819f0e6eba23233885cd65cf7b))

# Changelog

All notable changes to iroh-relay will be documented in this file.

## [1.1.0](https://github.com/n0-computer/iroh/compare/v1.0.3..1.1.0) - 2026-08-25

### ⛰️  Features

- *(iroh-relay, iroh)* Inform clients when they are rate-limited and warn log in iroh ([#4455](https://github.com/n0-computer/iroh/issues/4455)) - ([e68dbda](https://github.com/n0-computer/iroh/commit/e68dbda9ada25da61a2bcdff5eb12b9bc8e0ba1e))

### ⚙️ Miscellaneous Tasks

- *(*)* Update `noq` and `net-tools` dependencies ([#4487](https://github.com/n0-computer/iroh/issues/4487)) - ([1960e73](https://github.com/n0-computer/iroh/commit/1960e73f1494eb53a730f2dc408f91e599f620e7))

# Changelog

All notable changes to iroh-relay will be documented in this file.

## [1.0.3](https://github.com/n0-computer/iroh/compare/v1.0.2..1.0.3) - 2026-07-20

### 🐛 Bug Fixes

- Remove vergen use from build.rs files ([#4426](https://github.com/n0-computer/iroh/issues/4426)) - ([1795b93](https://github.com/n0-computer/iroh/commit/1795b9363c68820661fd06cf679d94561ec66c0c))

### 📚 Documentation

- *(iroh-relay)* System deps and build command ([#4385](https://github.com/n0-computer/iroh/issues/4385)) - ([403af3c](https://github.com/n0-computer/iroh/commit/403af3c9ed8eeda07f72a4ac4617d67ca053ccb7))

### ⚙️ Miscellaneous Tasks

- Fixes for clippy from rust 1.97 ([#4404](https://github.com/n0-computer/iroh/issues/4404)) - ([8b097b2](https://github.com/n0-computer/iroh/commit/8b097b24880581bc0bd348ac9965fa05e84428c9))
- Bump cfg_aliases ([#4422](https://github.com/n0-computer/iroh/issues/4422)) - ([4e0a820](https://github.com/n0-computer/iroh/commit/4e0a820d07f9edd7f32caf352dbf82c0a17d4c42))
- Update to `noq` 1.1.0 - ([e84fe96](https://github.com/n0-computer/iroh/commit/e84fe96ddeb75ef5e408f06c14edde513f2b6be8))

# Changelog

All notable changes to iroh-relay will be documented in this file.

## [1.0.2](https://github.com/n0-computer/iroh/compare/v1.0.1..1.0.2) - 2026-07-06

### ⛰️  Features

- *(relay)* Allow updating the per-client rate limit live ([#4381](https://github.com/n0-computer/iroh/issues/4381)) - ([c23446c](https://github.com/n0-computer/iroh/commit/c23446ce2ee2bf3a25121483c61d938645c2bcd0))

### 🐛 Bug Fixes

- *(iroh-relay)* Improve relay protocol proptests & properly handle invalid messages ([#4389](https://github.com/n0-computer/iroh/issues/4389)) - ([22cac74](https://github.com/n0-computer/iroh/commit/22cac742ca5e84da4542681e14b2d23b74c8330e))

### ⚙️ Miscellaneous Tasks

- *(*)* Add release configuration for generating the changelog - ([ead46e5](https://github.com/n0-computer/iroh/commit/ead46e50823e7ddcc4d142ea71511ed38a37260e))



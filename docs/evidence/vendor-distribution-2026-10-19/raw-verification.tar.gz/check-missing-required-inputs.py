import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

R = Path('/home/js/Git/miopunch')
H = Path('/tmp/miopunch-m105-20261019')
O = H / 'missing-required-inputs'
O.mkdir()
rows = []
cases = {'lock': 'Cargo.lock', 'manifest': 'Cargo.toml', 'configuration': '.cargo/config.toml',
         'library-source': 'vendor/iroh/src/lib.rs', 'build-script': 'vendor/iroh/build.rs'}
for optimized in [False, True]:
    for name, missing in cases.items():
        fixture = O / (('optimized-' if optimized else '') + name)
        fixture.mkdir()
        for directory in ['scripts', '.cargo', 'src', 'vendor/iroh/src', 'vendor/iroh-relay/src', 'bin']:
            (fixture / directory).mkdir(parents=True, exist_ok=True)
        for script in ['build_vendor_cdylib.py', 'cargo_cache.py']:
            shutil.copy2(R / 'scripts' / script, fixture / 'scripts' / script)
        (fixture / 'Cargo.toml').write_text('[package]\nname="mandatory-input-fixture"\nversion="0.0.0"\nedition="2024"\n')
        (fixture / 'Cargo.lock').write_text('version = 4\n[[package]]\nname = "mandatory-input-fixture"\nversion = "0.0.0"\n')
        (fixture / '.cargo/config.toml').write_text('[profile.dev]\ndebug = "line-tables-only"\nincremental = false\n')
        (fixture / 'src/lib.rs').write_text('// miniature source; never compiled\n')
        for package in ['iroh', 'iroh-relay']:
            (fixture / 'vendor' / package / 'Cargo.toml').write_text(
                '[package]\nname="' + package + '"\nversion="1.2.0"\nbuild="build.rs"\n'
                '[lib]\ncrate-type=["lib"]\npath="src/lib.rs"\n')
            (fixture / 'vendor' / package / 'src/lib.rs').write_text('// miniature source; never compiled\n')
            (fixture / 'vendor' / package / 'build.rs').write_text('fn main() {}\n')
        (fixture / missing).unlink()
        marker = fixture / 'cargo-was-invoked'
        fake = fixture / 'bin/cargo'
        fake.write_text('#!/usr/bin/env python3\nfrom pathlib import Path\nPath(' + repr(str(marker)) + ').write_text("unexpected Cargo invocation")\nraise SystemExit(93)\n')
        fake.chmod(0o755)
        env = os.environ.copy()
        env['PATH'] = str(fixture / 'bin') + os.pathsep + env['PATH']
        command = ['rtk', 'proxy', 'python3'] + (['-O'] if optimized else []) + [
            str(fixture / 'scripts/build_vendor_cdylib.py'), 'prepare', '--package', 'iroh',
            '--output', str(fixture / 'output')]
        result = subprocess.run(command, cwd=fixture, env=env, capture_output=True, text=True)
        (fixture / 'stdout.log').write_text(result.stdout)
        (fixture / 'stderr.log').write_text(result.stderr)
        assert result.returncode != 0 and 'required build input missing:' in result.stderr
        assert missing in result.stderr and not marker.exists() and not (fixture / 'output/context.json').exists()
        rows.append({'case': name, 'missingBeforePrepare': missing, 'optimizedPython': optimized,
                     'exit': result.returncode, 'refusedBeforeCargo': True, 'noContextCreated': True,
                     'fixtureOnly': True})
(H / 'missing-required-input-negatives.json').write_text(json.dumps({
    'builderSha256': hashlib.sha256((R / 'scripts/build_vendor_cdylib.py').read_bytes()).hexdigest(),
    'noRepositoryInputDeleted': True, 'cargoInvocationMarkerAbsentForAllCases': True,
    'cases': rows}, indent=2) + '\n')
print(json.dumps({'missingBeforePrepareNegatives': len(rows), 'normalAndOptimizedPython': True,
                  'noCargoInvoked': True, 'noRepositoryInputDeleted': True}))

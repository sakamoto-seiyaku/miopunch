import subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m98-20261019')
plans=[('ordinary-default-green', ['build', '--locked', '--offline', '--manifest-path', '/tmp/miopunch-m98-20261019/current-default/Cargo.toml', '--bin', 'm98-ordinary-default-consumer', '--jobs', '2']), ('ordinary-no-portmapper-green', ['build', '--locked', '--offline', '--manifest-path', '/tmp/miopunch-m98-20261019/current-no-portmapper/Cargo.toml', '--bin', 'm98-ordinary-default-consumer', '--jobs', '2']), ('gateway-product-tests', ['test', '--locked', '--offline', '--manifest-path', '/tmp/miopunch-m98-20261019/gateway-selector/Cargo.toml', '--test', 'udp_portmap', '--test', 'tcp_portmap', '--no-run', '--jobs', '2'])]
for name,cmd in plans:
 for phase,args in [('prepare',cmd),('run',[])]:
  r=subprocess.run(['rtk','proxy','python3',str(H/'build.py'),phase,name,*args]);assert r.returncode==0,(name,phase)
print('M98 ordinary feature variants and product gateway builds complete',flush=True)

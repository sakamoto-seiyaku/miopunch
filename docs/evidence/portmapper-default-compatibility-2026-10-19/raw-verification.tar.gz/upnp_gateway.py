import http.server,json,select,socket,subprocess,threading,xml.etree.ElementTree as ET
from pathlib import Path
SERVICE='urn:schemas-upnp-org:service:WANIPConnection:1'
ROOT=('<?xml version="1.0"?><root xmlns="urn:schemas-upnp-org:device-1-0"><specVersion><major>1</major><minor>0</minor></specVersion><device><deviceType>urn:schemas-upnp-org:device:InternetGatewayDevice:1</deviceType><friendlyName>Owned M98 gateway</friendlyName><manufacturer>miopunch test</manufacturer><modelName>M98</modelName><UDN>uuid:owned-m98</UDN><serviceList><service><serviceType>'+SERVICE+'</serviceType><serviceId>urn:upnp-org:serviceId:WANIPConn1</serviceId><SCPDURL>/wanip.xml</SCPDURL><controlURL>/control</controlURL><eventSubURL>/events</eventSubURL></service></serviceList></device></root>')
PARAMS=['NewRemoteHost','NewExternalPort','NewProtocol','NewInternalPort','NewInternalClient','NewEnabled','NewPortMappingDescription','NewLeaseDuration']
def schema():
 actions=[]
 for name,params in [('AddAnyPortMapping',PARAMS),('AddPortMapping',PARAMS),('DeletePortMapping',['NewRemoteHost','NewExternalPort','NewProtocol']),('GetExternalIPAddress',[])]:
  arguments=''.join('<argument><name>'+p+'</name><direction>in</direction><relatedStateVariable>'+p+'</relatedStateVariable></argument>' for p in params)
  actions.append('<action><name>'+name+'</name><argumentList>'+arguments+'</argumentList></action>')
 return '<?xml version="1.0"?><scpd xmlns="urn:schemas-upnp-org:service-1-0"><specVersion><major>1</major><minor>0</minor></specVersion><actionList>'+''.join(actions)+'</actionList><serviceStateTable/></scpd>'
def start(directory):
 directory=Path(directory);log=(directory/'upnp.jsonl').open('a',buffering=1);lock=threading.Lock();active={};stop=threading.Event()
 def record(value):
  with lock:log.write(json.dumps(dict(protocol='UPnP',**value))+'\n')
 def rule(action,ip,internal,external,protocol):
  for table,args in [('nat',['PREROUTING','-i','wan0','-p',protocol.lower(),'--dport',str(external),'-j','DNAT','--to-destination',f'{ip}:{internal}']), (None,['FORWARD','-i','wan0','-o','lan0','-p',protocol.lower(),'-d',ip,'--dport',str(internal),'-j','ACCEPT'])]:
   cmd=['iptables']+(['-t',table] if table else [])+[action]+args;subprocess.run(cmd,check=True)
 class Handler(http.server.BaseHTTPRequestHandler):
  def log_message(self,*args):pass
  def reply(self,text):
   data=text.encode();self.send_response(200);self.send_header('Content-Type','text/xml; charset="utf-8"');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
  def do_GET(self):
   assert self.path in ['/root.xml','/wanip.xml'],self.path
   record({'httpGet':self.path,'source':self.client_address[0]});self.reply(ROOT if self.path=='/root.xml' else schema())
  def do_POST(self):
   body=self.rfile.read(int(self.headers['Content-Length']));action=self.headers['SOAPAction'].strip('"').split('#')[-1]
   values={el.tag.split('}')[-1]:el.text or '' for el in ET.fromstring(body).iter() if not list(el)}
   event={'action':action,'source':self.client_address[0],'arguments':values};payload=''
   if action=='GetExternalIPAddress':payload='<NewExternalIPAddress>100.64.39.1</NewExternalIPAddress>'
   elif action in ['AddAnyPortMapping','AddPortMapping']:
    protocol=values['NewProtocol'];ip=values['NewInternalClient'];internal=int(values['NewInternalPort']);external=41039
    assert protocol in ['UDP','TCP'] and ip==self.client_address[0]=='10.39.0.2' and internal>0
    key=(protocol,external)
    if key not in active:rule('-A',ip,internal,external,protocol)
    else:assert active[key]==(ip,internal),'foreign allocation collision'
    active[key]=(ip,internal);event.update(internal_port=internal,external_port=external,requested_lifetime=int(values['NewLeaseDuration']),granted_lifetime=int(values['NewLeaseDuration']),owner=[ip,internal])
    if action=='AddAnyPortMapping':payload='<NewReservedPort>41039</NewReservedPort>'
   elif action=='DeletePortMapping':
    protocol=values['NewProtocol'];external=int(values['NewExternalPort']);key=(protocol,external)
    assert key in active and active[key][0]==self.client_address[0],'delete of another owner refused'
    ip,internal=active.pop(key);rule('-D',ip,internal,external,protocol);event.update(requested_lifetime=0,released=[ip,internal],external_port=external)
   else:raise AssertionError(action)
   record(event);self.reply('<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Body><u:'+action+'Response xmlns:u="'+SERVICE+'">'+payload+'</u:'+action+'Response></s:Body></s:Envelope>')
 http_service=http.server.HTTPServer(('10.39.0.1',5000),Handler);thread=threading.Thread(target=http_service.serve_forever);thread.start()
 ssdp=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);ssdp.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);ssdp.bind(('0.0.0.0',1900));ssdp.setsockopt(socket.IPPROTO_IP,socket.IP_ADD_MEMBERSHIP,socket.inet_aton('239.255.255.250')+socket.inet_aton('10.39.0.1'))
 def discover():
  while not stop.is_set():
   if not select.select([ssdp],[],[],.05)[0]:continue
   packet,source=ssdp.recvfrom(4096);assert source[0]=='10.39.0.2'
   record({'ssdpSearch':packet.decode(),'source':source[0]})
   response='HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=120\r\nLOCATION: http://10.39.0.1:5000/root.xml\r\nSERVER: OwnedM98/1 UPnP/1.0\r\nST: urn:schemas-upnp-org:device:InternetGatewayDevice:1\r\nUSN: uuid:owned-m98::urn:schemas-upnp-org:device:InternetGatewayDevice:1\r\n\r\n'
   ssdp.sendto(response.encode(),source)
 discovery=threading.Thread(target=discover);discovery.start();record({'upnp_started':True})
 def close():
  stop.set();discovery.join(timeout=2);assert not discovery.is_alive();ssdp.close();http_service.shutdown();thread.join(timeout=2);assert not thread.is_alive();http_service.server_close()
  for (protocol,external),(ip,internal) in list(active.items()):rule('-D',ip,internal,external,protocol);record({'administrativeDeleteOnGatewayStop':True,'owner':[ip,internal],'external_port':external})
  log.close()
 return close

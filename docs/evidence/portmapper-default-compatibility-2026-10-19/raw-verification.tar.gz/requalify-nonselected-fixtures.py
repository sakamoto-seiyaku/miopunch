import hashlib,importlib.util,json,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m98-20261019');U=Path('/tmp/mio81-final-peer-assertion-sdk-root-20261007/build-current-sdk.py');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(U)=='2b7e969a1f90fc93eacc80d8b62890f0bb0ef8f40dc140d9398ef1a6029671e1'
s=importlib.util.spec_from_file_location('m98_continuity',U);sdk=importlib.util.module_from_spec(s);sys.modules[s.name]=sdk;s.loader.exec_module(sdk)
sources=sdk.current_sources();tools=sdk.tool_snapshot();allowed=set(json.loads((H/'late-wrapper-fixture-correction.json').read_text())['files']);records={}
for name in ['ordinary-default-green','ordinary-no-portmapper-green','gateway-product-tests-v2','probe-cli-build','final-native-sdk','final-browser-sdk']:
 build=H/name;c=json.loads((H/(name+'-context.json')).read_text());r=json.loads((build/'receipt.json').read_text());inputs=json.loads((build/'selected-dependency-inputs.json').read_text())
 assert r['exit']==0 and r['qualifiedForFrozenRun'] and r['sourceFrozenDuringBuild']
 diff={p for p in set(c['sources'])|set(sources) if c['sources'].get(p)!=sources.get(p)};assert diff==allowed,(name,diff)
 assert tools==c['tools']
 assert not {str(R/p) for p in diff}&set(inputs['inputs']),'changed source selected by compiled graph'
 for group in ['fixedInputs','selectorPins','artifactPins']:assert all(sha(p)==digest for p,digest in c[group].items()),group
 assert all(sha(p)==digest for p,digest in inputs['inputs'].items()),name
 assert all(sha(R/p)==digest for p,digest in inputs['copiedRepositoryInputs'].items()),name
 assert all(sha(p)==digest for p,digest in r['artifacts'].items()),name
 records[name]={'buildReceiptSha256':sha(build/'receipt.json'),'buildContextSha256':sha(H/(name+'-context.json')),
   'selectedInputManifestSha256':sha(build/'selected-dependency-inputs.json'),'allSelectedInputsAndImmutableArtifactsUnchanged':True,
   'selectedInputCount':len(inputs['inputs']),'oldGlobalSourceDigest':r['sourceDigestAfter'],'newGlobalSourceDigest':sdk.json_digest(sources),
   'onlyNonSelectedSourceChanges':sorted(diff),'noCompilationRequired':True}
assert sdk.current_sources()==sources and sdk.tool_snapshot()==tools
(H/'runtime-source-guard.json').write_text(json.dumps({'sources':sources,'tools':tools,'graphs':records,'requalificationDriverSha256':sha(__file__)},indent=2)+'\n')
(H/'nonselected-fixture-requalification.json').write_text(json.dumps({'graphs':records,'noSdkOrLibraryRebuild':True,'guardSha256':sha(H/'runtime-source-guard.json'),'driverSha256':sha(__file__),'sourceDigest':sdk.json_digest(sources)},indent=2)+'\n')
print(json.dumps({'requalifiedGraphs':len(records),'nonselectedSourceChanges':sorted(allowed),'sourceDigest':sdk.json_digest(sources),'allActualSelectedInputsUnchanged':True}))

import subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m98-20261019')
cmd=['build', '--locked', '--offline', '-p', 'miopunch-browser-probe', '--target', 'wasm32-unknown-unknown', '--features', 'rtc-probe', '--jobs', '2']
for phase,args in [('prepare',cmd),('run',[])]:
 r=subprocess.run(['rtk','proxy','python3',str(H/'build.py'),phase,'final-browser-sdk',*args]);assert r.returncode==0,phase

import argparse
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import time
import tomllib
from pathlib import Path

ROOT = Path('/home/js/Git/miopunch')
HERE = Path('/tmp/miopunch-m98-20261019')
UTILITY = Path('/tmp/mio81-final-peer-assertion-sdk-root-20261007/build-current-sdk.py')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

assert sha(UTILITY) == '2b7e969a1f90fc93eacc80d8b62890f0bb0ef8f40dc140d9398ef1a6029671e1'
spec = importlib.util.spec_from_file_location('m92_sdk_capture', UTILITY)
sdk = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = sdk
spec.loader.exec_module(sdk)
cache = sdk.cargo_cache

def pin_rows(path):
    return tomllib.loads(Path(path).read_text())['package']

def prepare(name, command):
    context = HERE / (name + '-context.json')
    assert not context.exists()
    fixed = json.loads((HERE / 'fixed-consumer-inputs.json').read_text())
    for path, digest in fixed.items():
        assert sha(path) == digest, 'fixed original consumer/input changed: ' + path
    selectors = {}
    if '--manifest-path' in command:
        manifest = Path(command[command.index('--manifest-path') + 1])
        lock = manifest.parent / 'Cargo.lock'
        selectors = {str(manifest): sha(manifest), str(lock): sha(lock)}
        canonical = HERE / 'baseline-selector/Cargo.lock'
        if manifest.parent.name=='original-selector':
            assert lock.read_bytes()==Path('/tmp/miopunch-fork-audit-20261012/baselines/iroh/iroh-1.2.0/Cargo.lock').read_bytes(), 'original published lock changed'
        else:
            foreign=lambda rows:[row for row in rows if row['name']!='mio83-replica-red-selected']
            assert foreign(pin_rows(lock))==foreign(pin_rows(canonical)), 'complete foreign dependency rows changed'
    canonical = HERE / 'baseline-selector/Cargo.lock'
    fixed[str(canonical)] = sha(canonical)
    artifacts = {}
    for receipt in [Path('/tmp/miopunch-m97-20261019/final-native-sdk/receipt.json'), Path('/tmp/miopunch-m97-20261019/final-browser-sdk/receipt.json'), Path('/tmp/miopunch-m93-20261018/old-native-counterpart-build/receipt.json')]:
        pinned = json.loads(receipt.read_text())
        assert pinned['exit'] == 0 and pinned['qualifiedForFrozenRun'] and pinned['sourceFrozenDuringBuild']
        artifacts[str(receipt)] = sha(receipt)
        for artifact_name, digest in pinned['artifacts'].items():
            assert sha(artifact_name) == digest
            artifacts[artifact_name] = digest
    for directory in ['native-sdk-reviewed', 'wasm-sdk-reviewed']:
        receipt = Path('/tmp/miopunch-native-socket-api-20261012') / directory / 'receipt.json'
        report = json.loads(receipt.read_text())
        assert report['exit'] == 0 and report['qualifiedForFrozenRun'] and report['sourceFrozenDuringBuild']
        artifacts[str(receipt)] = sha(receipt)
        for path, digest in report['artifacts'].items():
            artifact = Path(path) if Path(path).is_absolute() else receipt.parent / 'pkg' / path
            assert sha(artifact) == digest
            artifacts[str(artifact)] = digest
    context.write_text(json.dumps({'sources': sdk.current_sources(), 'tools': sdk.tool_snapshot(),
        'fixedInputs': fixed, 'selectorPins': selectors, 'artifactPins': artifacts,
        'command': command, 'driverSha256': sha(__file__)}, indent=2) + '\n')
    print(json.dumps({'prepared': name, 'sourceDigest': sdk.json_digest(sdk.current_sources()), 'contextSha256': sha(context)}))

def guard(context):
    assert Path.cwd().resolve() == ROOT
    assert sha(__file__) == context['driverSha256']
    assert sdk.current_sources() == context['sources'], 'source/lock/config changed'
    assert sdk.tool_snapshot() == context['tools'], 'tool changed'
    for group in ['fixedInputs', 'selectorPins', 'artifactPins']:
        assert all(sha(p) == h for p, h in context[group].items()), group + ' changed'

def run(name):
    path = HERE / (name + '-context.json')
    context = json.loads(path.read_text())
    guard(context)
    out = HERE / name
    assert not out.exists()
    target = cache.target_directory(ROOT)
    assert target == ROOT / 'target'
    with cache.cache_lease(target) as disk:
        guard(context)
        out.mkdir()
        command = cache.cargo_command(context['command'], target)
        (out / 'preconditions.json').write_text(json.dumps({'sourceLockArtifactToolPreconditionsPassedBeforeCargo': True,
            'contextSha256': sha(path), 'driverSha256': sha(__file__), 'command': command,
            'targetDirectory': str(target), 'diskBefore': disk}, indent=2) + '\n')
        started = time.monotonic()
        with (out / 'cargo.jsonl').open('w') as log, (out / 'cargo.stderr.log').open('w') as err:
            result = subprocess.run(command, cwd=ROOT, env=cache.build_environment(target), stdout=log, stderr=err)
        records = sdk.parse_cargo_artifacts(out / 'cargo.jsonl')
        report = {'exit': result.returncode, 'cargoSeconds': time.monotonic() - started, 'command': command,
            'freshArtifacts': sum(r.get('fresh') is True for r in records),
            'rebuiltArtifacts': sum(r.get('fresh') is False for r in records),
            'qualifiedForFrozenRun': False, 'sourceFrozenDuringBuild': False, 'artifacts': {}}
        (out / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
        guard(context)
        report['sourceFrozenDuringBuild'] = True
        if result.returncode == 0:
            artifacts = {}
            for record in records:
                if record.get('executable'):
                    artifact = Path(record['executable'])
                    dest = out / 'pinned' / record['target']['name']
                    dest.parent.mkdir(exist_ok=True)
                    shutil.copy2(artifact, dest)
                    assert sha(artifact) == sha(dest)
                    artifacts[str(dest)] = sha(dest)
            if context['command'][0] != 'check' and 'wasm32-unknown-unknown' in context['command']:
                artifact = sdk.wasm_artifact(records)
                dest = out / 'miopunch_browser_probe.wasm'
                shutil.copy2(artifact, dest)
                assert sha(artifact) == sha(dest)
                artifacts[str(dest)] = sha(dest)
                binding = subprocess.run(['rtk', 'proxy', str(sdk.BINDGEN), '--target', 'web',
                    '--out-dir', str(out / 'pkg'), str(dest)], cwd=ROOT, capture_output=True, text=True)
                (out / 'bindgen.stdout.log').write_text(binding.stdout)
                (out / 'bindgen.stderr.log').write_text(binding.stderr)
                assert binding.returncode == 0
                artifacts.update({str(f): sha(f) for f in (out / 'pkg').rglob('*') if f.is_file()})
            selected = sdk.capture_inputs(records, target, out, context['sources'])
            report.update(qualifiedForFrozenRun=True, artifacts=artifacts,
                actualSelectedInputCount=len(selected['inputs']), actualCapturedDepfileCount=len(selected['depfiles']),
                actualSourceCopyCount=len(selected['copiedRepositoryInputs']))
        guard(context)
        report.update(sourceDigestBefore=sdk.json_digest(context['sources']), sourceDigestAfter=sdk.json_digest(sdk.current_sources()),
            diskAfter=cache.disk_state(target))
        (out / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report))
        return result.returncode

parser = argparse.ArgumentParser()
parser.add_argument('operation', choices=['prepare', 'run'])
parser.add_argument('name')
parser.add_argument('cargo', nargs=argparse.REMAINDER)
args = parser.parse_args()
if args.operation == 'prepare':
    prepare(args.name, args.cargo[1:] if args.cargo[:1] == ['--'] else args.cargo)
else:
    raise SystemExit(run(args.name))

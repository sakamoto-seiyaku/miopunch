import gzip,hashlib,json,os,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m98-20261019');OLD=Path('/tmp/miopunch-m92-20261018')
sys.path.insert(0,str(R/'scripts'));import cargo_cache as cache
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
builds=['restricted-first-green-build','restricted-full-behavior-build','restricted-negative-build',
 'restricted-path-operation-green-build','restricted-router-green-build-v2','revoke-weak-green-build',
 'withdrawn-ready-green-build','withdrawn-ready-red-build','cancel-peer-green-build','cancel-peer-red-build',
 'cancel-peer-red-build-v2','control-scope-green-build','mqtt-diagnosis-build','mqtt-owner-drop-build']
plans=[]
for name in builds:
    d=OLD/name;receipt=d/'receipt.json';r=json.loads(receipt.read_text())
    p=d/'pinned/restricted_endpoint';assert p.is_file() and not p.is_symlink()
    digest=r['artifacts'][str(p)];assert sha(p)==digest
    plans.append({'originalPath':str(p),'originalSha256':digest,'originalBytes':p.stat().st_size,
                  'buildReceipt':str(receipt),'buildReceiptSha256':sha(receipt)})
live=[]
for d in Path('/proc').iterdir():
    if not d.name.isdigit():continue
    try:
        if (d/'comm').read_text().strip().startswith('restricted_endp'):
            live.append(str((d/'exe').resolve(strict=True)))
    except OSError:continue
assert not live,live
out=H/'historical-test-artifacts';out.mkdir(exist_ok=True)
with cache.cache_lease(R/'target',min_free=0) as before:
    assert not cache.active_compilers(R)
    for row in plans:
        p=Path(row['originalPath']);assert sha(p)==row['originalSha256']
        dest=out/(p.parent.parent.name+'-'+row['originalSha256']+'.bin.gz')
        assert not dest.exists()
        with p.open('rb') as src,gzip.open(dest,'wb',compresslevel=1) as dst:
            while block:=src.read(1024*1024):dst.write(block)
        digest=hashlib.sha256()
        with gzip.open(dest,'rb') as f:
            for b in iter(lambda:f.read(1024*1024),b''):digest.update(b)
        assert digest.hexdigest()==row['originalSha256']
        row.update(compressedPath=str(dest),compressedSha256=sha(dest),compressedBytes=dest.stat().st_size,
                   roundTripSha256=digest.hexdigest())
        assert sha(p)==row['originalSha256'];p.unlink()
        (H/'historical-test-compression-progress.json').write_text(json.dumps(plans,indent=2)+'\n')
    after=cache.disk_state(R/'target')
value={'reason':'Lossless storage of obsolete M92 intermediate test executables only. Exact official baselines, final tests, all SDK pins, raw logs, inputs and build receipts remain. To replay an intermediate, decompress its verified bytes to originalPath before using its unchanged historical driver.',
       'noSdkArtifactsAltered':True,'noCargoCacheAltered':True,'before':before,'after':after,'artifacts':plans}
(H/'historical-test-compression.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({'compressedTests':len(plans),'savedBytes':sum(r['originalBytes']-r['compressedBytes'] for r in plans),'diskAfter':after}))

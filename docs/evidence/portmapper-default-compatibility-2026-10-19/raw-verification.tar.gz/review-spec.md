No Spec findings.

MIOPUNCH-98 restores ordinary Enabled behavior without forcing Cargo features. Product resource assembly preserves saved Disabled/NatPmp choices; probes and fixtures declare their intent explicitly. The restricted delegate matches the ordinary method feature gate.

Reviewed evidence covers the unchanged pre-edit consumer, real failures, restored gateway mapping and PING/PONG, feature-off silence, 12 product gateway cases, owner isolation, cancellation/timeout release, CLI packet silence, and Native/Browser SDK durability and natural cleanup. Close returning and observed gateway deletion are separate.

Limits: read-only source/controller/receipt review; no builds or runtimes rerun. Controlled facilities only; arbitrary-router cleanup guarantees and broader physical/public matrix excluded.

import hashlib,json,tarfile
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m98-20261019')
O=R/'docs/evidence/portmapper-default-compatibility-2026-10-19';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def write(n,d):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
protected=read(H/'protected-wip.json')
assert all(sha(R/r['path'])==r['sha256'] for r in protected)
build_names=['ordinary-default-green','ordinary-no-portmapper-green','gateway-product-tests-final','affected-fixture-typecheck-current','probe-cli-build','final-native-sdk','final-browser-sdk']
builds={};continuity={}
for name in build_names:
 b=read(H/name/'receipt.json');i=read(H/name/'selected-dependency-inputs.json')
 assert b['exit']==0 and b['sourceFrozenDuringBuild'] and b['qualifiedForFrozenRun']
 assert all(sha(p)==s for p,s in i['inputs'].items())
 assert all(sha(R/p)==s for p,s in i['copiedRepositoryInputs'].items())
 assert all(sha(p)==s for p,s in b['artifacts'].items())
 builds[name]=b;continuity[name]={'selectedInputsUnchanged':True,'selectedInputCount':len(i['inputs']),'repositoryInputCount':len(i['copiedRepositoryInputs']),'immutableArtifactsUnchanged':True,'compiledGlobalSourceDigest':b['sourceDigestAfter']}
write('selected-input-continuity.json',continuity)
(H/'final-selected-input-continuity.json').write_text(json.dumps(continuity,indent=2)+'\n')
for p,s in read(H/'runtime-source-guard.json')['sources'].items():assert sha(R/p)==s
sdk=H/'final-sdk-story';e=read(sdk/'execution.json');r=read(sdk/'runtime/private-runtime-receipt.json')
assert e['qualified'] and r['qualified'] and r['cleanupQualified'] and r['currentStrictPurpose2Qualified']
assert e['rawReceiptSha256']==sha(sdk/'runtime/private-runtime-receipt.json')
assert r['business']['result']=='PONG' and r['approval']['new_records']==1
assert r['pendingReopen']['id']==r['completeReopen']['id']
assert all(r['materialCompletion']['status'][k] for k in ['authorization_saved','secret_saved'])
assert r['cleanup']['nativeExit']=={'code':0,'signal':None}
assert r['cleanup']['websocketsClosedBeforeContext'] and r['cleanup']['ownedFixtureRemoved']
oldguard=read(sdk/'execution-preconditions.json')['pins'][str(H/'runtime-source-guard.json')]
assert oldguard==sha(H/'runtime-source-guard-before-unit-fixture-fix.json')
public_sdk={'execution':e,'rawPrivateReceiptSha256':sha(sdk/'runtime/private-runtime-receipt.json'),
 'strictRestrictedRequest':True,'approvalRecords':1,'bothMaterialsDurable':True,
 'sameBrowserIdentityReopened':True,'sameNativeIdentityReopened':True,'memberReply':'PONG',
 'browserClose':r['cleanup']['browser'],'websocketsClosedBeforeContext':True,
 'socketImmediateObservationPassed':r['cleanup']['socketImmediateObservationPassed'],
 'nativeExit':r['cleanup']['nativeExit'],'ownedFixtureRemoved':True,
 'privateMaterialCleanup':read(sdk/'private-material-cleanup.json'),
 'runtimeGlobalDigest':e['sourceDigest'],'runtimeGuardOriginalBytesRetained':True,
 'finalSourceQualification':'Only non-selected unit/wrapped fixture changes after SDK compilation/runtime; every actual selected input and immutable artifact revalidated against current source.'}
gateway_names=['final-gateway-udp-'+s for s in ['positive','disabled','allocation-timeout','allocation-cancel']]+['gateway-tcp-'+s for s in ['positive','disabled','disabled-advanced','tcp-disabled-advanced','tcp-disabled','close-isolation','allocation-timeout','allocation-cancel']]
gateways={n:read(H/n/'receipt.json') for n in gateway_names}
assert len(gateways)==12 and all(v['qualified'] and v['lab']['qualified'] and v['lab']['sdkWorkersAlreadyExitedZero'] and not v['lab']['forcedProcesses'] for v in gateways.values())
for name,v in gateways.items():
 expected='udp_portmap' if v['kind']=='udp' else 'tcp_portmap'
 assert v['binarySha256']==sha(H/'gateway-product-tests-final/pinned'/expected)
cli={n:read(H/n/'receipt.json') for n in ['probe-cli-raw-runtime','probe-cli-wrapped-runtime','probe-cli-tcp-runtime']}
assert all(v['qualified'] and v['lab']['actualPingPong'] and v['lab']['noGatewayProtocolPackets'] and set(v['lab']['workerExits'].values())=={0} for v in cli.values())
ordinary={n:read(H/n/'receipt.json') for n in ['original-upnp-default-baseline-runtime-v2','restored-ordinary-default-runtime','no-portmapper-feature-runtime','current-default-upnp-diagnostic-red-runtime']}
assert all(v['qualified'] for v in ordinary.values())
assert ordinary['original-upnp-default-baseline-runtime-v2']['lab']['actualMappingRequests']>0
assert not ordinary['original-upnp-default-baseline-runtime-v2']['lab']['gatewayConfirmedOwnedDelete']
assert ordinary['restored-ordinary-default-runtime']['lab']['gatewayConfirmedOwnedDelete']
unit=read(H/'runtime-local-gateway-consent-final/receipt.json')
assert unit['testsPassed']==2 and unit['testsFailed']==0 and unit['exit']==0 and unit['postconditionsPassed']
assert read(H/'current-default-before/receipt.json')['exit']==101
features=read(H/'feature-boundaries.json')
assert 'unstable-custom-transports' not in features['ordinary-default-green']['features']
assert 'portmapper' not in features['ordinary-no-portmapper-green']['features']
assert 'portmapper' not in features['final-browser-sdk']['features']
write('validation.json',{'baselineCommit':(H/'source-baseline.txt').read_text().strip(),'implementationCommit':(H/'source-commit.txt').read_text().strip(),
 'protectedPreexistingFileCount':len(protected),'protectedHashesUnchanged':True,
 'beforeProductionEdits':read(H/'before-production-edits.json'),'fixedConsumerInputs':read(H/'fixed-consumer-inputs.json'),
 'originalContractContinuity':read(H/'original-contract-continuity.json'),'featureBoundaries':features,
 'finalBuilds':builds,'actualSelectedInputContinuity':continuity,
 'nonselectedFixtureRequalification':read(H/'nonselected-fixture-requalification.json'),
 'ordinaryRuntimeCases':ordinary,'actualOrdinaryFeatureCompileFailure':read(H/'current-default-before/receipt.json'),
 'diagnosticScope':'Pre-edit runtime RED uses explicitly marked custom-feature diagnostic because ordinary features fail compilation. It is not the unchanged ordinary compatibility consumer.',
 'gatewayCases':gateways,'uniqueGatewayCasesPassed':12,'productConsentUnits':unit,'probeCliCases':cli,'finalSdkStory':public_sdk,
 'failedPreparations':read(H/'failed-preparations.json'),'staleRevisionFixtureCorrection':read(H/'stale-revision-fixture-correction.json'),
 'cleanupScope':'Close returning and gateway-confirmed deletion are separate. Original upstream baseline had successful mapping/business but no observed delete; restored controlled gateway observed own delete and foreign retention. No arbitrary-router guarantee.',
 'scope':'M98 ordinary library defaults and explicit product/probe/fixture consent. Owned controlled facilities; broader public/physical matrix remains M91 followup.',
 'reviews':{'Standards':0,'Spec':0,'reranBuildOrRuntime':False}})
files=set()
def include(p):
 if p.is_file():files.add(p)
for pattern in ['*.py','*.rs','*-context.json']:
 for p in H.glob(pattern):include(p)
for n in ['review-spec.md','review-standards.md','review-summary.md','source-baseline.txt','source-commit.txt','source-commit-receipt.json','owned-source-files.json','implementation-owned-files.json','final-selected-input-continuity.json','fixed-consumer-inputs-v1.json','fixed-consumer-inputs.json','before-production-edits.json','diagnostic-purpose.json','feature-boundaries.json','explicit-fixture-choices.json','original-contract-continuity.json','late-wrapper-fixture-correction.json','stale-revision-fixture-correction.json','nonselected-fixture-requalification.json','nonselected-fixture-requalification-before-unit-fixture-fix.json','runtime-source-guard.json','runtime-source-guard-before-unit-fixture-fix.json','failed-preparations.json','fixture-preparation-failures.json','historical-test-compression.json','historical-test-compression-round2.json','obsolete-m93-duplicate-cache-review.json','obsolete-m93-duplicate-cache-review-round2.json','obsolete-test-cache-prune.json','obsolete-test-cache-prune-round2.json','original-fetch.json']:
 include(H/n)
for d in H.iterdir():
 if not d.is_dir():continue
 for n in ['Cargo.toml','Cargo.lock','receipt.json','preconditions.json','cargo.jsonl','cargo.stderr.log','selected-dependency-inputs.json','bindgen.stdout.log','bindgen.stderr.log','execute.py','run.mjs','execution.json','execution-preconditions.json','private-material-cleanup.json']:
  include(d/n)
for p in (H/'before-source').rglob('*'):
 if p.suffix in ['.rs','.md']:include(p)
for n in list(ordinary)+gateway_names+list(cli):
 for f in ['gateway.jsonl','upnp.jsonl','rules-before-gateway-stop.txt','gateway-neighbor-before-actor.txt','gateway.pcap','gateway-protocol-packets.txt','disabled-protocol-packets.txt','receipt.json','final-rules.txt','m98-natural-cleanup.json','m98-natural-cleanup-before-namespace-removal.json']:
  include(H/n/'result'/f)
for n in ['runtime-local-gateway-consent','runtime-local-gateway-consent-final']:
 for f in ['stdout.log','stderr.log']:include(H/n/f)
manifest={str(p.relative_to(H)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(files)}
archive=O/'raw-verification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(H)),recursive=False)
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(manifest)
 for m in t:
  data=t.extractfile(m).read();v=manifest[m.name]
  assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
write('archive-manifest.json',{'members':manifest,'archiveSha256':sha(archive),'archiveBytes':archive.stat().st_size,'allMembersReadBackAndVerified':True,'excluded':['Raw private SDK receipts, synthetic identities, invitations, native/Browser logs, stores, keys and NSS; public results use explicit scalar/hash allowlist','Ordinary/diagnostic/CLI/product worker identity logs remain local','Immutable executables/WASM, selected source copies and compressed historical executables remain local with hash references']})
(O/'review.md').write_text((H/'review-summary.md').read_text()+'\n'+(H/'review-standards.md').read_text()+'\n'+(H/'review-spec.md').read_text())
print(json.dumps({'archiveMembers':len(manifest),'archiveBytes':archive.stat().st_size,'uniqueGatewayCases':12,'consentUnits':2,'cliCases':3,'sdkStoryPassed':True}))

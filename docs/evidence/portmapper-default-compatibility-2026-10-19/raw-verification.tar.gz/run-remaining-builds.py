import json,subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m98-20261019')
for name,cmd in json.loads((H/'remaining-build-plans.json').read_text()):
 for phase,args in [('prepare',cmd),('run',[])]:
  r=subprocess.run(['rtk','proxy','python3',str(H/'build.py'),phase,name,*args]);assert r.returncode==0,(name,phase)
print('M98 affected builds complete',flush=True)

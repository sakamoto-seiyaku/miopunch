import argparse,json,os,select,shutil,subprocess,sys,tempfile,time
from pathlib import Path
sys.path.insert(0,'/repo/scripts');from udp_portmap_lab import gateway as nat_gateway
from upnp_gateway import start as start_upnp
def gateway(directory):
 close=start_upnp(directory)
 try:nat_gateway(directory)
 finally:close()

def command(*args,**kwargs):return subprocess.run(args,check=True,text=True,**kwargs)
def lab(binary,output,expect):
 out=Path(output);out.mkdir(exist_ok=False);fixture=Path(tempfile.mkdtemp(prefix='m98-ordinary-'))
 prefix='m98-'+str(os.getpid());names={role:prefix+'-'+role for role in ['gateway','node','remote']}
 processes=[];files=[];gateway_process=None;capture=None;report={'expectation':expect,'passed':False,'workerExits':{},'cleanup':{}}
 def ns(role,*args,**kwargs):return command('ip','netns','exec',names[role],*args,**kwargs)
 def spawn(role,args,name):
  file=(out/name).open('w');files.append(file)
  p=subprocess.Popen(['ip','netns','exec',names[role],*args],stdout=file,stderr=subprocess.STDOUT,text=True);processes.append(p);return p
 try:
  for name in names.values():command('ip','netns','add',name);command('ip','-n',name,'link','set','lo','up')
  for left,li,la,right,ri,ra in [('gateway','lan0','10.39.0.1/24','node','eth0','10.39.0.2/24'),('gateway','wan0','100.64.39.1/24','remote','eth0','100.64.39.2/24')]:
   a=prefix+'a';b=prefix+'b';command('ip','link','add',a,'type','veth','peer','name',b)
   for link,role,interface,address in [(a,left,li,la),(b,right,ri,ra)]:
    command('ip','link','set',link,'netns',names[role]);command('ip','-n',names[role],'link','set',link,'name',interface);command('ip','-n',names[role],'addr','add',address,'dev',interface);command('ip','-n',names[role],'link','set',interface,'up')
  command('ip','-n',names['node'],'route','add','default','via','10.39.0.1')
  # Original netdev requires a learned gateway neighbor, as on an active LAN.
  gateway_mac=json.loads(ns('gateway','ip','-j','link','show','dev','lan0',capture_output=True).stdout)[0]['address']
  ns('node','ip','neigh','replace','10.39.0.1','lladdr',gateway_mac,'nud','permanent','dev','eth0')
  with (out/'gateway-neighbor-before-actor.txt').open('w') as log:ns('node','ip','neigh','show',stdout=log)

  ns('gateway','sysctl','-qw','net.ipv4.ip_forward=1');ns('gateway','iptables','-P','FORWARD','DROP')
  ns('gateway','iptables','-A','FORWARD','-i','lan0','-o','wan0','-j','ACCEPT');ns('gateway','iptables','-A','FORWARD','-m','conntrack','--ctstate','ESTABLISHED,RELATED','-j','ACCEPT')
  ns('gateway','iptables','-t','nat','-A','POSTROUTING','-o','wan0','-j','MASQUERADE')
  ns('gateway','iptables','-t','nat','-A','PREROUTING','-i','wan0','-p','udp','--dport','49039','-j','DNAT','--to-destination','10.39.0.3:49039')
  gateway_process=spawn('gateway',['python3',__file__,'gateway',str(fixture)],'gateway-process.log')
  capture=spawn('gateway',['tcpdump','--immediate-mode','-U','-ni','any','-w',str(out/'gateway.pcap'),'udp'],'tcpdump.log')
  deadline=time.monotonic()+5
  while not (fixture/'gateway.jsonl').exists():assert time.monotonic()<deadline;time.sleep(.02)
  role='quiet' if expect=='no-feature' else 'serve';server=spawn('node',[binary,role,str(fixture)],'server.log')
  if expect=='mapping':
   deadline=time.monotonic()+10
   while not (fixture/'mapped').exists():assert server.poll() is None and time.monotonic()<deadline,'ordinary mapping absent';time.sleep(.025)
   client=spawn('remote',[binary,'connect',str(fixture)],'client.log');report['workerExits']['client']=client.wait(timeout=12)
   assert report['workerExits']['client']==0
  report['workerExits']['server']=server.wait(timeout=14)
  assert report['workerExits']['server']==(1 if expect=='absent-default' else 0)
  events=[json.loads(line) for file in [fixture/'gateway.jsonl',fixture/'upnp.jsonl'] for line in file.read_text().splitlines()]
  mappings=[v for v in events if v.get('granted_lifetime',0)>0]
  releases=[v for v in events if v.get('requested_lifetime')==0 and v.get('released')]
  with (out/'rules-before-gateway-stop.txt').open('w') as f:ns('gateway','iptables-save',stdout=f)
  rules=(out/'rules-before-gateway-stop.txt').read_text();assert '--dport 49039' in rules
  if expect=='mapping':
   assert mappings and 'DEFAULT_MAPPING_DATA_OK' in (out/'server.log').read_text() and 'MAPPED_REMOTE_DATA_OK' in (out/'client.log').read_text()
   # Baseline close is best effort; separately report what the gateway actually saw.
   report['gatewayConfirmedOwnedDelete']=bool(releases) and '--dport 41039' not in rules
  else:assert not mappings and all(event.get('gateway_started') or event.get('upnp_started') for event in events),'a disabled feature/default must produce no mapping request'
  report.update(passed=True,actualMappingRequests=len(mappings),deleteRequests=len(releases),foreignOwnerRetainedBeforeGatewayStop=True,
    serverCloseReturned='ENDPOINT_CLOSE_RETURNED' in (out/'server.log').read_text(),sdkWorkersNaturallyExited=True)
 finally:
  # Stop the controlled gateway through its normal sentinel, then the capture utility.
  (fixture/'stop-gateway').touch()
  if gateway_process:
   report['cleanup']['gatewayExit']=gateway_process.wait(timeout=4)
  if capture:
   capture.send_signal(2);report['cleanup']['captureExit']=capture.wait(timeout=4)
  report['cleanup']['forcedSdkWorkers']=[]
  for p in processes:
   if p.poll() is None:
    report['cleanup']['forcedSdkWorkers'].append(p.pid);p.terminate();p.wait(timeout=3)
  for file in files:file.close()
  if (fixture/'gateway.jsonl').exists():shutil.copy2(fixture/'gateway.jsonl',out/'gateway.jsonl')
  if (fixture/'upnp.jsonl').exists():shutil.copy2(fixture/'upnp.jsonl',out/'upnp.jsonl')
  shutil.rmtree(fixture);report['cleanup']['ownedFixtureRemoved']=not fixture.exists()
  for name in reversed(list(names.values())):command('ip','netns','del',name)
  if report['passed'] and expect!='mapping':
   packets=subprocess.run(['tcpdump','-nn','-r',str(out/'gateway.pcap'),'udp port 5351 or udp port 1900'],capture_output=True,text=True)
   (out/'gateway-protocol-packets.txt').write_text(packets.stdout)
   assert packets.returncode==0 and not packets.stdout.strip(), 'feature-off/default-disabled sent gateway protocol packets'
   report['noGatewayProtocolPackets']=True
  remaining=subprocess.check_output(['ip','netns','list'],text=True);report['cleanup']['namespacesAbsent']=all(name not in remaining for name in names.values())
  report['qualified']=report['passed'] and report.get('serverCloseReturned') and not report['cleanup']['forcedSdkWorkers'] and report['cleanup']['gatewayExit']==0 and report['cleanup']['namespacesAbsent']
  (out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
 assert report['qualified'],report

if __name__=='__main__':
 if sys.argv[1]=='gateway':gateway(sys.argv[2])
 else:lab(*sys.argv[2:])

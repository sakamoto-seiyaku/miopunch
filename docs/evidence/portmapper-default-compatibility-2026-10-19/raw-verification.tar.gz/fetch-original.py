import hashlib,json,subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m98-20261019');M=H/'original-selector/Cargo.toml';L=M.parent/'Cargo.lock';O=Path('/tmp/miopunch-fork-audit-20261012/baselines/iroh/iroh-1.2.0/Cargo.lock')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
inputs={str(p):sha(p) for p in [M,L,O,H/'ordinary-default-consumer.rs']};assert L.read_bytes()==O.read_bytes()
cmd=['rtk','proxy','cargo','fetch','--locked','--manifest-path',str(M),'--target','x86_64-unknown-linux-gnu']
with (H/'original-fetch.stdout.log').open('w') as out,(H/'original-fetch.stderr.log').open('w') as err:r=subprocess.run(cmd,stdout=out,stderr=err,cwd='/home/js/Git/miopunch')
assert all(sha(p)==digest for p,digest in inputs.items())
(H/'original-fetch.json').write_text(json.dumps({'exit':r.returncode,'command':cmd,'exactPublishedLockUnchanged':True,'inputs':inputs,'noCompilationRequested':True},indent=2)+'\n');print(json.dumps({'exit':r.returncode,'originalPublishedLockUnchanged':True}));raise SystemExit(r.returncode)

import subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m98-20261019')
for case in ['positive','disabled','allocation-timeout','allocation-cancel']:
 r=subprocess.run(['rtk','proxy','python3',str(H/'run-gateway-final.py'),'udp',case,'final-gateway-udp-'+case]);assert r.returncode==0,case

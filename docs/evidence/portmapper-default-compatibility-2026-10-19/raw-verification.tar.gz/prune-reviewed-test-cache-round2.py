import fcntl,hashlib,json,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m98-20261019');sys.path.insert(0,str(R/'scripts'));import cargo_cache as cache
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=H/'obsolete-m93-duplicate-cache-review-round2.json';rows=json.loads(review.read_text())['files'];review_hash=sha(review)
with (R/'target/.miopunch-build.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX);assert not cache.active_compilers(R)
 live=set()
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:live.add(str((p/'exe').resolve(strict=True)))
  except OSError:pass
 for row in rows:
  p=Path(row['path']);pin=Path(row['retainedImmutableTestPin'])
  assert p.parent==R/'target/debug/deps' and not p.is_symlink() and p.stat().st_nlink==1 and str(p) not in live
  assert sha(p)==sha(pin)==row['sha256'] and sha(row['buildReceipt'])==row['buildReceiptSha256']
 assert sha(review)==review_hash
 before=cache.disk_state(R/'target')
 for row in rows:Path(row['path']).unlink()
 assert all(sha(row['retainedImmutableTestPin'])==row['sha256'] for row in rows)
 after=cache.disk_state(R/'target')
(H/'obsolete-test-cache-prune-round2.json').write_text(json.dumps({'reviewSha256':review_hash,'removedExactCaches':len(rows),'immutableTestPinsRetainedAndVerified':True,'sdkArtifactsAndLibrariesUnchanged':True,'noCargoInvoked':True,'compileDiskFloorAndCapUnchanged':True,'before':before,'after':after},indent=2)+'\n');print(json.dumps({'removed':len(rows),'after':after}))

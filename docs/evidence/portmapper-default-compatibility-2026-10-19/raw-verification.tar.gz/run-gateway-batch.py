import json,subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m98-20261019')
for kind,case in json.loads((H/'gateway-runtime-plans.json').read_text()):
 r=subprocess.run(['rtk','proxy','python3',str(H/'run-gateway.py'),kind,case,'gateway-'+kind+'-'+case]);assert r.returncode==0,(kind,case)
print('M98 product gateway cases completed',flush=True)

import hashlib,json,shutil,subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m98-20261019');names=['final-sdk-story']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name in names:
 case=H/name;execution=json.loads((case/'execution.json').read_text());raw=case/'runtime/private-runtime-receipt.json';r=json.loads(raw.read_text());c=r['cleanup']
 assert execution['qualified'] and execution['runtimeExit']==0 and sha(raw)==execution['rawReceiptSha256']
 assert c['ownedBrowserProcessClosed'] and c['ownedBrowserContextClosed'] and c['nativeProcessAbsentImmediate'] and c['nativeProcessAbsentLate'] and c['ownedFixtureRemoved'] and c['websocketsClosedBeforeContext']
 assert c['nativeExit']['code']==0 and execution['cleanup']['relayExit']==0 and execution['cleanup']['relayProcessAbsent'] and execution['cleanup']['relayGraceful']
 for container in execution['containers']:
  assert container['removed'];assert subprocess.run(['rtk','proxy','docker','inspect',container['name']],capture_output=True).returncode!=0
 f=case/'private-fixture';assert f.is_dir();removed=[]
 for key in f.glob('*.key'):
  assert key.name in ['ca.key','leaf.key'] and not key.is_symlink();removed.append({'path':str(key.relative_to(case)),'bytes':key.stat().st_size});key.unlink()
 nss=f/'nssdb';assert nss.is_dir() and not nss.is_symlink();shutil.rmtree(nss)
 report={'sdkAndActorCleanupQualifiedBeforeSecretRemoval':True,'containersActuallyAbsent':True,'runtimeReceiptSha256':sha(raw),'removedGeneratedKeys':removed,'privateNssRemoved':not nss.exists(),'remainingPrivateKeys':len(list(f.glob('*.key')))}
 assert len(removed)==2 and report['remainingPrivateKeys']==0
 (case/'private-material-cleanup.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'case':name,'generatedKeysRemoved':len(removed),'nssRemoved':report['privateNssRemoved']}))

import hashlib,importlib.util,json,subprocess,sys,time
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m98-20261019');U=Path('/tmp/mio81-final-peer-assertion-sdk-root-20261007/build-current-sdk.py')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(U)=='2b7e969a1f90fc93eacc80d8b62890f0bb0ef8f40dc140d9398ef1a6029671e1'
s=importlib.util.spec_from_file_location('m98_sdk',U);sdk=importlib.util.module_from_spec(s);sys.modules[s.name]=sdk;s.loader.exec_module(sdk)
build,name,expect=sys.argv[1:];b=H/build;context=json.loads((H/(build+'-context.json')).read_text());receipt=json.loads((b/'receipt.json').read_text())
assert len(receipt['artifacts'])==1;binary=Path(next(iter(receipt['artifacts'])));fixed={str(p):sha(p) for p in [H/'ordinary-lab.py',H/'upnp_gateway.py',Path(__file__),R/'scripts/udp_portmap_lab.py']}
def guard():
 assert sdk.current_sources()==context['sources'] and sdk.tool_snapshot()==context['tools']
 assert receipt['exit']==0 and receipt['qualifiedForFrozenRun'] and receipt['sourceFrozenDuringBuild']
 for group in ['fixedInputs','selectorPins','artifactPins']:assert all(sha(p)==digest for p,digest in context[group].items())
 assert all(sha(p)==digest for p,digest in receipt['artifacts'].items())
 assert all(sha(p)==digest for p,digest in fixed.items())
guard();out=H/name;out.mkdir();container='miopunch-m98-'+str(time.time_ns());image='miopunch-nat61-lab:bookworm';imageid=subprocess.check_output(['rtk','proxy','docker','image','inspect',image,'--format','{{.Id}}'],text=True).strip();assert imageid=='sha256:c9dbb88a37f58ae5105720e60bc5cc6eb40d8ad37106e57ce621d345b5ec62a2'
command=['rtk','proxy','docker','run','--rm','--name',container,'--privileged','--network','none',
 '--mount',f'type=bind,src={R},target=/repo,readonly','--mount',f'type=bind,src={H},target=/task,readonly',
 '--mount',f'type=bind,src={out},target=/evidence',image,'python3','/task/ordinary-lab.py','lab',
 '/task/'+str(binary.relative_to(H)),'/evidence/result',expect]
(out/'preconditions.json').write_text(json.dumps({'sourcesLocksArtifactsToolsAndLabBeforeActors':True,'fixedInputs':fixed,'buildReceiptSha256':sha(b/'receipt.json'),'buildContextSha256':sha(H/(build+'-context.json')),'binarySha256':sha(binary),'imageId':imageid,'command':command},indent=2)+'\n')
start=time.monotonic()
with (out/'docker.stdout.log').open('w') as stdout,(out/'docker.stderr.log').open('w') as stderr:r=subprocess.run(command,stdout=stdout,stderr=stderr,cwd=R)
guard();absent=subprocess.run(['rtk','proxy','docker','inspect',container],capture_output=True).returncode!=0
inner=json.loads((out/'result/receipt.json').read_text())
report={'exit':r.returncode,'seconds':time.monotonic()-start,'preAndPostconditionsPassed':True,'containerActuallyAbsent':absent,'lab':inner,'binarySha256':sha(binary),'sourceDigest':sdk.json_digest(sdk.current_sources()),'qualified':r.returncode==0 and absent and inner['qualified']}
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));raise SystemExit(0 if report['qualified'] else 1)

import argparse,json,os,socket,subprocess,time,hashlib
from pathlib import Path
h=Path('/tmp/miopunch-m93-20261018')
p=argparse.ArgumentParser();p.add_argument('--timeout-seconds',type=float,default=80);p.add_argument('build');p.add_argument('name');p.add_argument('binary');p.add_argument('arguments',nargs=argparse.REMAINDER);a=p.parse_args()
service='mio93-'+a.name
receipt={'containerName':service,'started':False,'removed':False,'testExit':None}
path=h/(a.name+'-service.json');assert not path.exists()
def call(args):return subprocess.run(['rtk','proxy',*args],capture_output=True,text=True,check=True)
image=json.loads(call(['docker','image','inspect','eclipse-mosquitto:2']).stdout)[0]['Id']
receipt['imageId']=image
try:
    container=call(['docker','run','--pull=never','-d','--name',service,'--label','miopunch.task=M93','-p','127.0.0.1::1883','--tmpfs','/mosquitto/data','--tmpfs','/mosquitto/log','-v',str(h/'mosquitto.conf')+':/mosquitto/config/mosquitto.conf:ro',image]).stdout.strip()
    receipt.update(started=True,containerId=container)
    info=json.loads(call(['docker','inspect',container]).stdout)[0];receipt['mounts']=info['Mounts']
    assert not any(m['Type']=='volume' for m in info['Mounts'])
    binding=info['NetworkSettings']['Ports']['1883/tcp'][0];assert binding['HostIp']=='127.0.0.1'
    port=int(binding['HostPort']);broker='127.0.0.1:'+str(port);receipt['broker']=broker
    deadline=time.monotonic()+5
    while True:
        try:
            with socket.create_connection(('127.0.0.1',port),timeout=.2):break
        except OSError:
            assert time.monotonic()<deadline;time.sleep(.05)
    env=os.environ.copy();env['MIOPUNCH_MQTT_BROKER']=broker
    command=['rtk','proxy','python3',str(h/'run-tests.py'),'--timeout-seconds',str(a.timeout_seconds),a.build,a.name,a.binary,*a.arguments]
    started=time.monotonic();result=subprocess.run(command,env=env)
    receipt.update(testExit=result.returncode,seconds=time.monotonic()-started)
finally:
    if receipt['started']:
        logs=call(['docker','logs',service]);(h/(a.name+'-service.stdout.log')).write_text(logs.stdout);(h/(a.name+'-service.stderr.log')).write_text(logs.stderr)
        call(['docker','stop','--time','5',service]);receipt['stopped']=True
        info=json.loads(call(['docker','inspect',service]).stdout)[0];receipt['serviceExit']=info['State']['ExitCode'];assert info['State']['Running'] is False
        call(['docker','rm','--volumes',service]);receipt['removed']=True
        remaining=call(['docker','ps','-aq','--filter','name=^/'+service+'$']).stdout.strip();assert not remaining;receipt['ownedContainerAbsent']=True
    receipt['driverSha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    path.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt));raise SystemExit(receipt['testExit'] if receipt['testExit'] is not None else 1)

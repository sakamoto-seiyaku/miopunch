import argparse
import hashlib
import importlib.util
import json
import re
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/home/js/Git/miopunch')
HERE = Path('/tmp/miopunch-m93-20261018')
UTILITY = Path('/tmp/mio81-final-peer-assertion-sdk-root-20261007/build-current-sdk.py')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(UTILITY) == '2b7e969a1f90fc93eacc80d8b62890f0bb0ef8f40dc140d9398ef1a6029671e1'
spec = importlib.util.spec_from_file_location('m92_runtime_capture', UTILITY)
sdk = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = sdk
spec.loader.exec_module(sdk)

parser=argparse.ArgumentParser()
parser.add_argument('build');parser.add_argument('name');parser.add_argument('--case',choices=['first','restart','management','precode','resources','all'],default='first')
args=parser.parse_args()
receipt_path=HERE/args.build/'receipt.json';context_path=HERE/(args.build+'-context.json')
report=json.loads(receipt_path.read_text());context=json.loads(context_path.read_text())
helper=ROOT/'scripts/check_desktop_management.py';helper_hash=sha(helper)
def guard():
    assert Path.cwd().resolve()==ROOT
    assert report['exit']==0 and report['qualifiedForFrozenRun'] and report['sourceFrozenDuringBuild']
    assert sdk.current_sources()==context['sources'] and sdk.tool_snapshot()==context['tools']
    for group in ['fixedInputs','selectorPins','artifactPins']:
        assert all(sha(p)==h for p,h in context[group].items())
    assert all(sha(p)==h for p,h in report['artifacts'].items())
    assert sha(helper)==helper_hash

guard()
out=HERE/args.name;out.mkdir(exist_ok=False,mode=0o700)
(out/'helper.py').write_bytes(helper.read_bytes())
resources=out/'owned-local-resources.json';resources.write_text('[]\n')
spec=importlib.util.spec_from_file_location('m93_desktop_story',helper)
story=importlib.util.module_from_spec(spec);sys.modules[spec.name]=story;spec.loader.exec_module(story)
binary=HERE/args.build/'pinned/miopunch-native-probe';assert str(binary) in report['artifacts']
from types import SimpleNamespace
class LocalLab(story.Lab):
    def __init__(self,args):
        super().__init__(args);self.local_configured=set()
    def session(self,platform,directory):
        key=str(Path(directory).resolve())
        if key not in self.local_configured:
            self.run(platform,'network','resources-import',self.path(platform,directory),str(resources))
            self.local_configured.add(key)
        return super().session(platform,directory)
forced=[]
original_popen=subprocess.Popen
def tracked_popen(*arguments,**keywords):
    process=original_popen(*arguments,**keywords)
    original_kill=process.kill
    def tracked_kill():
        forced.append(process.pid);return original_kill()
    process.kill=tracked_kill
    return process
subprocess.Popen=tracked_popen
lab=LocalLab(SimpleNamespace(output=str(out/'lab'),linux_bin=str(binary),windows_runner=None,windows_bin=None))
result={'buildReceiptSha256':sha(receipt_path),'buildContextSha256':sha(context_path),'driverSha256':sha(__file__),
    'helperSha256':helper_hash,'binarySha256':sha(binary),'preconditionsPassed':True,'configuredResources':'empty owned-local fixture','platform':'linux','cases':[],'exit':1}
started=time.monotonic()
try:
    cases={'first':lab.first,'restart':lab.restart_pending,'management':lab.management,'precode':lab.precode,'resources':lab.resources}
    for name in cases if args.case=='all' else [args.case]:
        result['cases'].append(cases[name]('linux','linux',name+'-typed-cli'))
    result['exit']=0
except Exception as error:
    result['failure']=repr(error)
    import traceback
    (out/'failure.txt').write_text(traceback.format_exc())
finally:
    errors=[]
    for process in lab.processes:
        if process.proc.poll() is None:
            try:process.close()
            except Exception as error:errors.append(repr(error))
    result['cleanupErrors']=errors
    result['processes']=[{'pid':process.proc.pid,'exit':process.proc.poll()} for process in lab.processes]
    result['naturalCleanup']=not forced and not errors and all(p['exit']==0 for p in result['processes'])
    result['forcedTerminationPids']=forced
    result['seconds']=time.monotonic()-started
    lab.log.close()
    if not result['naturalCleanup']:result['exit']=1
    guard();result['postconditionsPassed']=True
    result['processLogSha256']=sha(out/'lab/processes.log')
    (out/'receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
if result['exit']:
    print((out/'failure.txt').read_text() if (out/'failure.txt').exists() else 'cleanup failed')
raise SystemExit(result['exit'])

use std::{net::Ipv4Addr,sync::{Arc,atomic::{AtomicUsize,Ordering}},time::Duration};
use iroh::{EndpointAddr,endpoint::{Connection,EndpointHooks,AfterHandshakeOutcome},protocol::{ProtocolHandler,AcceptError},address_lookup::memory::MemoryLookup};
use p2panda_net::{AddressBook,Endpoint,iroh_endpoint::IrohConfig};
#[derive(Clone,Debug)]struct Hook(Arc<AtomicUsize>);
impl EndpointHooks for Hook {async fn after_handshake(&self,_:&Connection)->AfterHandshakeOutcome {self.0.fetch_add(1,Ordering::SeqCst);AfterHandshakeOutcome::Accept}}
#[derive(Debug)]struct Echo;
impl ProtocolHandler for Echo {async fn accept(&self,connection:Connection)->Result<(),AcceptError> {
 let (mut send,mut recv)=connection.accept_bi().await?;
 assert_eq!(recv.read_to_end(4).await.map_err(std::io::Error::other)?,b"PING");
 send.write_all(b"PONG").await.map_err(std::io::Error::other)?;send.finish()?;connection.closed().await;Ok(())
}}
fn config()->IrohConfig {IrohConfig {bind_ip_v4:Ipv4Addr::LOCALHOST,bind_port_v4:0,bind_ip_v6:std::net::Ipv6Addr::LOCALHOST,bind_port_v6:0}}
#[tokio::main]async fn main() {
 let calls=Arc::new(AtomicUsize::new(0));let a=AddressBook::builder().spawn().await.unwrap();let b=AddressBook::builder().spawn().await.unwrap();
 let server_key=p2panda_core::SigningKey::generate();let server_id=iroh::SecretKey::from_bytes(server_key.as_bytes()).public();
 let hook=Hook(calls.clone());
 let server=Endpoint::builder(a).network_id([23;32]).signing_key(server_key.clone()).config(config()).endpoint_builder_hook(move|builder|builder.hooks(hook.clone())).spawn().await.unwrap();
 server.accept(b"wrapped-ordinary-consumer/1",Echo).await.unwrap();
 let se:iroh::Endpoint=server.endpoint().await.unwrap();
 let lookup=MemoryLookup::from_endpoint_info([EndpointAddr::new(server_id).with_addrs(se.addr().ip_addrs().copied().map(iroh::TransportAddr::Ip))]);
 let hook=Hook(calls.clone());
 let client=Endpoint::builder(b).network_id([23;32]).config(config()).endpoint_builder_hook(move|builder|builder.address_lookup(lookup.clone()).hooks(hook.clone())).spawn().await.unwrap();
 let connection=tokio::time::timeout(Duration::from_secs(5),client.connect(server_key.verifying_key(),b"wrapped-ordinary-consumer/1")).await.unwrap().unwrap();
 let (mut send,mut recv)=connection.open_bi().await.unwrap();send.write_all(b"PING").await.unwrap();send.finish().unwrap();assert_eq!(recv.read_to_end(4).await.unwrap(),b"PONG");
 assert_eq!(calls.load(Ordering::SeqCst),2);connection.close(0u32.into(),b"ordinary wrapped consumer complete");drop(connection);
 let ce:iroh::Endpoint=client.endpoint().await.unwrap();tokio::join!(ce.close(),se.close());drop((client,server,ce,se));
 println!("ORDINARY_WRAPPED_CONSUMER_PASS unchanged_source=true original_endpoint_return=true hooks=2 ping_pong=true closed=true");
}

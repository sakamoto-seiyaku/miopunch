use std::{net::Ipv4Addr, time::Duration};
use miopunch_native_probe::{admission_gate::{ProtocolScope, ADMISSION_REQUEST_ALPN}, native_network::NativeNetwork};
use tokio::io::{AsyncBufReadExt, BufReader};
#[tokio::main]
async fn main() {
    let directory = std::env::args_os().nth(1).expect("owned fixture directory");
    let network = NativeNetwork::create(directory).await.unwrap();
    let mut resources = network.resource_configuration().unwrap();
    resources.replacement = Some(vec![]);
    resources.mqtt_facilities.clear();
    network.save_resource_configuration(&resources).unwrap();
    let endpoint = network.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    endpoint.set_alpns(vec![ADMISSION_REQUEST_ALPN.to_vec()]);
    let address = endpoint.addr().ip_addrs().find(|a| a.is_ipv4()).copied().unwrap();
    println!("{}", serde_json::json!({"event":"ready","id":endpoint.id().to_string(),"address":address.to_string()}));
    let accepted = tokio::time::timeout(Duration::from_secs(10), async {
        endpoint.accept().await.unwrap()
            .with_caller_deadline(n0_future::time::Instant::now() + Duration::from_secs(8))
            .await
    }).await;
    let success = if let Ok(Ok(connection)) = accepted {
        println!("{}", serde_json::json!({"event":"control-ready","requestAllowed":network.admission_gate().allows(&connection, ProtocolScope::AdmissionRequest),"memberAllowed":network.admission_gate().allows(&connection, ProtocolScope::Member)}));
        let mut input = BufReader::new(tokio::io::stdin());
        let mut command = String::new();
        let closed = tokio::time::timeout(Duration::from_secs(5), input.read_line(&mut command)).await;
        let success = matches!(closed, Ok(Ok(n)) if n > 0) && command.trim() == "close";
        connection.close(0u32.into(), b"owned counterpart closed");
        drop(connection);
        success
    } else { println!("{}", serde_json::json!({"event":"failed","stage":"request-control"})); false };
    endpoint.close().await;
    drop(endpoint);
    network.close().await;
    println!("{}", serde_json::json!({"event":"closed","natural":true,"passed":success}));
    if !success { std::process::exit(1); }
}

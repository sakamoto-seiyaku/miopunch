//! Durable native node entry for creating and reopening one private network.
//!
//! A creator saves its device key, trusted genesis credential, public network
//! anchor and admission secret. A joining device saves its own key and trusted
//! invitation, then independently persists verified membership and the current
//! secret. Ordinary joined devices never acquire the genesis private key.

use std::fs::{self, OpenOptions};
use std::io::Write;
use std::net::{Ipv4Addr, SocketAddr};
#[cfg(unix)]
use std::os::unix::fs::{DirBuilderExt, OpenOptionsExt};
use std::path::{Path, PathBuf};
use std::sync::Arc;

use iroh::endpoint::{Builder, presets};
use iroh::{Endpoint, SecretKey};
use p2panda_auth::group::{GroupAction, GroupMember};
use p2panda_auth::{Access, GroupsExtensionArgs};
use p2panda_core::{Hash, Header, SigningKey, VerifyingKey};
use thiserror::Error;

use crate::admission_gate::AdmissionGate;
use crate::admission_proof::{AdmissionScope, AdmissionSecret};
use crate::genesis_recovery::GenesisCredential;
use crate::management_auth::{ManagementExtension, NetworkAnchor};
use crate::management_recovery::RecoveryBinding;
use crate::management_store::{ManagementRecord, ManagementStore, StoreError};
use crate::manual_admission::{JoinBinding, ManualInvitation};
use crate::nat_connection::{NatConnector, UdpPolicy, UdpUpgrade};
use crate::native_files::{publish_file, replace_file, sync_directory};

const NODE_KEY: &str = "node.key";
const GENESIS_CREDENTIAL: &str = "genesis.credential";
const ANCHOR: &str = "network.anchor";
const ADMISSION_SECRET: &str = "admission.secret";
const MANAGEMENT_DB: &str = "management.sqlite";
const JOIN_BINDING: &str = "join.invitation";
const ADMISSION_MATERIAL: &str = "admission.material";
const RECOVERY_BINDING: &str = "recovery.binding";
const RESOURCE_CONFIGURATION: &str = "resources.json";
const MAINTENANCE_CONTACTS: &str = "maintenance.contacts.json";

fn network_protocols() -> Vec<Vec<u8>> {
    vec![
        crate::connection_coordinator::MEMBER_ALPN.to_vec(),
        crate::connection_coordinator::ACTIVE_IMPROVEMENT_ALPN.to_vec(),
        crate::connection_coordinator::REPLICA_ALPN.to_vec(),
        crate::admission_gate::PRECODE_REQUEST_ALPN.to_vec(),
        crate::admission_gate::ADMISSION_REQUEST_ALPN.to_vec(),
        crate::connection_recovery::CONNECTION_RECOVERY_ALPN.to_vec(),
        crate::network_recovery::RECOVERY_REPLICA_ALPN.to_vec(),
        crate::management_recovery::MANAGEMENT_RECOVERY_ALPN.to_vec(),
        crate::admission_rotation::ADMISSION_ROTATION_ALPN.to_vec(),
        crate::admission_rotation::ROTATION_DELIVERY_ALPN.to_vec(),
    ]
}

enum Initialization<'a> {
    Create,
    Join(ManualInvitation),
    Migration(ManualInvitation, &'a SigningKey),
    Recover(&'a GenesisCredential, iroh_base::EndpointId),
}

struct SavedAnchor([u8; 64]);

impl SavedAnchor {
    fn encode(anchor: NetworkAnchor) -> Self {
        let mut bytes = [0; 64];
        bytes[..32].copy_from_slice(anchor.root.as_bytes());
        bytes[32..].copy_from_slice(anchor.genesis.as_bytes());
        Self(bytes)
    }

    fn decode(self) -> Result<NetworkAnchor, NodeError> {
        Ok(NetworkAnchor {
            root: VerifyingKey::from_bytes(self.0[..32].try_into().unwrap())
                .map_err(|_| NodeError::InvalidData)?,
            genesis: Hash::from_bytes(self.0[32..].try_into().unwrap()),
        })
    }
}

struct SavedGenesisCredential([u8; 64]);

impl SavedGenesisCredential {
    fn encode(root: &SigningKey, genesis: Hash) -> Self {
        let mut bytes = [0; 64];
        bytes[..32].copy_from_slice(root.as_bytes());
        bytes[32..].copy_from_slice(genesis.as_bytes());
        Self(bytes)
    }

    fn decode(self) -> GenesisCredential {
        GenesisCredential::from_saved(
            self.0[..32].try_into().unwrap(),
            Hash::from_bytes(self.0[32..].try_into().unwrap()),
        )
    }
}

#[derive(Debug, Error)]
pub enum NodeError {
    #[error("this directory is owned by NetworkMigration; reopen its lifecycle entry")]
    MigrationManaged,
    #[error("node data directory already exists")]
    AlreadyExists,
    #[error("node data is incomplete or invalid")]
    InvalidData,
    #[error("genesis credential does not match the pinned network anchor")]
    InvalidCredential,
    #[error("signed management record has not been applied")]
    NotApplied,
    #[error("atomic network directory publication is unavailable on this Unix target")]
    UnsupportedAtomicPublication,
    #[error("node file operation failed: {0}")]
    Io(#[from] std::io::Error),
    #[error("management state failed: {0}")]
    Store(#[from] StoreError),
    #[error("endpoint failed: {0}")]
    Endpoint(#[from] iroh::endpoint::BindError),
}

/// Public, secret-free view obtained only after replaying the signed history.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NodeStatus {
    pub node_id: VerifyingKey,
    pub anchor: NetworkAnchor,
    pub members: Vec<(VerifyingKey, Access)>,
    pub applied_count: i64,
}

/// One verified local network. No secret-bearing type implements `Debug` here.
pub struct NativeNetwork {
    pub(crate) node_key: SigningKey,
    pub(crate) anchor: NetworkAnchor,
    pub(crate) store: ManagementStore,
    pub(crate) gate: AdmissionGate,
    pub(crate) scope: AdmissionScope,
    pub(crate) secret: Option<AdmissionSecret>,
    pub(crate) join: Option<JoinBinding>,
    pub(crate) recovery: Option<RecoveryBinding>,
    pub(crate) management_instance: [u8; 16],
    pub(crate) directory: PathBuf,
    udp: Arc<NatConnector>,
}

impl NativeNetwork {
    /// Create a fresh network and device in a new directory. Publishing the
    /// prepared directory is the final step, so readers never see half a Create.
    pub async fn create(path: impl AsRef<Path>) -> Result<Self, NodeError> {
        Self::initialize(path.as_ref(), Initialization::Create).await
    }

    /// Initialize an independently identified applicant. The trusted invitation
    /// pins its network and contact, but grants no membership or shared secret.
    pub async fn join(
        path: impl AsRef<Path>,
        invitation: ManualInvitation,
    ) -> Result<Self, NodeError> {
        Self::initialize(path.as_ref(), Initialization::Join(invitation)).await
    }

    /// Prepare a new independent device using the trusted original root-key
    /// and canonical Create backup. This stores no history or admission secret
    /// and grants no access. `restore_management` proves root authority to the
    /// chosen contact over the restricted TLS session; no approval is needed.
    pub async fn recover(
        path: impl AsRef<Path>,
        credential: &GenesisCredential,
        contact: iroh_base::EndpointId,
    ) -> Result<Self, NodeError> {
        Self::initialize(path.as_ref(), Initialization::Recover(credential, contact)).await
    }

    async fn initialize(
        path: &Path,
        initialization: Initialization<'_>,
    ) -> Result<Self, NodeError> {
        let path = path.as_ref();
        ensure_absent(path)?;
        let parent = match path.parent() {
            Some(parent) if !parent.as_os_str().is_empty() => parent,
            _ => Path::new("."),
        };
        fs::create_dir_all(parent)?;
        let staging = parent.join(format!(".miopunch-create-{:032x}", rand::random::<u128>()));
        let mut builder = fs::DirBuilder::new();
        #[cfg(unix)]
        builder.mode(0o700);
        builder.create(&staging)?;
        let prepared = match initialization {
            Initialization::Create => Self::prepare(&staging).await,
            Initialization::Join(invitation) => {
                Self::prepare_join(&staging, invitation, &SigningKey::generate()).await
            }
            Initialization::Migration(invitation, key) => {
                match Self::prepare_join(&staging, invitation, key).await {
                    Ok(()) => write_private(&staging.join("migration.managed"), b"1")
                        .and_then(|_| sync_directory(&staging).map_err(NodeError::from)),
                    Err(error) => Err(error),
                }
            }
            Initialization::Recover(credential, contact) => {
                Self::prepare_recovery(&staging, credential, contact).await
            }
        };
        if let Err(error) = prepared {
            let _ = fs::remove_dir_all(&staging);
            return Err(error);
        }
        if let Err(error) = ensure_absent(path) {
            let _ = fs::remove_dir_all(&staging);
            return Err(error);
        }
        if let Err(error) = publish_new_directory(&staging, path, parent) {
            let _ = fs::remove_dir_all(&staging);
            return Err(error);
        }
        sync_directory(parent)?;
        Self::open_migration_context(path).await
    }

    async fn prepare_recovery(
        path: &Path,
        credential: &GenesisCredential,
        contact: iroh_base::EndpointId,
    ) -> Result<(), NodeError> {
        let key = SigningKey::generate();
        let anchor = credential.anchor();
        let binding = RecoveryBinding {
            contact,
            attempt: rand::random(),
        };
        write_private(&path.join(NODE_KEY), key.as_bytes())?;
        write_private(&path.join(ANCHOR), &SavedAnchor::encode(anchor).0)?;
        write_private(
            &path.join(GENESIS_CREDENTIAL),
            &SavedGenesisCredential::encode(&credential.root, anchor.genesis).0,
        )?;
        write_private(&path.join(RECOVERY_BINDING), &binding.encode())?;
        let store = ManagementStore::open(path.join(MANAGEMENT_DB), anchor).await?;
        store.close().await;
        sync_directory(path)?;
        Ok(())
    }

    async fn prepare_join(
        path: &Path,
        invitation: ManualInvitation,
        key: &SigningKey,
    ) -> Result<(), NodeError> {
        let binding = JoinBinding {
            invitation,
            request_id: rand::random(),
        };
        write_private(&path.join(NODE_KEY), key.as_bytes())?;
        write_private(
            &path.join(ANCHOR),
            &SavedAnchor::encode(invitation.anchor).0,
        )?;
        write_private(&path.join(JOIN_BINDING), &binding.encode())?;
        let store = ManagementStore::open(path.join(MANAGEMENT_DB), invitation.anchor).await?;
        store.close().await;
        sync_directory(path)?;
        Ok(())
    }

    async fn prepare(path: &Path) -> Result<(), NodeError> {
        let node_key = SigningKey::generate();
        let root = SigningKey::generate();
        let admission_secret = AdmissionSecret::generate();
        let header = Header::<ManagementExtension>::builder()
            .build(
                &root,
                ManagementExtension {
                    version: 1,
                    log_id: rand::random(),
                    group: GroupsExtensionArgs {
                        group_id: root.verifying_key(),
                        action: GroupAction::Create {
                            initial_members: vec![
                                (
                                    GroupMember::Individual(root.verifying_key()),
                                    Access::manage(),
                                ),
                                (
                                    GroupMember::Individual(node_key.verifying_key()),
                                    Access::manage(),
                                ),
                            ],
                        },
                        dependencies: vec![],
                    },
                },
            )
            .encode();
        let anchor = NetworkAnchor {
            root: root.verifying_key(),
            genesis: Hash::digest(&header),
        };
        write_private(&path.join(NODE_KEY), node_key.as_bytes())?;
        write_private(
            &path.join(GENESIS_CREDENTIAL),
            &SavedGenesisCredential::encode(&root, anchor.genesis).0,
        )?;
        write_private(&path.join(ANCHOR), &SavedAnchor::encode(anchor).0)?;
        write_private(&path.join(ADMISSION_SECRET), admission_secret.saved_bytes())?;
        let mut store = ManagementStore::open(path.join(MANAGEMENT_DB), anchor).await?;
        let create = ManagementRecord::new(header, None);
        store.ingest(&create).await?;
        if store.apply_ready().await? != 1
            || store.nodes() != vec![(node_key.verifying_key(), Access::manage())]
        {
            return Err(NodeError::InvalidData);
        }
        store
            .set_current_admission(
                &AdmissionScope::new(*anchor.root.as_bytes(), 0),
                &admission_secret,
            )
            .await?;
        store.close().await;
        sync_directory(path)?;
        Ok(())
    }

    /// Replay a created network or an applicant's durable progress. Creators
    /// pin the Create with their private recovery credential; applicants use
    /// their trusted invitation and do not become successful members early.
    /// Capture a coherent, trusted local backup after stopping this node.
    /// Callers must close their bound endpoints and avoid concurrently opening
    /// the same data directory. This consumes the node and closes SQLite before
    /// copying its checkpointed main database and private durable materials.
    pub async fn create_backup(self, target: impl AsRef<Path>) -> Result<(), NodeError> {
        let source = self.directory.clone();
        self.store.checkpoint_backup().await?;
        self.close().await;
        copy_node_backup(&source, target.as_ref(), false).await
    }

    /// Restore into a new directory, never over a running node. The trusted
    /// backup may predate consumption, so every restored code is stopped before
    /// atomic publication. This explicit recovery event supplies the boundary;
    /// no flag inside a rolled-back database proves counter continuity. Fresh
    /// codes can be issued normally. Undisclosed whole-disk rollback detection
    /// is intentionally not claimed.
    pub async fn restore_backup(
        backup: impl AsRef<Path>,
        target: impl AsRef<Path>,
    ) -> Result<Self, NodeError> {
        if fs::read(backup.as_ref().join("backup.version"))? != b"miopunch node backup 1\n" {
            return Err(NodeError::InvalidData);
        }
        copy_node_backup(backup.as_ref(), target.as_ref(), true).await?;
        Self::open(target).await
    }

    pub async fn open(path: impl AsRef<Path>) -> Result<Self, NodeError> {
        let path = path.as_ref();
        if path.join("migration.invitation").exists() || path.join("migration.managed").exists() {
            return Err(NodeError::MigrationManaged);
        }
        Self::open_migration_context(path).await
    }

    pub(crate) async fn join_migration(
        path: &Path,
        invitation: ManualInvitation,
        key: &SigningKey,
    ) -> Result<Self, NodeError> {
        Self::initialize(path, Initialization::Migration(invitation, key)).await
    }

    pub(crate) async fn open_migration_context(path: &Path) -> Result<Self, NodeError> {
        let node_key = SigningKey::from_bytes(&read_array::<32>(&path.join(NODE_KEY))?);
        let anchor = SavedAnchor(read_array::<64>(&path.join(ANCHOR))?).decode()?;
        let join = if path.join(JOIN_BINDING).exists() {
            let binding = JoinBinding::decode(&read_array::<112>(&path.join(JOIN_BINDING))?)
                .map_err(|_| NodeError::InvalidData)?;
            if binding.invitation.anchor != anchor {
                return Err(NodeError::InvalidData);
            }
            Some(binding)
        } else {
            None
        };
        let recovery = if path.join(RECOVERY_BINDING).exists() {
            Some(RecoveryBinding::decode(&read_array::<48>(
                &path.join(RECOVERY_BINDING),
            )?)?)
        } else {
            None
        };
        if recovery.is_some() && !path.join(GENESIS_CREDENTIAL).exists() {
            return Err(NodeError::InvalidData);
        }
        if path.join(GENESIS_CREDENTIAL).exists() {
            let credential =
                SavedGenesisCredential(read_array::<64>(&path.join(GENESIS_CREDENTIAL))?).decode();
            if credential.anchor() != anchor {
                return Err(NodeError::InvalidCredential);
            }
        } else if join.is_none() {
            return Err(NodeError::InvalidData);
        }
        if !path.join(MANAGEMENT_DB).is_file() {
            return Err(NodeError::InvalidData);
        }
        let mut store = ManagementStore::open(path.join(MANAGEMENT_DB), anchor).await?;
        // Approval's Add/result can have committed before process exit without
        // its materialized view. Recover ready records before exposing the
        // reopened node's authority or making admission decisions.
        store.apply_ready().await?;
        crate::admission_rotation::recover_rotation_material(&mut store, path).await?;
        if path.join(GENESIS_CREDENTIAL).exists()
            && recovery.is_none()
            && store.get_record(anchor.genesis).await?.is_none()
        {
            return Err(NodeError::InvalidData);
        }
        let (scope, mut secret) = if path.join(ADMISSION_MATERIAL).exists() {
            let bytes = read_array::<40>(&path.join(ADMISSION_MATERIAL))?;
            (
                AdmissionScope::new(
                    *anchor.root.as_bytes(),
                    u64::from_be_bytes(bytes[..8].try_into().unwrap()),
                ),
                Some(AdmissionSecret::from_saved(bytes[8..].try_into().unwrap())),
            )
        } else if path.join(ADMISSION_SECRET).exists() {
            (
                AdmissionScope::new(*anchor.root.as_bytes(), 0),
                Some(AdmissionSecret::from_saved(read_array::<32>(
                    &path.join(ADMISSION_SECRET),
                )?)),
            )
        } else if join.is_some() || recovery.is_some() {
            (AdmissionScope::new(*anchor.root.as_bytes(), 0), None)
        } else {
            return Err(NodeError::InvalidData);
        };
        if let Some(material) = &secret {
            if !store
                .current_admission_matches(&scope, &material.fingerprint(&scope))
                .await?
            {
                if join.is_none() && recovery.is_none() {
                    return Err(NodeError::InvalidData);
                }
                // A crash between private-file fsync and database commit is
                // still pending. A retry must pin the credential before use.
                secret = None;
            }
        }
        if let Some(binding) = join {
            if store
                .expected_admission_generation(binding.request_id)
                .await?
                .is_some_and(|generation| generation > scope.secret_generation())
            {
                secret = None;
            }
        }
        let node_id = SecretKey::from_bytes(node_key.as_bytes()).public();
        let gate = AdmissionGate::new(node_id, scope.clone(), secret.clone());
        gate.register_p2panda_defaults(*anchor.root.as_bytes());
        gate.update_authorization(
            store.nodes().into_iter().map(|(id, _)| *id.as_bytes()),
            store.removed_nodes().into_iter().map(|id| *id.as_bytes()),
        );
        let mut node = Self {
            node_key,
            anchor,
            store,
            gate,
            scope,
            secret,
            join,
            recovery,
            management_instance: rand::random(),
            directory: path.to_path_buf(),
            udp: Arc::new(NatConnector::new(None, UdpPolicy::default())),
        };
        node.restore_rotation_gate().await?;
        if node.join.is_some() {
            if let Some(binding) = node.recovery {
                if !node.has_completed_root_recovery(binding).await? {
                    return Err(NodeError::InvalidData);
                }
                // A single fsynced join-binding publication selects the new
                // active lifecycle. Keep the old signed recovery history and
                // binding as inert audit material, without two active flows.
                node.recovery = None;
            }
        }
        Ok(node)
    }

    pub fn status(&self) -> NodeStatus {
        let mut members = self.store.nodes();
        members.sort_by_key(|(id, _)| *id.as_bytes());
        NodeStatus {
            node_id: self.node_key.verifying_key(),
            anchor: self.anchor,
            members,
            applied_count: self.store.applied_count(),
        }
    }

    /// Bind only after loading the durable device key; the endpoint can never
    /// silently generate a new identity on process restart.
    pub async fn bind_endpoint(&self, bind_ip: Ipv4Addr) -> Result<Endpoint, NodeError> {
        self.bind_endpoint_with(
            Endpoint::builder(presets::Minimal)
                .alpns(network_protocols())
                .bind_addr(SocketAddr::from((bind_ip, 0)))
                .map_err(|_| NodeError::InvalidData)?,
        )
        .await
    }

    /// Configure allowed resources/carriers and advertised protocols through
    /// the selected stack. The node installs its durable identity and shared
    /// gate last, so carrier configuration cannot substitute either boundary.
    pub async fn bind_endpoint_with(&self, builder: Builder) -> Result<Endpoint, NodeError> {
        let resources = self.resource_configuration()?;
        self.bind_endpoint_with_resources(
            builder,
            &resources,
            false,
            #[cfg(feature = "rtc-probe")]
            None,
            None,
        )
        .await
        .map(|(endpoint, _, _, _)| endpoint)
    }

    async fn bind_endpoint_with_resources(
        &self,
        builder: Builder,
        resources: &crate::resources::ResourceConfig,
        configured_startup: bool,
        #[cfg(feature = "rtc-probe")] rtc: Option<crate::rtc_transport::RtcTransport>,
        contact_override: Option<Arc<crate::mqtt_transport::MqttTransport>>,
    ) -> Result<
        (
            Endpoint,
            Option<crate::tcp_transport::TcpTransport>,
            Vec<Arc<crate::mqtt_transport::MqttTransport>>,
            Option<crate::contact_listener::ContactListenerControl>,
        ),
        NodeError,
    > {
        resources.validate_mqtt_facilities()?;
        #[cfg(feature = "rtc-probe")]
        if let Some(rtc) = &rtc {
            let disabled: Vec<_> = resources
                .disabled
                .iter()
                .filter(|(_, purpose)| *purpose == crate::resources::ResourceUse::Observation)
                .map(|(url, _)| url.clone())
                .collect();
            rtc.ice_profile().check_allowed(&disabled)?;
            if rtc
                .ice_profile()
                .observation_resources()?
                .iter()
                .any(|url| !resources.allows(url, crate::resources::ResourceUse::Observation))
            {
                return Err(std::io::Error::new(
                    std::io::ErrorKind::PermissionDenied,
                    "RTC observer is not approved by saved resources",
                )
                .into());
            }
        }
        #[cfg(feature = "rtc-probe")]
        let builder = if let Some(rtc) = &rtc {
            self.gate
                .register_data_carrier(crate::rtc_transport::TRANSPORT_ID);
            builder.add_custom_transport(Arc::new(rtc.clone()))
        } else {
            builder
        };
        #[cfg(feature = "rtc-probe")]
        let rtc_installed = rtc.is_some();
        #[cfg(not(feature = "rtc-probe"))]
        let rtc_installed = false;
        let (mut builder, tcp) = resources.configure_with_tcp_and_rtc(builder, rtc_installed)?;
        if !resources.member_data_relay_disabled
            && !resources
                .disabled_uses
                .contains(&crate::resources::ResourceUse::DataRelay)
        {
            self.gate
                .register_data_carrier(crate::member_transport::DATA_TRANSPORT_ID);
        }
        let mut mqtt = Vec::new();
        let mut contact_listener = None;
        let mut irc = Vec::new();
        if configured_startup {
            let selected = if let Some(transport) = contact_override {
                let (resource, usage) =
                    iroh::endpoint::transports::CustomTransport::resource(transport.as_ref())
                        .ok_or_else(|| {
                            std::io::Error::other("contact resource descriptor absent")
                        })?;
                let mapping_allowed = if let Some(facility) = transport.facility() {
                    resources
                        .allowed_mqtt_facilities()
                        .iter()
                        .any(|saved| saved.validate().is_ok_and(|saved| &saved == facility))
                } else {
                    // Raw legacy contacts retain their explicit URL policy only
                    // for unmapped resources; they cannot borrow a facility's
                    // logical-ID/WSS consent from its shared native URL.
                    !resources.mqtt_facilities.iter().any(|facility| {
                        facility
                            .native_url
                            .parse::<iroh::RelayUrl>()
                            .is_ok_and(|url| url == resource)
                    })
                };
                if !matches!(usage, iroh::endpoint::RelayResourceUse::Signaling)
                    || !resources
                        .allows(resource.as_str(), crate::resources::ResourceUse::Signaling)
                    || !mapping_allowed
                {
                    return Err(std::io::Error::new(
                        std::io::ErrorKind::PermissionDenied,
                        "explicit contact resource denied",
                    )
                    .into());
                }
                Some(transport)
            } else if let Some(facility) = resources.allowed_mqtt_facilities().first() {
                Some(Arc::new(
                    crate::mqtt_transport::MqttTransport::from_facility(
                        facility,
                        &[],
                        Arc::new(crate::mqtt_transport::Traffic::default()),
                        None,
                    )?,
                ))
            } else if let Some(resource) = resources.mqtt_resources().iter().find(|resource| {
                !resources.mqtt_facilities.iter().any(|facility| {
                    facility
                        .native_url
                        .parse::<iroh::RelayUrl>()
                        .is_ok_and(|url| &url == *resource)
                })
            }) {
                Some(Arc::new(
                    crate::mqtt_transport::MqttTransport::from_resource(
                        resource.clone(),
                        Arc::new(crate::mqtt_transport::Traffic::default()),
                    )?,
                ))
            } else {
                None
            };
            if let Some(transport) = selected {
                let listener = crate::contact_listener::ContactListener::new(transport.clone());
                contact_listener = Some(listener.control());
                builder = builder.add_custom_transport(Arc::new(listener));
                mqtt.push(transport);
            }
            for resource in resources.irc_resources() {
                let transport =
                    Arc::new(crate::irc_transport::IrcTransport::from_resource(resource)?);
                builder = builder.add_custom_transport(transport.clone());
                irc.push(transport);
            }
        }
        let builder = if configured_startup
            && !irc.is_empty()
            && mqtt.is_empty()
            && !rtc_installed
            && resources.udp_direct_disabled
            && resources.tcp_direct_disabled
            && (resources.member_data_relay_disabled
                || resources.disabled_uses.contains(&crate::resources::ResourceUse::DataRelay))
            && resources.relay_map(crate::resources::ResourceUse::DataRelay)?.is_empty()
        {
            builder.active_connection_id_limit(2)
        } else {
            builder
        };
        let builder = match resources.lan_discovery {
            crate::resources::LanDiscovery::Disabled => builder,
            mode => builder.address_lookup(
                iroh_mdns_address_lookup::MdnsAddressLookup::builder()
                    .advertise(mode == crate::resources::LanDiscovery::Active)
                    .service_name("miopunchv1"),
            ),
        };
        for alpn in [
            crate::connection_coordinator::MEMBER_ALPN,
            crate::connection_coordinator::REPLICA_ALPN,
        ] {
            self.gate
                .register_protocol(alpn, crate::admission_gate::ProtocolScope::Member);
        }
        let observers = resources.relay_map(crate::resources::ResourceUse::Observation)?;
        let native_udp = Arc::new(self.udp.for_endpoint(
            (!observers.is_empty()).then_some(observers),
            resources.udp_stun_resources(),
            !resources.udp_direct_disabled,
        ));
        let native_tcp = tcp.clone().map(|transport| {
            crate::tcp_punch::TcpPunch::new(
                transport,
                resources.tcp_stun_resources(),
                resources.clone(),
            )
        });
        let coordinator = crate::connection_coordinator::CoordinatorHook::new(
            self.gate.clone(),
            !resources.udp_direct_disabled,
        )
        .with_resources(resources.clone())
        .with_relay(
            !resources
                .relay_map(crate::resources::ResourceUse::DataRelay)?
                .is_empty(),
        )
        .with_native(crate::native_path_adapter::NativePathAdapter::new(
            native_udp.clone(),
            native_tcp.clone(),
        ));
        #[cfg(feature = "rtc-probe")]
        let coordinator = coordinator.with_rtc(rtc.clone());
        let gate = self.gate.with_request_coordinator();
        let builder = if configured_startup {
            let existing_data = crate::message_bootstrap::ExistingMemberDataRelease::new(
                self.gate.clone(),
                native_tcp
                    .filter(|tcp| !tcp.observers.is_empty() && tcp.transport.supports_punching()),
            );
            gate.with_message_bootstrap()
                .configure(builder)
                .hooks(coordinator)
                .hooks(existing_data)
        } else {
            gate.configure(builder).hooks(coordinator)
        };
        let endpoint = builder
            .secret_key(SecretKey::from_bytes(self.node_key.as_bytes()))
            .bind()
            .await?;
        // Poll all approved services within the adapter's shared startup bound.
        // A failed subscription cannot prevent another resource or direct path.
        for result in
            futures_util::future::join_all(mqtt.iter().map(|mqtt| mqtt.wait_ready())).await
        {
            if let Err(error) = result {
                eprintln!("MQTT_RESOURCE_UNAVAILABLE error={error}");
            }
        }
        for result in futures_util::future::join_all(irc.iter().map(|irc| irc.wait_ready())).await {
            if let Err(error) = result {
                eprintln!("IRC_RESOURCE_UNAVAILABLE error={error}");
            }
        }
        Ok((endpoint, tcp, mqtt, contact_listener))
    }

    pub fn resource_configuration(&self) -> Result<crate::resources::ResourceConfig, NodeError> {
        Ok(crate::resources::ResourceConfig::load(
            &self.directory.join(RESOURCE_CONFIGURATION),
        )?)
    }

    pub(crate) fn saved_maintenance_contacts(&self) -> Result<Vec<iroh::EndpointAddr>, NodeError> {
        let bytes = match std::fs::read(self.directory.join(MAINTENANCE_CONTACTS)) {
            Ok(bytes) => bytes,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
            Err(error) => return Err(error.into()),
        };
        if bytes.len() > 64 * 1024 {
            return Err(NodeError::InvalidData);
        }
        let contacts: Vec<iroh::EndpointAddr> =
            serde_json::from_slice(&bytes).map_err(|_| NodeError::InvalidData)?;
        if contacts.len() > 64 || contacts.iter().any(|contact| contact.addrs.len() > 8) {
            return Err(NodeError::InvalidData);
        }
        Ok(contacts)
    }

    pub(crate) fn save_maintenance_contacts(
        &self,
        contacts: &[iroh::EndpointAddr],
    ) -> Result<(), NodeError> {
        let temporary = self
            .directory
            .join(format!(".contacts-{:032x}", rand::random::<u128>()));
        let result = (|| {
            let bytes = serde_json::to_vec(contacts).map_err(std::io::Error::other)?;
            if contacts.len() > 64 || bytes.len() > 64 * 1024 {
                return Err(NodeError::InvalidData);
            }
            write_private(&temporary, &bytes)?;
            replace_file(&temporary, &self.directory.join(MAINTENANCE_CONTACTS))?;
            sync_directory(&self.directory)?;
            Ok(())
        })();
        let _ = fs::remove_file(temporary);
        result
    }

    /// Atomically save configuration for the next endpoint start. Existing
    /// endpoints retain their startup snapshot; this is not a hot update.
    pub fn save_resource_configuration(
        &self,
        config: &crate::resources::ResourceConfig,
    ) -> Result<(), NodeError> {
        config.validate_mqtt_facilities()?;
        let temporary = self
            .directory
            .join(format!(".resources-{:032x}", rand::random::<u128>()));
        let result = (|| {
            write_private(
                &temporary,
                &serde_json::to_vec(config).map_err(std::io::Error::other)?,
            )?;
            replace_file(&temporary, &self.directory.join(RESOURCE_CONFIGURATION))?;
            sync_directory(&self.directory)?;
            Ok::<_, NodeError>(())
        })();
        let _ = fs::remove_file(temporary);
        result
    }

    /// Normal client startup uses bundled defaults or the saved local replacement.
    pub async fn bind_configured_endpoint(
        &self,
        bind_ip: Ipv4Addr,
    ) -> Result<crate::resources::ResourceEndpoint, NodeError> {
        self.bind_configured_endpoint_with(
            Endpoint::builder(presets::Minimal)
                .bind_addr(SocketAddr::from((bind_ip, 0)))
                .map_err(|_| NodeError::InvalidData)?,
        )
        .await
    }

    /// The formal startup with advanced local socket/TLS settings. Saved
    /// resource consent, durable identity and member bootstrap remain owned by
    /// this assembly rather than by the caller's stream or synchronization code.
    pub async fn bind_configured_endpoint_with(
        &self,
        builder: Builder,
    ) -> Result<crate::resources::ResourceEndpoint, NodeError> {
        self.bind_configured_endpoint_with_options(
            builder,
            #[cfg(feature = "rtc-probe")]
            None,
            None,
        )
        .await
    }

    /// Experimental installed RTC adapter; the saved resource assembly and
    /// original admission gate still own all member connection decisions.
    #[cfg(feature = "rtc-probe")]
    pub async fn bind_configured_endpoint_with_rtc(
        &self,
        builder: Builder,
        rtc: crate::rtc_transport::RtcTransport,
    ) -> Result<crate::resources::ResourceEndpoint, NodeError> {
        self.bind_configured_endpoint_with_options(builder, Some(rtc), None)
            .await
    }

    /// Explicit local contact IO settings (for example a controlled CA), still
    /// checked against the node resource policy and owned by its listener.
    pub async fn bind_configured_endpoint_with_contact(
        &self,
        builder: Builder,
        contact: Arc<crate::mqtt_transport::MqttTransport>,
    ) -> Result<crate::resources::ResourceEndpoint, NodeError> {
        self.bind_configured_endpoint_with_options(
            builder,
            #[cfg(feature = "rtc-probe")]
            None,
            Some(contact),
        )
        .await
    }
    #[cfg(feature = "rtc-probe")]
    pub async fn bind_configured_endpoint_with_rtc_and_contact(
        &self,
        builder: Builder,
        rtc: crate::rtc_transport::RtcTransport,
        contact: Arc<crate::mqtt_transport::MqttTransport>,
    ) -> Result<crate::resources::ResourceEndpoint, NodeError> {
        self.bind_configured_endpoint_with_options(builder, Some(rtc), Some(contact))
            .await
    }

    async fn bind_configured_endpoint_with_options(
        &self,
        builder: Builder,
        #[cfg(feature = "rtc-probe")] rtc: Option<crate::rtc_transport::RtcTransport>,
        contact_override: Option<Arc<crate::mqtt_transport::MqttTransport>>,
    ) -> Result<crate::resources::ResourceEndpoint, NodeError> {
        let config = self.resource_configuration()?;
        let (endpoint, tcp, mqtt, contact_listener) = self
            .bind_endpoint_with_resources(
                builder
                    .alpns(network_protocols())
                    .relay_mode(iroh::RelayMode::Custom(
                        config.relay_map(crate::resources::ResourceUse::DataRelay)?,
                    ))
                    .observation_servers(
                        config.relay_map(crate::resources::ResourceUse::Observation)?,
                    ),
                &config,
                true,
                #[cfg(feature = "rtc-probe")]
                rtc.clone(),
                contact_override,
            )
            .await?;
        let resources = crate::resources::ResourceEndpoint::new(endpoint, config)
            .with_tcp(tcp)
            .with_mqtt(mqtt)
            .with_contact_listener(contact_listener);
        #[cfg(feature = "rtc-probe")]
        let resources = resources.with_rtc(rtc);
        let mut resources = resources;
        if !resources.recovery_origins().is_empty() {
            resources
                .endpoint()
                .address_lookup()
                .map_err(std::io::Error::other)?
                .add(resources.contacts.clone());
        }
        self.start_recovery_discovery(&mut resources).await;
        Ok(resources)
    }

    /// The same policy handle can be installed through p2panda's endpoint
    /// builder hook and used to classify any additional protocol ALPN.
    pub fn admission_gate(&self) -> AdmissionGate {
        self.gate.clone()
    }

    /// Supply the node's explicitly configured observation resources and UDP
    /// maintenance policy when reopening. The connector is retained by the
    /// node across connection attempts rather than recreated after failures.
    pub async fn open_with_udp_resources(
        path: impl AsRef<Path>,
        observers: Option<iroh::RelayMap>,
        policy: UdpPolicy,
    ) -> Result<Self, NodeError> {
        let mut node = Self::open(path).await?;
        node.udp = Arc::new(NatConnector::new(observers, policy));
        Ok(node)
    }

    pub fn udp_connector(&self) -> &NatConnector {
        &self.udp
    }

    /// Upgrade an admitted control session using direct candidates first, then
    /// a bounded sequence of complete automatically selected old UDP plans.
    pub async fn upgrade_udp(
        &self,
        control: crate::control_session::ControlSession,
    ) -> Result<UdpUpgrade, crate::control_session::CommitError> {
        self.udp.upgrade(control, &self.gate).await
    }

    /// Ingest and apply a complete signed management record through the same
    /// verifier used by replay. Rejected records cannot enter the public view.
    pub async fn ingest_management_record(
        &mut self,
        header: &[u8],
        body: Option<&[u8]>,
    ) -> Result<Hash, NodeError> {
        let id = self
            .store
            .ingest(&ManagementRecord::new(header.to_vec(), body))
            .await?;
        self.store.apply_ready().await?;
        if self.store.get_record(id).await?.is_none() {
            return Err(NodeError::NotApplied);
        }
        self.refresh_authorization();
        Ok(id)
    }

    pub(crate) fn refresh_authorization(&self) {
        self.gate.update_authorization(
            self.store.nodes().into_iter().map(|(id, _)| *id.as_bytes()),
            self.store
                .removed_nodes()
                .into_iter()
                .map(|id| *id.as_bytes()),
        );
    }

    /// Start a fresh approval attempt after effective departure/removal while
    /// preserving this device key, network anchor and all verified history.
    /// An old request keeps its old invalidated result; it is never repurposed.
    pub async fn begin_rejoin(&mut self, invitation: ManualInvitation) -> Result<(), NodeError> {
        self.store.ensure_admissions_open().await?;
        self.store.apply_ready().await?;
        self.refresh_authorization();
        if invitation.anchor != self.anchor
            || self
                .store
                .nodes()
                .iter()
                .any(|(id, _)| *id == self.node_key.verifying_key())
        {
            return Err(NodeError::InvalidData);
        }
        if let Some(binding) = self.recovery {
            if !self.has_completed_root_recovery(binding).await? {
                return Err(NodeError::InvalidData);
            }
            // Seal locally saved completion before publishing the ordinary
            // binding, including a prior exit just after secret pinning. A
            // crash between these writes leaves the old flow safely retryable.
            self.seal_completed_root_recovery(binding).await?;
            #[cfg(feature = "replica-test-hooks")]
            self.store
                .observe(crate::management_store::RecordCheckpoint::RecoveryRejoinPrepared);
        }
        let binding = JoinBinding {
            invitation,
            request_id: rand::random(),
        };
        self.persist_join_binding(binding)?;
        #[cfg(feature = "replica-test-hooks")]
        if self.recovery.is_some() {
            self.store
                .observe(crate::management_store::RecordCheckpoint::RecoveryRejoinPublished);
        }
        self.recovery = None;
        Ok(())
    }

    /// Continue incomplete admission with a trusted new code in this same
    /// canonical network. This only changes the delivery contact; actual TLS
    /// identity, code consumption and current signed membership are checked by
    /// the ordinary precode exchange. Repeating the same contact preserves the
    /// persisted attempt, including across reopen, rather than consuming again.
    pub async fn begin_precode_completion(
        &mut self,
        code: &crate::precode::Precode,
    ) -> Result<(), NodeError> {
        self.store.apply_ready().await?;
        self.refresh_authorization();
        self.store.ensure_admissions_open().await?;
        let previous = self.join.ok_or(NodeError::InvalidData)?;
        let invitation = code.invitation();
        if invitation.anchor != self.anchor {
            return Err(NodeError::InvalidData);
        }
        if previous.invitation == invitation {
            return Ok(());
        }
        if self.admission_stage() == crate::manual_admission::AdmissionStage::Complete {
            return Err(NodeError::InvalidData);
        }
        let binding = JoinBinding {
            invitation,
            request_id: previous.request_id,
        };
        self.persist_join_binding(binding)
    }

    fn persist_join_binding(&mut self, binding: JoinBinding) -> Result<(), NodeError> {
        let temporary = self
            .directory
            .join(format!(".join-binding-{:032x}", rand::random::<u128>()));
        let result = (|| {
            write_private(&temporary, &binding.encode())?;
            replace_file(&temporary, &self.directory.join(JOIN_BINDING))?;
            sync_directory(&self.directory)?;
            Ok::<_, NodeError>(())
        })();
        let _ = fs::remove_file(&temporary);
        result?;
        self.join = Some(binding);
        Ok(())
    }

    pub(crate) async fn save_admission_material(
        &mut self,
        scope: AdmissionScope,
        secret: AdmissionSecret,
    ) -> Result<(), NodeError> {
        self.store.ensure_admissions_open().await?;
        let mut bytes = [0; 40];
        bytes[..8].copy_from_slice(&scope.secret_generation().to_be_bytes());
        bytes[8..].copy_from_slice(secret.saved_bytes());
        let path = self.directory.join(ADMISSION_MATERIAL);
        if scope.secret_generation() < self.scope.secret_generation() {
            return Err(NodeError::InvalidData);
        }
        if path.exists() {
            let saved = read_array::<40>(&path)?;
            let old_generation = u64::from_be_bytes(saved[..8].try_into().unwrap());
            if old_generation > scope.secret_generation()
                || old_generation == scope.secret_generation() && saved != bytes
            {
                return Err(NodeError::InvalidData);
            }
            if old_generation < scope.secret_generation() {
                let temporary = self.directory.join(format!(
                    ".admission-material-{:032x}",
                    rand::random::<u128>()
                ));
                let result = (|| {
                    write_private(&temporary, &bytes)?;
                    replace_file(&temporary, &path)?;
                    Ok::<_, NodeError>(())
                })();
                let _ = fs::remove_file(&temporary);
                result?;
            }
        } else {
            // Publish a complete fsynced private file atomically. A process
            // exit during the write leaves only its unreferenced temp file.
            let temporary = self.directory.join(format!(
                ".admission-material-{:032x}",
                rand::random::<u128>()
            ));
            let result = (|| {
                write_private(&temporary, &bytes)?;
                publish_file(&temporary, &path)?;
                Ok::<_, NodeError>(())
            })();
            let _ = fs::remove_file(&temporary);
            result?;
        }
        // Also sync on retry: a previous process could have exited after
        // publishing the link but before making its directory entry durable.
        sync_directory(&self.directory)?;
        #[cfg(feature = "replica-test-hooks")]
        self.store
            .observe(crate::management_store::RecordCheckpoint::SecretFilePublished);
        self.store.set_current_admission(&scope, &secret).await?;
        self.gate.rotate_secret(scope.clone(), secret.clone());
        self.scope = scope;
        self.secret = Some(secret);
        self.refresh_authorization();
        Ok(())
    }

    /// Owned RTC qualification fault only. Installs a new active credential
    /// through the same durable material publication and store pin as delivery.
    /// This is not a rotation protocol or a retained-member acknowledgement.
    #[cfg(feature = "rtc-probe")]
    pub async fn invalidate_current_credential_fixture(&mut self) -> Result<u64, NodeError> {
        let generation = self
            .scope
            .secret_generation()
            .checked_add(1)
            .filter(|generation| *generation <= i64::MAX as u64)
            .ok_or(NodeError::InvalidData)?;
        let scope = AdmissionScope::new(*self.anchor.root.as_bytes(), generation);
        self.save_admission_material(scope, AdmissionSecret::generate())
            .await?;
        Ok(generation)
    }

    /// Secret-free readback from the node's actual active scope and durable pin.
    #[cfg(feature = "rtc-probe")]
    pub async fn credential_generation_fixture(&self) -> Result<(u64, bool), NodeError> {
        let current = match self.secret.as_ref() {
            Some(secret) => {
                self.store
                    .current_admission_matches(&self.scope, &secret.fingerprint(&self.scope))
                    .await?
            }
            None => false,
        };
        Ok((self.scope.secret_generation(), current))
    }

    pub(crate) fn saved_genesis_credential(&self) -> Result<GenesisCredential, NodeError> {
        let credential =
            SavedGenesisCredential(read_array::<64>(&self.directory.join(GENESIS_CREDENTIAL))?)
                .decode();
        if credential.anchor() != self.anchor {
            return Err(NodeError::InvalidCredential);
        }
        Ok(credential)
    }

    pub async fn close(self) {
        self.store.close().await;
    }
}

async fn copy_node_backup(source: &Path, target: &Path, restoring: bool) -> Result<(), NodeError> {
    ensure_absent(target)?;
    let parent = target
        .parent()
        .filter(|path| !path.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    fs::create_dir_all(parent)?;
    let staging = parent.join(format!(".miopunch-backup-{:032x}", rand::random::<u128>()));
    let mut builder = fs::DirBuilder::new();
    #[cfg(unix)]
    builder.mode(0o700);
    builder.create(&staging)?;
    let prepare = async {
        for name in [
            NODE_KEY,
            GENESIS_CREDENTIAL,
            ANCHOR,
            ADMISSION_SECRET,
            MANAGEMENT_DB,
            JOIN_BINDING,
            ADMISSION_MATERIAL,
            RECOVERY_BINDING,
            RESOURCE_CONFIGURATION,
        ] {
            let path = source.join(name);
            if path.exists() {
                write_private(&staging.join(name), &fs::read(path)?)?;
            }
        }
        // Rotation's staged private references must travel with this node's
        // database. Ignore unreferenced write temporaries and unrelated files.
        for entry in fs::read_dir(source)? {
            let entry = entry?;
            let name = entry.file_name();
            let Some(name) = name.to_str() else { continue };
            if name
                .strip_prefix("rotation.material.")
                .is_some_and(|suffix| suffix.len() == 16 && u64::from_str_radix(suffix, 16).is_ok())
            {
                write_private(&staging.join(name), &fs::read(entry.path())?)?;
            }
        }
        // Replay verifies the copied signed history/anchor/material before
        // publishing anything; restoration's stop is committed in this copy.
        let node = NativeNetwork::open(&staging).await?;
        if restoring {
            sqlx::query("UPDATE precodes SET stopped=1")
                .execute(&node.store.pool)
                .await
                .map_err(StoreError::from)?;
        } else {
            write_private(&staging.join("backup.version"), b"miopunch node backup 1\n")?;
        }
        node.close().await;
        sync_directory(&staging)?;
        ensure_absent(target)?;
        publish_new_directory(&staging, target, parent)?;
        sync_directory(parent)?;
        Ok::<_, NodeError>(())
    }
    .await;
    if prepare.is_err() {
        let _ = fs::remove_dir_all(&staging);
    }
    prepare
}

pub(crate) fn write_private(path: &Path, bytes: &[u8]) -> Result<(), NodeError> {
    let mut options = OpenOptions::new();
    options.write(true).create_new(true);
    #[cfg(unix)]
    options.mode(0o600);
    let mut file = options.open(path)?;
    file.write_all(bytes)?;
    file.sync_all()?;
    Ok(())
}

fn read_array<const N: usize>(path: &Path) -> Result<[u8; N], NodeError> {
    let bytes = fs::read(path)?;
    bytes.try_into().map_err(|_| NodeError::InvalidData)
}

fn ensure_absent(path: &Path) -> Result<(), NodeError> {
    match path.symlink_metadata() {
        Ok(_) => Err(NodeError::AlreadyExists),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error.into()),
    }
}

#[cfg(any(
    target_os = "linux",
    target_os = "android",
    target_os = "macos",
    target_os = "ios"
))]
fn publish_new_directory(staging: &Path, target: &Path, parent: &Path) -> Result<(), NodeError> {
    use rustix::fs::{RenameFlags, renameat_with};

    let parent_dir = fs::File::open(parent)?;
    let source = staging.file_name().ok_or(NodeError::InvalidData)?;
    let destination = target.file_name().ok_or(NodeError::InvalidData)?;
    renameat_with(
        &parent_dir,
        source,
        &parent_dir,
        destination,
        RenameFlags::NOREPLACE,
    )
    .map_err(|error| {
        if error == rustix::io::Errno::EXIST {
            NodeError::AlreadyExists
        } else {
            NodeError::Io(error.into())
        }
    })
}

#[cfg(all(
    unix,
    not(any(
        target_os = "linux",
        target_os = "android",
        target_os = "macos",
        target_os = "ios"
    ))
))]
fn publish_new_directory(_staging: &Path, _target: &Path, _parent: &Path) -> Result<(), NodeError> {
    Err(NodeError::UnsupportedAtomicPublication)
}

#[cfg(windows)]
fn publish_new_directory(staging: &Path, target: &Path, _parent: &Path) -> Result<(), NodeError> {
    crate::native_files::move_windows(staging, target, false).map_err(|error| {
        if error.kind() == std::io::ErrorKind::AlreadyExists {
            NodeError::AlreadyExists
        } else {
            NodeError::Io(error)
        }
    })
}

#[cfg(all(not(unix), not(windows)))]
fn publish_new_directory(staging: &Path, target: &Path, _parent: &Path) -> Result<(), NodeError> {
    fs::rename(staging, target)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    #[cfg(target_os = "linux")]
    #[test]
    fn publishing_never_replaces_an_existing_empty_directory() {
        let base = tempfile::tempdir().unwrap();
        let staging = base.path().join("staging");
        let target = base.path().join("target");
        std::fs::create_dir(&staging).unwrap();
        std::fs::create_dir(&target).unwrap();
        assert!(matches!(
            super::publish_new_directory(&staging, &target, base.path()),
            Err(super::NodeError::AlreadyExists)
        ));
        assert!(staging.is_dir());
        assert!(target.is_dir());
    }
}

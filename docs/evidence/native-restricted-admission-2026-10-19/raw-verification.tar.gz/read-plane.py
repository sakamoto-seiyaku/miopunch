import json,subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m93-20261018/plane')
b=['rtk','proxy','/home/js/.agents/skills/plane-ops/scripts/plane-ops.sh','--defaults','docs/agents/plane-defaults.json']
for name,args in [('items',['work-item','list','--json']),('states',['state','list','--json']),('members',['member','list','--json']),('m93',['work-item','get','MIOPUNCH-93','--json']),('m94',['work-item','get','MIOPUNCH-94','--json']),('m91',['work-item','get','MIOPUNCH-91','--json'])]:
 r=subprocess.run(b+args,capture_output=True,text=True);assert r.returncode==0,r.stderr;data=json.loads(r.stdout);(H/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(name+' saved',flush=True)
for name in ['m93','m94']:
 d=json.loads((H/(name+'.json')).read_text());r=subprocess.run(b+['work-item','relations','list',d['id'],'--json'],capture_output=True,text=True);assert r.returncode==0,r.stderr;(H/(name+'-relations.json')).write_text(r.stdout)
 r=subprocess.run(b+['work-item','comments','list',d['id'],'--json'],capture_output=True,text=True);assert r.returncode==0,r.stderr;(H/(name+'-comments.json')).write_text(r.stdout)
 print(name+' relations/comments saved',flush=True)

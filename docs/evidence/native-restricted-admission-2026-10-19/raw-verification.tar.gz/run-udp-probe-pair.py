import argparse,hashlib,importlib.util,json,os,re,signal,socket,subprocess,sys,time
from pathlib import Path
H=Path('/tmp/miopunch-m93-20261018');ROOT=Path('/home/js/Git/miopunch')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
U=Path('/tmp/mio81-final-peer-assertion-sdk-root-20261007/build-current-sdk.py')
assert sha(U)=='2b7e969a1f90fc93eacc80d8b62890f0bb0ef8f40dc140d9398ef1a6029671e1'
spec=importlib.util.spec_from_file_location('capture_probe_pair',U);sdk=importlib.util.module_from_spec(spec);sys.modules[spec.name]=sdk;spec.loader.exec_module(sdk)
p=argparse.ArgumentParser();p.add_argument('build');p.add_argument('name');p.add_argument('strategy',choices=['formal','coordinated','baseline']);a=p.parse_args()
b=H/a.build;context=json.loads((H/(a.build+'-context.json')).read_text());build=json.loads((b/'receipt.json').read_text())
def guard():
 assert build['exit']==0 and build['sourceFrozenDuringBuild'] and build['qualifiedForFrozenRun']
 assert sdk.current_sources()==context['sources'] and sdk.tool_snapshot()==context['tools']
 for group in ['fixedInputs','selectorPins','artifactPins']:
  assert all(sha(p)==d for p,d in context[group].items())
 assert all(sha(p)==d for p,d in build['artifacts'].items())
def call(args):return subprocess.run(['rtk','proxy',*map(str,args)],capture_output=True,text=True,check=True)
out=H/a.name;out.mkdir();guard()
service='mio93-'+a.name;processes=[];files=[];report={'exit':1,'forcedTermination':False,'processes':[],'preconditionsPassed':True,'scope':'local cross-process MQTT/QAD; no NAT-rate claim'}
def spawn(label,command,env=None):
 stdout=(out/(label+'.stdout.log')).open('w');stderr=(out/(label+'.stderr.log')).open('w');files.extend([stdout,stderr])
 child=subprocess.Popen(list(map(str,command)),stdout=stdout,stderr=stderr,env=env,cwd=ROOT);processes.append((label,child));return child
def wait_log(label,pattern,child,seconds=8):
 deadline=time.monotonic()+seconds
 while True:
  text=(out/(label+'.stdout.log')).read_text();m=re.search(pattern,text)
  if m:return m
  assert child.poll() is None,'process ended before readiness: '+label
  assert time.monotonic()<deadline,'readiness timeout: '+label
  time.sleep(.02)
started=time.monotonic();container=None;qad=None
try:
 image=json.loads(call(['docker','image','inspect','eclipse-mosquitto:2']).stdout)[0]['Id']
 container=call(['docker','run','--pull=never','-d','--name',service,'--label','miopunch.task=M93','-p','127.0.0.1::1883','--tmpfs','/mosquitto/data','--tmpfs','/mosquitto/log','-v',str(H/'mosquitto.conf')+':/mosquitto/config/mosquitto.conf:ro',image]).stdout.strip()
 info=json.loads(call(['docker','inspect',container]).stdout)[0];assert not any(m['Type']=='volume' for m in info['Mounts'])
 port=int(info['NetworkSettings']['Ports']['1883/tcp'][0]['HostPort']);broker='127.0.0.1:'+str(port)
 deadline=time.monotonic()+5
 while True:
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=.2):break
  except OSError:assert time.monotonic()<deadline;time.sleep(.03)
 probe=b/'pinned/udp_nat_probe';observer=b/'pinned/udp_observation_probe';cert=out/'qad.der'
 qad=spawn('qad',[observer,'serve',cert,'127.0.0.1:0']);qport=wait_log('qad',r'QAD_READY 127.0.0.1:(\d+)',qad)[1]
 identities={}
 for name in ['client','server']:
  result=call([probe,'identity',out/(name+'.key')]);identities[name]=result.stdout.strip();report[name+'IdentityExit']=result.returncode
 env=os.environ.copy();env['MIOPUNCH_NAT_STRATEGY']=a.strategy
 if a.strategy!='baseline':
  (out/'secret').write_bytes(bytes([42])*32);env['MIOPUNCH_NAT_SECRET_FILE']=str(out/'secret')
 server=spawn('server',[probe,'server',out/'server.key',cert,broker,'localhost',qport,identities['client']],env)
 route=wait_log('server',r'READY id=\S+ route=(\S+)',server)[1]
 client=spawn('client',[probe,'client',out/'client.key',cert,broker,'localhost',qport,identities['server'],route],env)
 for label,child in [('client',client),('server',server)]:
  code=child.wait(timeout=35);assert code==0,f'{label} exit {code}'
  text=(out/(label+'.stdout.log')).read_text();assert 'DATA_OK ' in text,label+' has no actual business completion'
  ids=set(re.findall(r'stable_id=(\d+)',text));assert len(ids)==1,label+' replaced original connection'
  report[label+'StableId']=next(iter(ids))
 report['exit']=0
except BaseException as error:
 report['failure']=repr(error)
finally:
 for label,child in processes:
  if child.poll() is None:
   # QAD explicitly handles Ctrl-C; a failed probe is stopped only as owned cleanup.
   child.send_signal(signal.SIGINT)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:child.kill();child.wait();report['forcedTermination']=True
  report['processes'].append({'label':label,'pid':child.pid,'exit':child.returncode})
 for f in files:f.close()
 if container:
  logs=call(['docker','logs',container]);(out/'broker.stdout.log').write_text(logs.stdout);(out/'broker.stderr.log').write_text(logs.stderr)
  call(['docker','stop','--time','5',container]);info=json.loads(call(['docker','inspect',container]).stdout)[0];report['brokerExit']=info['State']['ExitCode']
  call(['docker','rm','--volumes',container]);assert not call(['docker','ps','-aq','--filter','name=^/'+service+'$']).stdout.strip();report['ownedContainerAbsent']=True
 guard();report['postconditionsPassed']=True;report['seconds']=time.monotonic()-started;report['driverSha256']=sha(__file__)
 report['buildReceiptSha256']=sha(b/'receipt.json');report['logs']={str(p.name):sha(p) for p in out.glob('*.log')}
 (out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report));sys.exit(report['exit'])

import hashlib
import json
import tarfile
from pathlib import Path

ROOT = Path('/home/js/Git/miopunch')
HERE = Path('/tmp/miopunch-m93-20261018')
OUT = ROOT / 'docs/evidence/native-restricted-admission-2026-10-19'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

protected = read(HERE / 'protected-wip.json')
assert all(sha(ROOT / row['path']) == row['sha256'] for row in protected)

build_names = ['typed-native-formatted-check', 'typed-final-default-v2',
               'typed-final-native', 'typed-final-counterpart-v3',
               'typed-final-wasm-v3', 'typed-final-control-fixtures',
               'typed-late-mqtt-fixtures-v5', 'typed-final-default-fixtures-v3']
builds = {}
for name in build_names:
    receipt = read(HERE / name / 'receipt.json')
    assert receipt['exit'] == 0 and receipt['qualifiedForFrozenRun']
    assert receipt['sourceFrozenDuringBuild']
    builds[name] = receipt

contracts = read(HERE / 'final-native-compile-contracts/receipt.json')
assert contracts['passed'] and len(contracts['cases']) == 18
diagnostics = [json.loads(line) for line in
    (HERE / 'final-native-compile-contracts/native_member_links_control/stderr.jsonl').read_text().splitlines()]
assert sum(row.get('level') == 'error' and (row.get('code') or {}).get('code') == 'E0308'
           for row in diagnostics) == 4

sdk = {}
for name in ['final-old-browser-relay', 'final-old-browser-rtc', 'final-old-browser-active-rtc']:
    directory = HERE / name
    execution = read(directory / 'execution.json')
    raw = read(directory / 'runtime/private-runtime-receipt.json')
    assert execution['qualified'] and raw['qualified'] and raw['cleanupQualified']
    assert execution['cleanup']['relayExit'] == 0 and all(c['removed'] for c in execution['containers'])
    material = raw['materialCompletion']['status']
    reopened = raw['completeReopen']['status']
    assert material['authorization_saved'] and material['secret_saved']
    assert reopened['authorization_saved'] and reopened['secret_saved']
    assert raw['business']['result'] == 'PONG' and raw['approval']['new_records'] == 1
    assert raw['pendingReopen']['id'] == raw['completeReopen']['id']
    initial = raw['memberOpen']['diagnostics']['bootstrap']['coordinator']
    case = {
        'qualified': True, 'execution': execution,
        'privateRawReceiptSha256': sha(directory / 'runtime/private-runtime-receipt.json'),
        'strictPurpose2Request': raw['currentStrictPurpose2Qualified'],
        'oneApprovalRecord': raw['approval']['new_records'] == 1,
        'authorizationSaved': material['authorization_saved'],
        'secretSaved': material['secret_saved'],
        'sameBrowserIdentityReopened': raw['pendingReopen']['id'] == raw['completeReopen']['id'],
        'sameNativeIdentityReopened': raw['businessQualified'],
        'reply': raw['business']['result'],
        'originalConnectionAndBinding': initial['stableUnchanged'] and initial['bindingUnchanged'],
        'freshAck': initial['freshAck'],
        'initialDataCarrier': 'RTC' if raw['nativeMemberReleased'].get('selected_rtc') else 'Relay',
        'cleanup': {key: raw['cleanup'][key] for key in [
            'websocketsClosedBeforeContext', 'ownedBrowserContextClosed',
            'ownedBrowserProcessClosed', 'ownedOriginClosed',
            'nativeProcessAbsentImmediate', 'nativeProcessAbsentLate', 'ownedFixtureRemoved']},
        'nativeExit': raw['cleanup']['nativeExit'],
        'privateMaterialCleanup': read(directory / 'private-material-cleanup.json'),
    }
    if 'improvement' in raw:
        improvement = raw['improvement']
        committed = raw['nativeCommitted']
        final = raw['afterImprovementSelection']
        assert improvement['result']['outcome'] == 'committed'
        assert committed['freshAck'] and committed['bothReady'] and committed['originalOpen']
        assert final['memberStableId'] == raw['beforeImprovement']['diagnostics']['memberStableId']
        assert any(p['isRtc'] and p['selected'] for p in final['paths'])
        case['activeImprovement'] = {'outcome': 'committed', 'sameMemberStableId': True,
            'freshAck': True, 'bothReady': True, 'originalOpen': True,
            'selectedRtc': True, 'explicitPolicy': 'PreferDirect'}
    sdk[name] = case

runtime = {}
for directory in sorted(HERE.iterdir()):
    receipt_path = directory / 'receipt.json'
    if not receipt_path.is_file():
        continue
    value = read(receipt_path)
    if 'testsPassed' in value or 'consumerAssertionMarkerPresent' in value:
        runtime[directory.name] = value

for name, count in [('final-mqtt-bootstrap-v5-runtime', 8), ('final-path-maintenance-runtime', 19), ('final-public-resources-corrected-runtime', 11), ('final-negotiated-context-runtime', 3)]:
    result = runtime[name]
    assert result['exit'] == 0 and result['testsPassed'] == count and not result['forcedTermination']

write('validation.json', {
    'baseline': 'b0cbabec640649873fcef3bf558bde89f6baf0db',
    'implementationCommit': (HERE / 'source-commit.txt').read_text().strip(),
    'protectedPreexistingFileCount': len(protected),
    'protectedPreexistingHashesUnchanged': True,
    'sdkActualSelectedInputsAfterTestOnlyCorrections': read(HERE / 'final-sdk-selected-input-continuity.json'),
    'builds': builds,
    'compilerContracts': contracts,
    'nativeControlBusinessTypeErrors': 4,
    'fixedCounterparts': {
        'native': read(HERE / 'old-native-counterpart-build/receipt.json'),
        'browser': read(Path('/tmp/miopunch-m92-20261018/verified-wasm-sdk/receipt.json')),
    },
    'fixedBrowserInteroperability': sdk,
    'runtimeReceiptsIncludingHistoricalFailures': runtime,
    'scope': 'Native M93; Browser migration and ordinary library contract restoration remain M94/M95',
})

files = set()
def include(path):
    if path.is_file():
        files.add(path)

for p in HERE.glob('*-context.json'):
    include(p)
for p in HERE.glob('*.py'):
    if 'staged' not in p.name and not p.name.startswith('port-'):
        include(p)
for name in ['fixed-consumer-inputs.json', 'source-baseline.txt',
             'old-native-counterpart.rs', 'fixed-ordinary-wrapped-consumer.rs',
             'baseline-native-fixtures-pins.json', 'final-sdk-selected-input-continuity.json',
             'source-commit.txt', 'final-source-files.json']:
    include(HERE / name)
for directory in HERE.iterdir():
    if not directory.is_dir():
        continue
    for name in ['Cargo.toml', 'Cargo.lock', 'receipt.json', 'preconditions.json',
                 'cargo.jsonl', 'cargo.stderr.log', 'selected-dependency-inputs.json',
                 'bindgen.stdout.log', 'bindgen.stderr.log']:
        include(directory / name)
    if (directory / 'receipt.json').is_file():
        report = read(directory / 'receipt.json')
        if 'testsPassed' in report or 'consumerAssertionMarkerPresent' in report:
            for name in ['stdout.log', 'stderr.log', 'runtime-driver.py']:
                include(directory / name)
    if directory.name.startswith(('old-browser-', 'final-old-browser-')):
        for name in ['execute.py', 'run.mjs', 'execution.json',
                     'execution-preconditions.json', 'private-material-cleanup.json']:
            include(directory / name)
for p in HERE.glob('*-service.json'):
    include(p)
for directory_name in ['typed-sdk-native-compile-contracts', 'final-native-compile-contracts']:
    directory = HERE / directory_name
    for p in directory.rglob('*'):
        if 'pinned' not in p.parts and p.suffix in {'.json', '.jsonl', '.log'}:
            include(p)

for p in (HERE / 'baseline-native-fixtures').rglob('*'):
    if p.suffix == '.rs':
        include(p)

manifest = {str(p.relative_to(HERE)): {'sha256': sha(p), 'bytes': p.stat().st_size}
            for p in sorted(files)}
archive = OUT / 'raw-verification.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for p in sorted(files):
        tar.add(p, arcname=str(p.relative_to(HERE)), recursive=False)
write('archive-manifest.json', {'members': manifest, 'archiveSha256': sha(archive),
    'archiveBytes': archive.stat().st_size,
    'excluded': ['Pinned executables/libraries and full source copies remain under local receipt paths',
        'Private SDK logs, generated stores, test private keys, NSS databases and SDP/identity details'],
    'privateSdkResults': 'Only explicit allowlisted outcomes are in validation.json'})
print(json.dumps({'archiveMembers': len(manifest), 'archiveBytes': archive.stat().st_size,
                  'runtimeReceipts': len(runtime), 'sdkCases': len(sdk)}))

import json,os,subprocess,time
from pathlib import Path
h=Path('/tmp/miopunch-m93-20261018')
name='miopunch-m93-owned-mqtt-20261018'
def call(args,**kw):return subprocess.run(['rtk','proxy',*args],check=True,text=True,capture_output=True,**kw)
image=json.loads(call(['docker','image','inspect','eclipse-mosquitto:2']).stdout)[0]['Id']
receipt={'imageId':image,'containerName':name,'started':False,'stopped':False,'removed':False}
try:
    container=call(['docker','run','--pull=never','-d','--name',name,'--label','miopunch.task=M93','-p','127.0.0.1::1883','-v',str(h/'mosquitto.conf')+':/mosquitto/config/mosquitto.conf:ro',image]).stdout.strip()
    receipt.update(containerId=container,started=True)
    info=json.loads(call(['docker','inspect',container]).stdout)[0]
    binding=info['NetworkSettings']['Ports']['1883/tcp'][0]
    assert binding['HostIp']=='127.0.0.1'
    broker='127.0.0.1:'+binding['HostPort'];receipt['broker']=broker
    env=os.environ.copy();env['MIOPUNCH_MQTT_BROKER']=broker
    command=['rtk','proxy','python3',str(h/'run-tests.py'),'--timeout-seconds','80','native-path-regressions-v1','native-path-mqtt-upgrade-runtime-v1','mqtt_upgrade','--test-threads=1','--nocapture']
    started=time.monotonic()
    result=subprocess.run(command,env=env)
    receipt.update(testExit=result.returncode,seconds=time.monotonic()-started)
finally:
    if receipt['started']:
        (h/'owned-mqtt-regression-service.log').write_text(call(['docker','logs',name]).stdout)
        call(['docker','stop','--time','5',name]);receipt['stopped']=True
        info=json.loads(call(['docker','inspect',name]).stdout)[0]
        receipt['serviceExit']=info['State']['ExitCode']
        call(['docker','rm',name]);receipt['removed']=True
    (h/'owned-mqtt-regression-service.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
raise SystemExit(receipt.get('testExit',1))

import hashlib,json,sys,os
from pathlib import Path
ROOT=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m95-20261019')
sys.path.insert(0,str(ROOT/'scripts'));import cargo_cache as cache
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((H/'cache-review.json').read_text());assert not review['errors']
assert sha(H/'cache-review.json') == 'f0e3a0e14108f4577d9dd799c9529d575522d81be6a7acc89c24c9b3fc48054a'
assert len(review['exactList']) == 12
catalog=review['publishedEvidenceCatalog']
assert {str(p) for p in (ROOT/'docs/evidence').rglob('*') if p.is_file()}==set(catalog)
for p,r in catalog.items():
 st=Path(p).stat();assert st.st_size==r['bytes'] and st.st_mtime_ns==r['mtimeNs']
removed=[]
# Cleanup only: acquire the same lease even below the compile free-space floor. No Cargo is invoked.
with cache.cache_lease(ROOT/'target', min_free=0) as before:
 assert not cache.active_compilers(ROOT)
 for r in review['exactList']:
  p=Path(r['path']);st=p.stat();assert p.parent==ROOT/'target/debug/deps' and not p.is_symlink() and st.st_nlink==1
  assert st.st_size==r['bytes'] and st.st_mtime==r['mtime'] and sha(p)==r['sha256']
  assert sha(r['fingerprint'])==r['fingerprintSha256'] and r['path'] not in review['publishedExemptions']
 for r in review['exactList']:
  Path(r['path']).unlink();removed.append(r)
 result={'reviewSha256':sha(H/'cache-review.json'),'reviewedExactListOnly':True,'publishedCatalogUnchanged':True,'noActiveCompilers':True,'before':before,'removed':removed,'after':cache.disk_state(ROOT/'target')}
(H/'cache-prune-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'removed':len(removed),'bytes':sum(r['bytes'] for r in removed),'diskAfter':result['after']}))

import gzip,hashlib,json,os
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m95-20261019')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
builds=['original-ordinary-baseline-v3','original-routing-baseline-v2','current-ordinary-green','current-routing-green','current-restricted-baseline']
rows=[];pins={}
for build in builds:
 report=json.loads((H/build/'receipt.json').read_text());assert report['exit']==0 and report['qualifiedForFrozenRun']
 artifact=next(iter(report['artifacts']));digest=report['artifacts'][artifact];assert sha(artifact)==digest;pins[artifact]=digest
 name=Path(artifact).name
 for p in (R/'target/debug/deps').glob(name.replace('-','_')+'-*'):
  if not p.is_file() or p.suffix or p.is_symlink() or sha(p)!=digest:continue
  st=p.stat();paths=[p]
  if st.st_nlink==2:
   normal=R/'target/debug'/name;assert normal.exists() and normal.stat().st_ino==st.st_ino and normal.stat().st_dev==st.st_dev;paths.append(normal)
  else:assert st.st_nlink==1
  rows.append({'cachePaths':[str(x) for x in paths],'pin':artifact,'sha256':digest,'bytes':st.st_size,'inode':st.st_ino,'device':st.st_dev,'nlink':st.st_nlink,'mtimeNs':st.st_mtime_ns,'buildReceipt':str(H/build/'receipt.json'),'buildReceiptSha256':sha(H/build/'receipt.json')})
needles={}
for i,row in enumerate(rows):
 for name in row['cachePaths']:needles.setdefault(name.encode(),set()).add(i)
 needles.setdefault(row['sha256'].encode(),set()).add(i)
refs={};catalog={}
for p in (R/'docs/evidence').rglob('*'):
 if not p.is_file():continue
 st=p.stat();catalog[str(p)]={'bytes':st.st_size,'mtimeNs':st.st_mtime_ns};blob=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
 for needle,indices in needles.items():
  if needle in blob:
   for i in indices:refs.setdefault(str(i),[]).append(str(p))
selected=[r for i,r in enumerate(rows) if str(i) not in refs]
assert len({p for r in selected for p in r['cachePaths']})==sum(len(r['cachePaths']) for r in selected)
value={'reason':'Only newly created M95 consumer/obsolete baseline executable cache duplicates; every runtime uses a verified immutable pin outside target. Current SDK cache, all dependency libraries, raw .d evidence and pins remain exempt. Any published exact cache path or artifact hash causes exclusion.','exactList':selected,'totalBytes':sum(r['bytes'] for r in selected),'immutablePinsExempted':pins,'publishedExemptions':refs,'publishedEvidenceCatalog':catalog}
(H/'owned-duplicate-cache-review.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({'selectedGroups':len(selected),'bytes':value['totalBytes'],'publishedExemptions':len(refs)}))

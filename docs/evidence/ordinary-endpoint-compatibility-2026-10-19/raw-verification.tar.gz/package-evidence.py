import hashlib
import json
import tarfile
from pathlib import Path

ROOT = Path('/home/js/Git/miopunch')
HERE = Path('/tmp/miopunch-m95-20261019')
OUT = ROOT / 'docs/evidence/ordinary-endpoint-compatibility-2026-10-19'
OUT.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

protected = read(HERE / 'protected-wip.json')
assert all(sha(ROOT / r['path']) == r['sha256'] for r in protected)
cases = {}
for name in ['final-sdk-story', 'final-sdk-active-rtc', 'final-sdk-negatives',
             'final-browser-incoming-active-rtc']:
    d = HERE / name
    e = read(d / 'execution.json')
    r = read(d / 'runtime/private-runtime-receipt.json')
    assert e['qualified'] and r['qualified'] and r['cleanupQualified']
    assert r['business']['result'] == 'PONG' and r['approval']['new_records'] == 1
    assert r['pendingReopen']['id'] == r['completeReopen']['id']
    assert r['currentStrictPurpose2Qualified'] and r['businessQualified']
    cases[name] = {
        'qualified': True,
        'execution': e,
        'privateRawReceiptSha256': sha(d / 'runtime/private-runtime-receipt.json'),
        'strictRestrictedRequest': True,
        'approvalRecords': r['approval']['new_records'],
        'bothMaterialsDurable': all(r['materialCompletion']['status'][k]
                                   for k in ['authorization_saved', 'secret_saved']),
        'sameBrowserIdentityReopened': True,
        'sameNativeIdentityReopened': True,
        'memberReply': r['business']['result'],
        'initialCarrier': 'RTC' if r['nativeMemberReleased'].get('selected_rtc') else 'Relay',
        'browserClose': r['cleanup']['browser'],
        'socketImmediateObservationPassed': r['cleanup']['socketImmediateObservationPassed'],
        'lateSocketWaitMs': r['cleanup']['lateSocketWaitMs'],
        'websocketsClosedBeforeContext': r['cleanup']['websocketsClosedBeforeContext'],
        'nativeExit': r['cleanup']['nativeExit'],
        'ownedFixtureRemoved': r['cleanup']['ownedFixtureRemoved'],
        'privateMaterialCleanup': read(d / 'private-material-cleanup.json'),
    }
    case = cases[name]
    if 'improvement' in r:
        assert r['improvement']['result']['outcome'] == 'committed'
        assert r['nativeCommitted']['freshAck'] and r['nativeCommitted']['bothReady']
        assert r['nativeBusiness']['stable_id'] == r['nativeBeforeImprovement']['stable_id']
        case['existingNativeBrowserMemberImprovement'] = {
            'sameOriginal': True, 'freshAck': True, 'bothReady': True,
            'selectedRtc': any(p['selected'] and p['isRtc']
                               for p in r['afterImprovementSelection']['paths']),
            'explicitFixturePolicy': 'PreferDirect',
        }
    if 'negativeCases' in r:
        assert len(r['negativeCases']) == 5
        negative = []
        for n in r['negativeCases']:
            outcome = n.get('outcome', n)
            assert outcome['ordinaryHandle'] is False
            value = {'case': n['name'], 'localOrdinaryHandle': False,
                     'counterpartReleasesUnderItsCurrentView': n['nativeOrdinaryReleases']}
            if 'retired' in n:
                t = n['retired']
                assert t['activeAssociations'] == t['activePumpTasks'] == 0
                assert t['checkpoint']['originalOpen'] is False
                assert not t['checkpoint']['route']['active']
                assert not t['checkpoint']['route']['qualified']
                assert t['checkpoint']['route']['tx_bytes'] + t['checkpoint']['route']['rx_bytes'] == 0
                value.update(originalClosed=True, activeAssociations=0, activePumps=0,
                             routeActive=False, routeQualified=False, queuedBytes=0,
                             checkpointFreshAck=n['checkpoint']['checkpoint']['metadata']['freshAck'])
            negative.append(value)
        assert r['publicDeparture']['status']['stage'] == 'Removed'
        case['negativeCases'] = negative
        case['revocationPropagationScope'] = 'Browser-local departure refuses Browser delivery; the fixed counterpart has not received the new departure record.'
        initial = r['memberOpen']['diagnostics']['bootstrap']
        assert initial['finalReleaseFreshAck'] and initial['stableUnchanged'] and initial['bindingUnchanged']
        case['initialRtcFinalChecks'] = {'freshAck': True, 'stableUnchanged': True,
                                        'bindingUnchanged': True, 'beforeRetainFrames': initial['beforeRetainFrames']}
    if 'browserServedFirstRequest' in r:
        assert r['browserServedFirstRequest'] == {'response': 'AwaitingApproval', 'served': 'AwaitingApproval'}
        assert r['browserServedApproved'] == {'response': 'PendingMaterials', 'served': 'Complete'}
        assert r['browserPrecodeUsage'] == 1 and r['browserServedReplica']['complete']
        assert r['manualApplicantReopen']['sameIdentity']
        assert all(c['sdkClosed'] and c['websocketsClosedBeforeContext'] for c in r['extraBrowserCleanup'])
        case['browserIncoming'] = {'manualApproval': True, 'durableMaterials': True,
                                  'sameApplicantReopened': True, 'memberStream': True,
                                  'precodeUses': 1, 'precodeRetryDoesNotConsumeAgain': True,
                                  'replicaComplete': True, 'extraContextCleanup': r['extraBrowserCleanup']}
    if 'browserIncomingActive' in r:
        assert r['browserIncomingActive']['outcome'] == 'committed'
        sides = {}
        for side in ['initiator', 'responder']:
            before, after = r['browserIncomingActiveBefore'][side], r['browserIncomingActiveAfter'][side]
            b = after['bootstrap']
            assert before['memberStableId'] == after['memberStableId']
            assert b['finalReleaseFreshAck'] and b['stableUnchanged'] and b['bindingUnchanged']
            assert b['coordinator']['freshAck'] and b['coordinator']['bothReady']
            assert any(p['selected'] and p['isRtc'] for p in after['paths'])
            sides[side] = {'sameOriginal': True, 'freshAck': True, 'bothReady': True,
                           'selectedRtc': True, 'beforeRetainFrames': b['beforeRetainFrames']}
        case['browserIncomingActiveControl'] = {'sides': sides, 'originalMemberBusinessAfterRtc': True,
                                               'explicitFixturePolicy': 'PreferDirect'}

build_names = ['final-native-sdk', 'final-browser-sdk', 'final-affected-tests-v2']
builds = {n: read(HERE / n / 'receipt.json') for n in build_names}
continuity = {}
for name, receipt in builds.items():
    assert receipt['exit'] == 0 and receipt['sourceFrozenDuringBuild'] and receipt['qualifiedForFrozenRun']
    inputs = read(HERE / name / 'selected-dependency-inputs.json')
    for path, digest in inputs['inputs'].items():
        assert sha(path) == digest, path
    for path, digest in inputs['copiedRepositoryInputs'].items():
        assert sha(ROOT / path) == digest, path
    for path, digest in receipt['artifacts'].items():
        assert sha(path) == digest, path
    continuity[name] = {'allActualSelectedInputsUnchanged': True,
                        'inputCount': len(inputs['inputs']),
                        'repositoryInputCount': len(inputs['copiedRepositoryInputs']),
                        'immutableArtifactsUnchanged': True,
                        'sourceDigest': receipt['sourceDigestAfter']}
(HERE / 'final-selected-input-continuity.json').write_text(json.dumps(continuity, indent=2) + '\n')

tests = {}
for name in ['ordinary_endpoint', 'restricted_endpoint', 'native_restricted_admission',
             'restricted_protocol_interop', 'existing-protocol-counterpart']:
    d = HERE / ('final-runtime-' + name)
    r = read(d / 'receipt.json')
    assert r['exit'] == 0 and r['postconditionsPassed'] and not r['forcedTermination']
    assert r['nonemptyTestSelection'] and r['testsFailed'] == 0
    tests[name] = r
assert sum(r['testsPassed'] for r in tests.values()) == 36
contracts = read(HERE / 'restored-restricted-contracts/receipt.json')
ordinary = {name: read(HERE / name / 'receipt.json') for name in
            ['original-ordinary-runtime', 'current-ordinary-runtime',
             'original-routing-runtime', 'current-routing-runtime']}
assert all(r['exit'] == 0 for r in ordinary.values())
write('validation.json', {
    'baselineCommit': (HERE / 'source-baseline.txt').read_text().strip(),
    'implementationCommit': (HERE / 'source-commit.txt').read_text().strip(),
    'protectedPreexistingFileCount': len(protected), 'protectedPreexistingHashesUnchanged': True,
    'beforeProductionEdits': read(HERE / 'before-production-edits.json'),
    'unchangedOriginalConsumers': read(HERE / 'fixed-consumer-inputs.json'),
    'originalM92ConsumerFinal': read(HERE / 'unchanged-original-consumer-final/receipt.json'),
    'ordinaryRuntimes': ordinary, 'finalBuilds': builds,
    'actualSelectedInputContinuity': continuity,
    'affectedRuntimeTests': tests, 'distinctRuntimeTestsPassed': 36,
    'compilerContracts': contracts,
    'finalSdkCases': cases,
    'intermediateTestCompression': read(HERE / 'intermediate-test-compression.json'),
    'scope': 'M95 ordinary library contract restoration and affected restricted/SDK regressions; owned loopback only; broader M91 and public/physical matrix remain separate',
})

files = set()
def include(p):
    if p.is_file():
        files.add(p)
for pattern in ['*.py', '*-context.json', '*.rs']:
    for p in HERE.glob(pattern):
        include(p)
for name in ['architecture-plan.txt', 'review-spec.md', 'review-standards.md',
             'fixed-consumer-inputs.json', 'before-production-edits.json', 'source-baseline.txt',
             'owned-source-files.json', 'source-commit.txt', 'source-commit-receipt.json',
             'final-selected-input-continuity.json', 'original-vs-fork-red.json',
             'sdk-consumer-delta.json', 'intermediate-test-compression.json',
             'affected-selector-scope.json']:
    include(HERE / name)
for p in HERE.glob('*cache*.json'):
    include(p)
for d in HERE.iterdir():
    if not d.is_dir():
        continue
    sdk_run = (d / 'execution.json').is_file()
    for name in ['Cargo.toml', 'Cargo.lock', 'receipt.json', 'preconditions.json',
                 'cargo.jsonl', 'cargo.stderr.log', 'selected-dependency-inputs.json',
                 'bindgen.stdout.log', 'bindgen.stderr.log', 'execute.py', 'run.mjs',
                 'execution.json', 'execution-preconditions.json', 'private-material-cleanup.json']:
        include(d / name)
    if not sdk_run:
        for name in ['stdout.log', 'stderr.log']:
            include(d / name)
    if 'restricted-contracts' in d.name or d.name == 'unchanged-original-consumer-final':
        for p in d.rglob('*'):
            if p.suffix in ['.rs', '.json', '.log']:
                include(p)

manifest = {str(p.relative_to(HERE)): {'sha256': sha(p), 'bytes': p.stat().st_size}
            for p in sorted(files)}
archive = OUT / 'raw-verification.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for p in sorted(files):
        tar.add(p, arcname=str(p.relative_to(HERE)), recursive=False)
with tarfile.open(archive) as tar:
    assert set(tar.getnames()) == set(manifest)
    for member in tar:
        data = tar.extractfile(member).read()
        expected = manifest[member.name]
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
write('archive-manifest.json', {'members': manifest, 'archiveSha256': sha(archive),
    'archiveBytes': archive.stat().st_size, 'allMembersReadBackAndVerified': True,
    'excluded': ['Fixed executables/WASM and selected source copies remain under local receipt paths',
                 'Private SDK runtime logs, identities, SDP, stores, private keys and NSS databases'],
    'sdkResults': 'Explicit scalar/hash allowlist in validation.json',
    'intermediateExecutable': 'Lossless compression receipt identifies the intentionally removed uncompressed historical path'})
print(json.dumps({'archiveMembers': len(manifest), 'archiveBytes': archive.stat().st_size,
                  'finalSdkCases': len(cases), 'runtimeTestsPassed': 36}))


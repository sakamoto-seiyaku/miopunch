import hashlib,json,subprocess,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m95-20261019');P=Path('/tmp/miopunch-m92-20261018/original-consumer.rs')
sys.path.insert(0,str(R/'scripts'));import cargo_cache
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(P)=='e59e299a02e620408c28b0398b1e3ec8ab451ce9f9111e37af2f68e61bdcc769'
out=H/'unchanged-original-consumer-final';assert not out.exists()
original=H/'original-ordinary-baseline-v3';c=json.loads((H/'original-ordinary-baseline-v3-context.json').read_text());report=json.loads((original/'receipt.json').read_text());assert report['exit']==0 and report['qualifiedForFrozenRun']
records=[json.loads(l) for l in (original/'cargo.jsonl').read_text().splitlines() if l.startswith('{')]
rows=[r for r in records if r.get('reason')=='compiler-artifact' and r['target']['name']=='iroh' and 'lib' in r['target']['kind']]
assert len(rows)==1 and rows[0]['target']['src_path']=='/tmp/miopunch-fork-audit-20261012/baselines/iroh/iroh-1.2.0/src/lib.rs'
lib=next(Path(p) for p in rows[0]['filenames'] if p.endswith('.rlib'))
selected=json.loads((original/'selected-dependency-inputs.json').read_text());assert not any(p.startswith(str(R/'vendor')+'/') or p.startswith(str(R/'src')+'/') for p in selected['inputs'])
inputs={**selected['inputs'],**c['fixedInputs'],**c['selectorPins'],**c['artifactPins'],**c['tools']['binaries'],**report['artifacts'],str(lib):sha(lib)}
current=H/'restored-restricted-contracts';r=json.loads((current/'receipt.json').read_text());assert r['passed'];fork=next((current/'pinned').glob('libiroh-*.rlib'));assert sha(fork)==r['librarySha256']
inputs.update(r['inputs']);inputs[str(fork)]=sha(fork);inputs[str(P)]=sha(P);inputs[str(Path(__file__))]=sha(__file__)
def guard():assert all(sha(p)==d for p,d in inputs.items()), 'source/lock/tool/artifact precondition changed'
guard();results=[]
with cargo_cache.cache_lease(R/'target'):
 guard();out.mkdir()
 for name,library in [('fixed-official',lib),('current-fork',fork)]:
  case=out/name;case.mkdir();command=['rtk','proxy',c['tools']['stableToolchain']['rustc'],'--edition=2024','--crate-type=bin','--emit=metadata','--error-format=json','--extern',f'iroh={library}','-L',f'dependency={R}/target/debug/deps','--out-dir',str(case),str(P)]
  guard();result=subprocess.run(command,capture_output=True,text=True,timeout=60);(case/'stderr.jsonl').write_text(result.stderr);(case/'stdout.log').write_text(result.stdout);guard();results.append({'case':name,'command':command,'exit':result.returncode,'consumerSha256':sha(P),'irohLibrarySha256':sha(library),'metadata':{str(p):sha(p) for p in case.glob('*.rmeta')},'stderrSha256':sha(case/'stderr.jsonl')})
 guard();value={'sameUnmodifiedM92Consumer':True,'consumerSha256':sha(P),'sourceLockToolArtifactPreconditionsPassed':True,'postconditionsPassed':True,'cases':results,'inputs':inputs,'passed':all(x['exit']==0 and x['metadata'] for x in results)};(out/'receipt.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({'passed':value['passed'],'cases':[{'case':x['case'],'exit':x['exit']} for x in results]}));assert value['passed']

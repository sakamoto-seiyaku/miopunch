import hashlib,json,os,sys
from pathlib import Path
ROOT=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m95-20261019')
sys.path.insert(0,str(ROOT/'scripts'));import cargo_cache as cache
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
assert sha(H/'owned-duplicate-cache-review.json') == '031cb0a506c5f2695ef7ef7477f5aa2357a01d00db7d3d82e3de5022494cd8aa'
r=json.loads((H/'owned-duplicate-cache-review.json').read_text());assert not r['publishedExemptions'];assert len(r['exactList'])==5 and r['totalBytes']==544360320
cat=r['publishedEvidenceCatalog'];assert set(cat)=={str(p) for p in (ROOT/'docs/evidence').rglob('*') if p.is_file()}
for p,item in cat.items():
 st=Path(p).stat();assert st.st_size==item['bytes'] and st.st_mtime_ns==item['mtimeNs']
# This lease permits cleanup below the compile floor; no Cargo is invoked.
with cache.cache_lease(ROOT/'target',min_free=0) as before:
 assert not cache.active_compilers(ROOT)
 assert all(sha(p)==digest for p,digest in r['immutablePinsExempted'].items())
 selected={(item['device'],item['inode']) for item in r['exactList']}
 names={Path(path).name[:15] for item in r['exactList'] for path in item['cachePaths']}
 names.update(Path(item['pin']).name[:15] for item in r['exactList'])
 for proc in Path('/proc').glob('[0-9]*'):
  try:
   if proc.stat().st_uid!=os.getuid():continue
   if (proc/'comm').read_text().strip() not in names:continue
   try:st=(proc/'exe').stat()
   except FileNotFoundError:continue
   assert (st.st_dev,st.st_ino) not in selected, 'selected cache executable is still running'
  except FileNotFoundError:continue
 for item in r['exactList']:
  assert sha(item['pin'])==item['sha256'] and sha(item['buildReceipt'])==item['buildReceiptSha256']
  for path in item['cachePaths']:
   p=Path(path);assert p.parent in [ROOT/'target/debug',ROOT/'target/debug/deps'];assert not p.is_symlink()
   st=p.stat();assert (st.st_dev,st.st_ino,st.st_nlink,st.st_size,st.st_mtime_ns)==(item['device'],item['inode'],item['nlink'],item['bytes'],item['mtimeNs']);assert sha(p)==item['sha256']
 for item in r['exactList']:
  for path in item['cachePaths']:Path(path).unlink()
 assert all(sha(p)==digest for p,digest in r['immutablePinsExempted'].items())
 report={'reviewSha256':sha(H/'owned-duplicate-cache-review.json'),'exactReviewedCacheDuplicatesOnly':True,'noActiveCompilersOrSelectedExecutables':True,'allImmutablePinsUnchanged':True,'before':before,'removed':r['exactList'],'after':cache.disk_state(ROOT/'target')}
(H/'owned-duplicate-cache-prune.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'groups':len(r['exactList']),'bytes':r['totalBytes'],'diskAfter':report['after']}))

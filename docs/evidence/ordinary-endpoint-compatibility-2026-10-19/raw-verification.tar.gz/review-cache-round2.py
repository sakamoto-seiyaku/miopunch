import gzip,hashlib,json,re,time
from pathlib import Path

root=Path('/home/js/Git/miopunch');out=Path('/tmp/miopunch-m95-20261019')
assert not (out/'cache-review-round2.json').exists()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()

cache=root/'target/debug';candidates=[]
for p in (cache/'deps').iterdir():
 if not p.is_file() or p.is_symlink() or p.suffix:continue
 s=p.stat()
 if s.st_nlink!=1 or not s.st_mode&0o111 or s.st_mtime>=1792195200:continue
 suffix=p.name.rsplit('-',1)[-1]
 fingerprints=list((cache/'.fingerprint').glob('*-'+suffix+'/test-*.json'))
 if not fingerprints:continue
 candidates.append({'path':str(p),'fingerprint':str(fingerprints[0]),'fingerprintSha256':sha(fingerprints[0]),'bytes':s.st_size,'mtime':s.st_mtime})
names={Path(r['path']).name.encode():r['path'] for r in candidates}
published={};catalog={};errors=[]
filename=re.compile(rb'[A-Za-z_][A-Za-z0-9_-]{0,80}-[0-9a-f]{16}(?![0-9a-f])')
def evidence():
 for p in (root/'docs/evidence').rglob('*'):
  if p.is_file():yield p
for p in evidence():
 s=p.stat();catalog[str(p)]={'bytes':s.st_size,'mtimeNs':s.st_mtime_ns}
 try:
  blob=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
  for match in filename.finditer(blob):
   candidate=names.get(match.group())
   if candidate:published[candidate]=str(p)
 except (OSError,EOFError,gzip.BadGzipFile) as e:errors.append({'path':str(p),'error':str(e)})
assert not errors,errors
selected=[];total=0
for r in sorted(candidates,key=lambda r:r['mtime']):
 if r['path'] in published:continue
 selected.append(r);total+=r['bytes']
 if total>=8000*1024**2:break
hashes={}
for r in selected:
 r['sha256']=sha(r['path']);hashes.setdefault(r['sha256'].encode(),[]).append(r['path'])
digest=re.compile(rb'[0-9a-f]{64}(?![0-9a-f])')
for p in evidence():
 try:
  blob=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes()
  for match in digest.finditer(blob):
   for candidate in hashes.get(match.group(),[]):published[candidate]=str(p)
 except (OSError,EOFError,gzip.BadGzipFile) as e:errors.append({'path':str(p),'error':str(e)})
assert not errors,errors
selected=[r for r in selected if r['path'] not in published]
value={'exactList':selected,'totalBytes':sum(r['bytes'] for r in selected),'publishedEvidenceCatalog':catalog,'publishedExemptions':published,'candidateCount':len(candidates),'errors':errors,'reason':'Pre-Oct17, confirmed Cargo test cache executables only; no published filename/hash references; raw evidence, .d files, SDK pins, libraries, normal bins and hardlinks excluded.'}
(out/'cache-review-round2.json').write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({'selected':len(selected),'bytes':value['totalBytes'],'publishedExemptions':len(published),'evidenceFiles':len(catalog)}))

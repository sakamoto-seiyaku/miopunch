import subprocess,json,hashlib,sys,time,tarfile,re,shutil
from pathlib import Path
out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
files=sorted({str(p) for d in ['src','tests','browser-probe/src'] for p in Path(d).rglob('*.rs')}|{'Cargo.toml','Cargo.lock',__file__})
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
hashes={p:sha(p) for p in files}
cmd=sys.argv[2:]
(out/'prestart.json').write_text(json.dumps({'command':cmd,'source_sha256':hashes,'started':time.time(),'snapshot':'source-snapshot.tar.gz'},indent=2))
with tarfile.open(out/'source-snapshot.tar.gz','w:gz') as archive:
    for p in files:archive.add(p,arcname=('harness/'+Path(p).name if Path(p).is_absolute() else p),recursive=False)
with (out/'output.log').open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
receipt={'exit_code':r.returncode,'finished':time.time(),'source_unchanged':hashes=={p:sha(p) for p in files}}
(out/'exit.json').write_text(json.dumps(receipt,indent=2))
frozen=Path('/tmp/mio37-frozen-executables'); binaries=[]
for name in re.findall(r'Running [^\n]+\((target/debug/deps/[^) ]+)\)',(out/'output.log').read_text()):
    p=Path(name)
    if p.exists():
        digest=sha(p); dest=frozen/digest/p.name;dest.parent.mkdir(parents=True,exist_ok=True)
        if not dest.exists():shutil.copyfile(p,dest);dest.chmod(0o500)
        assert sha(dest)==digest
        binaries.append({'path':str(p),'sha256':digest,'frozen_path':str(dest)})
(out/'executables.json').write_text(json.dumps(binaries,indent=2))
print(out,r.returncode)
sys.exit(r.returncode if receipt['source_unchanged'] else 2)

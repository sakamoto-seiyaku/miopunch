//! Admission-secret rotation through durable public nodes and real TLS/QUIC.
use std::net::Ipv4Addr;
use std::path::Path;
use std::time::Duration;
use iroh::{Endpoint, EndpointAddr, endpoint::Connection};
use miopunch_native_probe::admission_gate::ADMISSION_REQUEST_ALPN;
use miopunch_native_probe::admission_rotation::{ADMISSION_ROTATION_ALPN, RotationStage};
use miopunch_native_probe::genesis_recovery::GenesisCredential;
use miopunch_native_probe::manual_admission::ManualExchange;
use miopunch_native_probe::native_network::NativeNetwork;
use p2panda_core::Hash;

fn credential(path: &Path) -> GenesisCredential {
    let saved = std::fs::read(path.join("genesis.credential")).unwrap();
    GenesisCredential::from_saved(
        saved[..32].try_into().unwrap(),
        Hash::from_bytes(saved[32..].try_into().unwrap()),
    )
}

async fn connect(a: &Endpoint, b: &Endpoint, alpn: &[u8]) -> (Connection, Connection) {
    tokio::time::timeout(Duration::from_secs(10), async {
        let address = EndpointAddr::new(b.id()).with_ip_addr(*b.addr().ip_addrs().next().unwrap());
        let (a, b) = tokio::join!(a.connect(address, alpn), async {
            b.accept().await.unwrap().await
        });
        (a.unwrap(), b.unwrap())
    })
    .await
    .unwrap()
}

async fn join(admin: &mut NativeNetwork, path: &Path) -> NativeNetwork {
    let mut node = NativeNetwork::join(path, admin.manual_invitation().unwrap())
        .await
        .unwrap();
    let ae = admin.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let ne = node.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let (client, server) = connect(&ne, &ae, ADMISSION_REQUEST_ALPN).await;
    let (request, served) = tokio::join!(
        node.request_manual_admission(&client),
        admin.serve_manual_admission(&server)
    );
    assert!(matches!(request.unwrap(), ManualExchange::AwaitingApproval));
    served.unwrap();
    let request = admin.manual_requests().await.unwrap().pop().unwrap();
    admin.approve_manual_admission(&request).await.unwrap();
    let receiver = async {
        let ManualExchange::Materials(material) =
            node.request_manual_admission(&client).await.unwrap()
        else {
            panic!("approved member must receive material")
        };
        node.complete_manual_admission(material).await.unwrap();
    };
    let (_, served) = tokio::join!(receiver, admin.serve_manual_admission(&server));
    served.unwrap();
    client.close(0u32.into(), b"admission done");
    server.close(0u32.into(), b"admission done");
    ne.close().await;
    ae.close().await;
    node
}


async fn distribute(initiator: &mut NativeNetwork, member: &mut NativeNetwork) {
    let ie = initiator.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let me = member.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let (client, server) = connect(&ie, &me, ADMISSION_ROTATION_ALPN).await;
    let (sent, received) = tokio::join!(
        initiator.distribute_admission_rotation(&client),
        member.receive_admission_rotation(&server)
    );
    sent.unwrap();
    received.unwrap();
    ie.close().await;
    me.close().await;
}

#[tokio::test]
async fn two_retained_members_save_ack_switch_and_reopen_with_stable_identities() {
    let dir = tempfile::tempdir().unwrap();
    let cp = dir.path().join("creator");
    let ap = dir.path().join("member-a");
    let bp = dir.path().join("member-b");
    let mut c = NativeNetwork::create(&cp).await.unwrap();
    let mut a = join(&mut c, &ap).await;
    let mut b = join(&mut c, &bp).await;
    let identities = [c.status().node_id, a.status().node_id, b.status().node_id];
    let anchor = c.status().anchor;
    let mut session = c.begin_management_session();
    c.elevate_genesis(&mut session, credential(&cp), Duration::from_secs(60)).unwrap();
    let initial = c.begin_admission_rotation(&mut session).await.unwrap();
    assert_eq!(initial.generation, 1);
    assert_eq!(initial.retained.len(), 3, "virtual root is not an online member");
    assert_eq!(initial.acknowledged, vec![identities[0]]);
    distribute(&mut c, &mut a).await;
    distribute(&mut c, &mut b).await;
    let ready = c.rotation_progress().await.unwrap().unwrap();
    assert_eq!(ready.acknowledged.len(), 3);
    let complete = c.finish_admission_rotation(&mut session).await.unwrap();
    assert_eq!(complete.stage, RotationStage::Complete);
    distribute(&mut c, &mut a).await;
    distribute(&mut c, &mut b).await;
    c.close().await; a.close().await; b.close().await;
    let mut c = NativeNetwork::open(&cp).await.unwrap();
    let mut a = NativeNetwork::open(&ap).await.unwrap();
    let b = NativeNetwork::open(&bp).await.unwrap();
    for (node, id) in [(&c, identities[0]), (&a, identities[1]), (&b, identities[2])] {
        assert_eq!(node.status().node_id, id);
        assert_eq!(node.status().anchor, anchor);
        let progress = node.rotation_progress().await.unwrap().unwrap();
        assert_eq!(progress.id, initial.id);
        assert_eq!(progress.stage, RotationStage::Complete);
    }
    // Idempotent completion on a fresh, new-generation SCRAM-bound connection.
    distribute(&mut c, &mut a).await;
    eprintln!("MIO37_FIRST retained=3 external_retained=2 durable_ack=3 generation=1 reopened=true stable_identity=true new_secret_connection=true");
    c.close().await; a.close().await; b.close().await;
}

#[cfg(feature = "replica-test-hooks")]
#[test]
fn rotation_checkpoint_worker() {
    let Ok(path) = std::env::var("MIO37_NODE_PATH") else { return };
    tokio::runtime::Runtime::new().unwrap().block_on(async {
        let mut node = NativeNetwork::open(&path).await.unwrap();
        node.set_replica_checkpoint_observer(|checkpoint| {
            if format!("{checkpoint:?}") == std::env::var("MIO37_CHECKPOINT").unwrap() {
                eprintln!("MIO37_CRASH actual_exit=87 checkpoint={checkpoint:?}");
                std::process::exit(87);
            }
        });
        let endpoint = node.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
        let public = format!("{}\n{}", endpoint.id(), endpoint.addr().ip_addrs().next().unwrap());
        std::fs::write(std::env::var("MIO37_PUBLIC_PATH").unwrap(), public).unwrap();
        let connection = endpoint.accept().await.unwrap().await.unwrap();
        if std::env::var("MIO37_ROLE").unwrap() == "root-recovery" {
            node.restore_management(&connection).await.unwrap();
        } else if std::env::var("MIO37_ROLE").unwrap() == "initiator" {
            node.distribute_admission_rotation(&connection).await.unwrap();
        } else {
            node.receive_admission_rotation(&connection).await.unwrap();
        }
        endpoint.close().await;
        node.close().await;
    });
}

#[cfg(feature = "replica-test-hooks")]
async fn rotation_worker(path: &Path, public: &Path, checkpoint: &str, role: &str) -> (tokio::process::Child, EndpointAddr) {
    use sha2::{Digest, Sha256};
    let executable = std::env::current_exe().unwrap();
    eprintln!("MIO37_WORKER binary_sha256={} checkpoint={checkpoint}", hex::encode(Sha256::digest(std::fs::read(&executable).unwrap())));
    let mut child = tokio::process::Command::new(executable)
        .args(["--exact", "rotation_checkpoint_worker", "--nocapture"])
        .env("MIO37_NODE_PATH", path)
        .env("MIO37_PUBLIC_PATH", public)
        .env("MIO37_CHECKPOINT", checkpoint)
        .env("MIO37_ROLE", role)
        .kill_on_drop(true)
        .spawn().unwrap();
    let address = tokio::time::timeout(Duration::from_secs(10), async {
        loop {
            if let Ok(text) = std::fs::read_to_string(public) {
                let mut lines = text.lines();
                if let (Some(id), Some(address)) = (lines.next(), lines.next()) {
                    if let (Ok(id), Ok(address)) = (id.parse::<iroh_base::EndpointId>(), address.parse::<std::net::SocketAddr>()) {
                        break EndpointAddr::new(id).with_ip_addr(address);
                    }
                }
            }
            assert!(child.try_wait().unwrap().is_none(), "worker exited before publishing address");
            tokio::time::sleep(Duration::from_millis(20)).await;
        }
    }).await.unwrap();
    (child, address)
}

#[cfg(feature = "replica-test-hooks")]
#[tokio::test]
async fn received_before_commit_process_crash_never_acknowledges_or_switches() {
    use miopunch_native_probe::admission_rotation::RotationError;
    let dir = tempfile::tempdir().unwrap();
    let cp = dir.path().join("creator");
    let mp = dir.path().join("member");
    let mut c = NativeNetwork::create(&cp).await.unwrap();
    let member = join(&mut c, &mp).await;
    let id = member.status().node_id;
    member.close().await;
    let mut session = c.begin_management_session();
    c.elevate_genesis(&mut session, credential(&cp), Duration::from_secs(60)).unwrap();
    let initial = c.begin_admission_rotation(&mut session).await.unwrap();
    let (mut child, target) = rotation_worker(&mp, &dir.path().join("worker.public"), "RotationSecretReceived", "receiver").await;
    let endpoint = c.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let connection = endpoint.connect(target, ADMISSION_ROTATION_ALPN).await.unwrap();
    assert!(c.distribute_admission_rotation(&connection).await.is_err());
    let exit = tokio::time::timeout(Duration::from_secs(10), child.wait()).await.unwrap().unwrap();
    assert_eq!(exit.code(), Some(87));
    endpoint.close().await;
    let after = c.rotation_progress().await.unwrap().unwrap();
    assert_eq!(after.id, initial.id);
    assert_eq!(after.acknowledged.len(), 1);
    assert_eq!(after.stage, RotationStage::Distributing);
    assert!(matches!(c.finish_admission_rotation(&mut session).await, Err(RotationError::Waiting)));
    tokio::time::sleep(Duration::from_millis(100)).await;
    assert!(c.status().members.iter().any(|(member, _)| *member == id), "waiting never automatically removes a member");
    let mut member = NativeNetwork::open(&mp).await.unwrap();
    let pending = member.rotation_progress().await.unwrap().unwrap();
    assert_eq!(pending.id, initial.id);
    assert!(pending.acknowledged.is_empty(), "root pause is durable; secret receipt is not acknowledged");
    assert!(matches!(
        member.begin_rejoin(c.manual_invitation().unwrap()).await,
        Err(miopunch_native_probe::native_network::NodeError::Store(
            miopunch_native_probe::management_store::StoreError::AdmissionPaused
        ))
    ), "reopened recipient enforces its durable admission pause");
    distribute(&mut c, &mut member).await;
    c.finish_admission_rotation(&mut session).await.unwrap();
    distribute(&mut c, &mut member).await;
    assert_eq!(member.rotation_progress().await.unwrap().unwrap().stage, RotationStage::Complete);
    eprintln!("MIO37_PRIORITY receiver_received=true before_commit_actual_exit=87 ack_not_counted=true no_early_switch=true reopened_unacknowledged_plan=true reopened_pause_enforced=true explicit_retry_completed=true");
    c.close().await; member.close().await;
}

#[cfg(feature = "replica-test-hooks")]
#[tokio::test]
async fn saved_replacement_lost_ack_is_retryable_after_member_and_initiator_restart() {
    use miopunch_native_probe::admission_rotation::RotationError;
    let dir = tempfile::tempdir().unwrap();
    let cp = dir.path().join("creator");
    let mp = dir.path().join("member");
    let mut c = NativeNetwork::create(&cp).await.unwrap();
    let member = join(&mut c, &mp).await;
    let id = member.status().node_id;
    member.close().await;
    let mut session = c.begin_management_session();
    c.elevate_genesis(&mut session, credential(&cp), Duration::from_secs(60)).unwrap();
    let initial = c.begin_admission_rotation(&mut session).await.unwrap();
    let (mut child, target) = rotation_worker(&mp, &dir.path().join("worker.public"), "RotationSecretSaved", "receiver").await;
    let endpoint = c.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let connection = endpoint.connect(target, ADMISSION_ROTATION_ALPN).await.unwrap();
    assert!(c.distribute_admission_rotation(&connection).await.is_err());
    assert_eq!(tokio::time::timeout(Duration::from_secs(10), child.wait()).await.unwrap().unwrap().code(), Some(87));
    endpoint.close().await;
    assert!(matches!(c.finish_admission_rotation(&mut session).await, Err(RotationError::Waiting)));
    c.close().await;
    let mut c = NativeNetwork::open(&cp).await.unwrap();
    let mut member = NativeNetwork::open(&mp).await.unwrap();
    assert_eq!(member.status().node_id, id);
    assert_eq!(member.rotation_progress().await.unwrap().unwrap().id, initial.id);
    let before = c.rotation_progress().await.unwrap().unwrap();
    assert_eq!(before.id, initial.id);
    assert_eq!(before.acknowledged.len(), 1);
    let mut session = c.begin_management_session();
    assert!(c.finish_admission_rotation(&mut session).await.is_err(), "reopen never transfers the old elevation");
    c.elevate_genesis(&mut session, credential(&cp), Duration::from_secs(60)).unwrap();
    assert_eq!(c.begin_admission_rotation(&mut session).await.unwrap().id, initial.id, "restart resumes the exact rotation");
    distribute(&mut c, &mut member).await;
    distribute(&mut c, &mut member).await;
    assert_eq!(c.rotation_progress().await.unwrap().unwrap().acknowledged.len(), 2, "duplicates never increase the retained count");
    c.finish_admission_rotation(&mut session).await.unwrap();
    distribute(&mut c, &mut member).await;
    eprintln!("MIO37_LOST_ACK actual_exit=87 durable_secret_before_ack=true initiator_reopened=true same_rotation=true duplicate_ack_idempotent=true");
    c.close().await; member.close().await;
}

#[cfg(feature = "replica-test-hooks")]
async fn initiator_ack_boundary(checkpoint: &str, expected_saved: usize) {
    use miopunch_native_probe::admission_rotation::RotationError;
    let dir = tempfile::tempdir().unwrap();
    let cp = dir.path().join("creator");
    let mp = dir.path().join("member");
    let mut c = NativeNetwork::create(&cp).await.unwrap();
    let mut member = join(&mut c, &mp).await;
    let mut session = c.begin_management_session();
    c.elevate_genesis(&mut session, credential(&cp), Duration::from_secs(60)).unwrap();
    let initial = c.begin_admission_rotation(&mut session).await.unwrap();
    c.close().await;
    let (mut child, target) = rotation_worker(&cp, &dir.path().join("worker.public"), checkpoint, "initiator").await;
    let endpoint = member.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let connection = endpoint.connect(target, ADMISSION_ROTATION_ALPN).await.unwrap();
    assert!(member.receive_admission_rotation(&connection).await.is_err());
    assert_eq!(tokio::time::timeout(Duration::from_secs(10), child.wait()).await.unwrap().unwrap().code(), Some(87));
    endpoint.close().await;
    member.close().await;
    let mut member = NativeNetwork::open(&mp).await.unwrap();
    let mut c = NativeNetwork::open(&cp).await.unwrap();
    let progress = c.rotation_progress().await.unwrap().unwrap();
    assert_eq!(progress.id, initial.id);
    assert_eq!(progress.stage, RotationStage::Distributing);
    assert_eq!(progress.acknowledged.len(), expected_saved);
    let mut session = c.begin_management_session();
    c.elevate_genesis(&mut session, credential(&cp), Duration::from_secs(60)).unwrap();
    if expected_saved == 1 {
        assert!(matches!(c.finish_admission_rotation(&mut session).await, Err(RotationError::Waiting)));
    }
    distribute(&mut c, &mut member).await;
    assert_eq!(c.rotation_progress().await.unwrap().unwrap().acknowledged.len(), 2);
    c.finish_admission_rotation(&mut session).await.unwrap();
    distribute(&mut c, &mut member).await;
    eprintln!("MIO37_INITIATOR actual_exit=87 checkpoint={checkpoint} saved_acknowledgements={expected_saved} same_rotation=true retry_completed=true");
    c.close().await; member.close().await;
}

#[cfg(feature = "replica-test-hooks")]
#[tokio::test]
async fn initiator_ack_received_before_database_commit_does_not_count_after_restart() {
    initiator_ack_boundary("RotationAcknowledgementReceived", 1).await;
}

#[cfg(feature = "replica-test-hooks")]
#[tokio::test]
async fn initiator_ack_database_commit_survives_restart_before_sender_result() {
    initiator_ack_boundary("RotationAcknowledgementSaved", 2).await;
}

#[tokio::test]
async fn new_manual_approval_waits_for_rotation_without_creating_membership() {
    let dir = tempfile::tempdir().unwrap();
    let cp = dir.path().join("creator");
    let mut c = NativeNetwork::create(&cp).await.unwrap();
    let mut applicant = NativeNetwork::join(dir.path().join("applicant"), c.manual_invitation().unwrap()).await.unwrap();
    let ce = c.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let ae = applicant.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let (client, server) = connect(&ae, &ce, ADMISSION_REQUEST_ALPN).await;
    let (sent, served) = tokio::join!(applicant.request_manual_admission(&client), c.serve_manual_admission(&server));
    assert!(matches!(sent.unwrap(), ManualExchange::AwaitingApproval)); served.unwrap();
    ae.close().await; ce.close().await;
    let request = c.manual_requests().await.unwrap().pop().unwrap();
    let before = c.status();
    let mut session = c.begin_management_session();
    c.elevate_genesis(&mut session, credential(&cp), Duration::from_secs(60)).unwrap();
    c.begin_admission_rotation(&mut session).await.unwrap();
    assert!(c.approve_manual_admission(&request).await.is_err(), "rotation pauses new manual approvals");
    assert_eq!(c.status(), before);
    assert!(c.approved_admission(&request).await.unwrap().is_none());
    c.finish_admission_rotation(&mut session).await.unwrap();
    c.approve_manual_admission(&request).await.unwrap();
    let ce = c.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let ae = applicant.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let (client, server) = connect(&ae, &ce, ADMISSION_REQUEST_ALPN).await;
    let receive = async {
        let ManualExchange::Materials(material) = applicant.request_manual_admission(&client).await.unwrap() else { panic!("approval") };
        applicant.complete_manual_admission(material).await.unwrap();
    };
    let (_, served) = tokio::join!(receive, c.serve_manual_admission(&server)); served.unwrap();
    ae.close().await; ce.close().await;
    eprintln!("MIO37_PAUSE new_manual_approval=true no_side_effect=true resumed_current_generation=true");
    c.close().await; applicant.close().await;
}

#[tokio::test]
async fn already_approved_member_without_old_secret_receives_only_rotation_replacement() {
    use miopunch_native_probe::admission_rotation::{ROTATION_DELIVERY_ALPN, RotationError};
    use miopunch_native_probe::manual_admission::AdmissionStage;
    let dir = tempfile::tempdir().unwrap();
    let cp = dir.path().join("creator");
    let ap = dir.path().join("approved-member");
    let mut c = NativeNetwork::create(&cp).await.unwrap();
    let mut a = NativeNetwork::join(&ap, c.manual_invitation().unwrap()).await.unwrap();
    let ce = c.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let ae = a.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let (client, server) = connect(&ae, &ce, ADMISSION_REQUEST_ALPN).await;
    let (sent, served) = tokio::join!(a.request_manual_admission(&client), c.serve_manual_admission(&server));
    assert!(matches!(sent.unwrap(), ManualExchange::AwaitingApproval)); served.unwrap();
    let request = c.manual_requests().await.unwrap().pop().unwrap();
    let original = c.approve_manual_admission(&request).await.unwrap();
    assert_eq!(a.admission_stage(), AdmissionStage::AwaitingApproval);
    let mut session = c.begin_management_session();
    c.elevate_genesis(&mut session, credential(&cp), Duration::from_secs(60)).unwrap();
    let progress = c.begin_admission_rotation(&mut session).await.unwrap();
    assert!(progress.retained.contains(&a.status().node_id), "current approved membership must not be silently excluded");
    assert!(matches!(c.finish_admission_rotation(&mut session).await, Err(RotationError::Waiting)));
    let (requested, served) = tokio::join!(a.request_manual_admission(&client), c.serve_manual_admission(&server));
    assert!(requested.is_err() && served.is_err(), "ordinary approved-material resumption stays paused");
    ae.close().await; ce.close().await;
    let ce = c.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let ae = a.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let (client, server) = connect(&ce, &ae, ROTATION_DELIVERY_ALPN).await;
    let (sent, received) = tokio::join!(c.distribute_admission_rotation(&client), a.receive_admission_rotation(&server));
    sent.unwrap(); received.unwrap();
    assert_eq!(a.admission_stage(), AdmissionStage::PendingMaterials, "staged replacement does not activate before commit");
    assert_eq!(c.approved_admission(&request).await.unwrap().unwrap().authorization, original.authorization);
    ae.close().await; ce.close().await;
    c.finish_admission_rotation(&mut session).await.unwrap();
    distribute(&mut c, &mut a).await;
    assert_eq!(a.admission_stage(), AdmissionStage::Complete);
    a.close().await;
    let a = NativeNetwork::open(&ap).await.unwrap();
    assert_eq!(a.admission_stage(), AdmissionStage::Complete);
    eprintln!("MIO37_PENDING_MEMBER original_grant_reused=true retained_not_excluded=true ordinary_resumption_paused=true replacement_staged_without_old_secret=true complete_after_switch=true");
    a.close().await; c.close().await;
}

#[cfg(feature = "replica-test-hooks")]
async fn pending_root() -> (tempfile::TempDir, std::path::PathBuf, std::path::PathBuf, NativeNetwork, NativeNetwork) {
    use miopunch_native_probe::management_recovery::{MANAGEMENT_RECOVERY_ALPN, RecoveryStage};
    let dir = tempfile::tempdir().unwrap();
    let cp = dir.path().join("creator");
    let rp = dir.path().join("recovering");
    let mut c = NativeNetwork::create(&cp).await.unwrap();
    let ce = c.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let root = NativeNetwork::recover(&rp, &credential(&cp), ce.id()).await.unwrap();
    root.close().await;
    let (mut child, target) = rotation_worker(&rp, &dir.path().join("root-worker.public"), "SecretReceived", "root-recovery").await;
    let connection = ce.connect(target, MANAGEMENT_RECOVERY_ALPN).await.unwrap();
    assert!(c.serve_management_recovery(&connection).await.is_err());
    assert_eq!(tokio::time::timeout(Duration::from_secs(10), child.wait()).await.unwrap().unwrap().code(), Some(87));
    ce.close().await;
    let root = NativeNetwork::open(&rp).await.unwrap();
    assert_eq!(root.recovery_progress().await.unwrap().stage, RecoveryStage::AuthorizationSaved);
    assert!(c.status().members.contains(&(root.status().node_id, p2panda_auth::Access::manage())), "provider has durably verified the grant before this interruption");
    assert!(c.manual_requests().await.unwrap().is_empty(), "root proof never becomes an ordinary approval");
    (dir, cp, rp, c, root)
}

#[cfg(feature = "replica-test-hooks")]
#[tokio::test]
async fn pending_root_recovery_delivery_pauses_but_fresh_root_proof_receives_replacement_once() {
    use miopunch_native_probe::admission_rotation::ROTATION_DELIVERY_ALPN;
    use miopunch_native_probe::management_recovery::{MANAGEMENT_RECOVERY_ALPN, RecoveryStage};
    let (_dir, cp, rp, mut c, mut root) = pending_root().await;
    let id = root.status().node_id;
    let old = root.recovery_progress().await.unwrap();
    let mut session = c.begin_management_session();
    c.elevate_genesis(&mut session, credential(&cp), Duration::from_secs(60)).unwrap();
    c.begin_admission_rotation(&mut session).await.unwrap();
    let ce = c.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let re = root.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let (client, server) = connect(&re, &ce, MANAGEMENT_RECOVERY_ALPN).await;
    let (restored, served) = tokio::join!(root.restore_management(&client), c.serve_management_recovery(&server));
    assert!(restored.is_err() && served.is_err(), "ordinary root restoration material delivery pauses");
    assert!(c.manual_requests().await.unwrap().is_empty());
    let (client, server) = connect(&ce, &re, ROTATION_DELIVERY_ALPN).await;
    let (sent, received) = tokio::join!(c.distribute_admission_rotation(&client), root.receive_admission_rotation(&server));
    sent.unwrap(); received.unwrap();
    tokio::time::timeout(Duration::from_secs(2), client.closed()).await.unwrap();
    assert!(root.receive_admission_rotation(&server).await.is_err(), "root authentication cannot repeat on this same TLS session");
    assert_eq!(root.recovery_progress().await.unwrap().stage, RecoveryStage::AuthorizationSaved);
    ce.close().await; re.close().await;
    c.finish_admission_rotation(&mut session).await.unwrap();
    distribute(&mut c, &mut root).await;
    assert_eq!(root.recovery_progress().await.unwrap().stage, RecoveryStage::Complete);
    root.close().await;
    let root = NativeNetwork::open(&rp).await.unwrap();
    assert_eq!(root.status().node_id, id);
    let current = root.recovery_progress().await.unwrap();
    assert_eq!(current.request, old.request);
    assert_eq!(current.authorization, old.authorization);
    assert_eq!(current.stage, RecoveryStage::Complete);
    assert!(c.manual_requests().await.unwrap().is_empty());
    eprintln!("MIO37_ROOT_PENDING original_grant=true fresh_original_root_exporter_proof=true one_authentication_per_tls=true ordinary_delivery_paused=true replacement_only=true stable_identity=true reopened=true no_ordinary_approval=true");
    root.close().await; c.close().await;
}

#[cfg(feature = "replica-test-hooks")]
#[tokio::test]
async fn forged_ack_signature_is_rejected_without_counting_the_member() {
    use miopunch_native_probe::admission_rotation::{RotationAckFault, RotationError};
    let dir = tempfile::tempdir().unwrap();
    let cp = dir.path().join("creator");
    let mut c = NativeNetwork::create(&cp).await.unwrap();
    let mut a = join(&mut c, &dir.path().join("member")).await;
    let mut session = c.begin_management_session();
    c.elevate_genesis(&mut session, credential(&cp), Duration::from_secs(60)).unwrap();
    c.begin_admission_rotation(&mut session).await.unwrap();
    let ce = c.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let ae = a.bind_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    let (client, server) = connect(&ce, &ae, ADMISSION_ROTATION_ALPN).await;
    let (sent, received) = tokio::join!(
        c.distribute_admission_rotation(&client),
        a.receive_admission_rotation_fixture(&server, RotationAckFault::ForgedSignature)
    );
    assert!(sent.is_err() && received.is_err());
    assert_eq!(c.rotation_progress().await.unwrap().unwrap().acknowledged.len(), 1);
    assert!(matches!(c.finish_admission_rotation(&mut session).await, Err(RotationError::Waiting)));
    ce.close().await; ae.close().await;
    distribute(&mut c, &mut a).await;
    c.finish_admission_rotation(&mut session).await.unwrap();
    distribute(&mut c, &mut a).await;
    eprintln!("MIO37_FORGED_ACK real_tls=true actual_signature_tampered=true counted=false honest_retry_completed=true");
    a.close().await; c.close().await;
}

import json,subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m97-20261019')
plans=[('final-native-sdk', ['build', '--locked', '--offline', '--manifest-path', '/tmp/miopunch-m96-20261019/final-selector/Cargo.toml', '--features', 'rtc-probe', '--bin', 'native_sdk_counterpart', '--jobs', '2']), ('final-browser-sdk', ['build', '--locked', '--offline', '-p', 'miopunch-browser-probe', '--target', 'wasm32-unknown-unknown', '--features', 'rtc-probe', '--jobs', '2']), ('affected-replica-tests', ['test', '--locked', '--offline', '--manifest-path', '/tmp/miopunch-m96-20261019/affected-selector/Cargo.toml', '--features', 'rtc-probe', '--test', 'management_store', '--test', 'offline_replica', '--no-run', '--jobs', '2'])]
for name,cmd in plans:
 for phase,args in [('prepare',cmd),('run',[])]:
  r=subprocess.run(['rtk','proxy','python3',str(H/'build-v2.py'),phase,name,*args]);assert r.returncode==0,(name,phase)
print('Final Native/Browser SDK and affected test builds complete',flush=True)

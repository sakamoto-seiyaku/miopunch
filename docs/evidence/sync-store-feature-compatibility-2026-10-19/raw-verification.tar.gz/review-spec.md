## Spec

No Spec findings.

The diff satisfies MIOPUNCH-97’s native transitive-default requirement, including `sync default-features=false`, while keeping actual Browser SDK normal/dev graphs SQLite-free. Retained evidence covers unchanged consumers before production edits, real failure cases, restored native persistence/reopen, Browser replica save/apply/reopen/duplicate behavior, and resource cleanup. Sync Rust sources and the root lock remain unchanged.

Limits: reviewed source and existing receipts/controllers without rerunning builds or runtimes. Browser explicit `test_utils` and sync’s own dev fixtures retain upstream SQLite requirements; they were inspected and explicitly excluded from Browser build support. WASI has graph evidence only. The physical/public matrix remains outside this issue’s scope.

import argparse
import hashlib
import importlib.util
import json
import re
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/home/js/Git/miopunch')
HERE = Path('/tmp/miopunch-m97-20261019')
UTILITY = Path('/tmp/mio81-final-peer-assertion-sdk-root-20261007/build-current-sdk.py')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(UTILITY) == '2b7e969a1f90fc93eacc80d8b62890f0bb0ef8f40dc140d9398ef1a6029671e1'
spec = importlib.util.spec_from_file_location('m92_runtime_capture', UTILITY)
sdk = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = sdk
spec.loader.exec_module(sdk)

parser = argparse.ArgumentParser()
parser.add_argument('--timeout-seconds', type=float, default=180)
parser.add_argument('build')
parser.add_argument('name')
parser.add_argument('binary')
parser.add_argument('arguments', nargs=argparse.REMAINDER)
args = parser.parse_args()
assert args.timeout_seconds > 0
receipt_path = HERE / args.build / 'receipt.json'
report = json.loads(receipt_path.read_text())
context_path = HERE / (args.build + '-context.json')
context = json.loads(context_path.read_text())

# Existing process tests can embed Cargo's executable path (env! macro).
# Verify those actual child executable bytes as well as the selected copies.
compiled_executables={}
for line in (HERE / args.build / 'cargo.jsonl').read_text().splitlines():
    record=json.loads(line)
    if record.get('reason')=='compiler-artifact' and record.get('executable'):
        pinned=HERE / args.build / 'pinned' / record['target']['name']
        assert str(pinned) in report['artifacts']
        compiled_executables[record['executable']]=report['artifacts'][str(pinned)]

def guard():
    external = os.environ.get('MIOPUNCH_OLD_NATIVE_COUNTERPART')
    if external:
        baseline = json.loads((HERE / 'old-native-counterpart-build/receipt.json').read_text())
        assert baseline['exit'] == 0 and baseline['qualifiedForFrozenRun']
        assert external in baseline['artifacts'] and sha(external) == baseline['artifacts'][external]
    assert Path.cwd().resolve() == ROOT
    assert report['exit'] == 0 and report['qualifiedForFrozenRun'] and report['sourceFrozenDuringBuild']
    assert sdk.current_sources() == context['sources']
    assert sdk.tool_snapshot() == context['tools']
    for group in ['fixedInputs', 'selectorPins', 'artifactPins']:
        assert all(sha(p) == h for p, h in context[group].items()), group + ' changed'
    assert all(sha(p) == h for p, h in report['artifacts'].items()), 'runtime artifact changed'
    assert all(sha(p)==h for p,h in compiled_executables.items()), 'compiled child executable changed'

guard()
out = HERE / args.name
out.mkdir(exist_ok=False)
(out / 'runtime-driver.py').write_bytes(Path(__file__).read_bytes())
binary = HERE / args.build / 'pinned' / args.binary
assert str(binary) in report['artifacts']
command = [str(binary), *args.arguments]
runtime = {'command': command, 'buildReceiptSha256': sha(receipt_path), 'buildContextSha256': sha(context_path),
    'driverSha256': sha(__file__), 'binarySha256': sha(binary), 'compiledExecutablePins': compiled_executables, 'preconditionsPassed': True,
    'exit': None, 'forcedTermination': False}
runtime['oldNativeCounterpartSha256'] = sha(os.environ['MIOPUNCH_OLD_NATIVE_COUNTERPART']) if os.environ.get('MIOPUNCH_OLD_NATIVE_COUNTERPART') else None
started = time.monotonic()
with (out / 'stdout.log').open('w') as stdout, (out / 'stderr.log').open('w') as stderr:
    try:
        result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, timeout=args.timeout_seconds)
        runtime['exit'] = result.returncode
    except subprocess.TimeoutExpired:
        runtime.update(exit=124, forcedTermination=True)
runtime['seconds'] = time.monotonic() - started
guard()
runtime['postconditionsPassed'] = True
summaries = list(re.finditer(r'test result: .*? (\d+) passed; (\d+) failed;', (out / 'stdout.log').read_text()))
summary = summaries[-1] if summaries else None
runtime['testsPassed'] = int(summary.group(1)) if summary else 0
runtime['testsFailed'] = int(summary.group(2)) if summary else 0
runtime['nonemptyTestSelection'] = runtime['testsPassed'] + runtime['testsFailed'] > 0
if not runtime['nonemptyTestSelection'] and runtime['exit'] == 0:
    runtime['exit'] = 1
    runtime['failure'] = 'Empty test selection is not verification.'
runtime['rawLogs'] = {name: sha(out / name) for name in ['stdout.log', 'stderr.log']}
(out / 'receipt.json').write_text(json.dumps(runtime, indent=2) + '\n')
print(json.dumps({key:value for key,value in runtime.items() if key!='compiledExecutablePins'}))
print((out / 'stdout.log').read_text()[-3000:])
if runtime['exit']:
    print((out / 'stderr.log').read_text()[-3000:])
raise SystemExit(runtime['exit'])

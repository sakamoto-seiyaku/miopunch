import hashlib,json,subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m97-20261019');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
fixed=json.loads((H/'published-dev-fixture.json').read_text());manifest=Path(fixed['manifest']);lock=manifest.parent/'Cargo.lock'
assert sha(manifest)==fixed['manifestSha256'] and sha(lock)==fixed['originalLockSha256'] and fixed['sameOriginalRustBytes']
command=['rtk','proxy','cargo','fetch','--locked','--manifest-path',str(manifest),'--target','x86_64-unknown-linux-gnu']
with (H/'published-dev-fetch.stdout.log').open('w') as out,(H/'published-dev-fetch.stderr.log').open('w') as err:
    r=subprocess.run(command,cwd='/home/js/Git/miopunch',stdout=out,stderr=err)
assert sha(manifest)==fixed['manifestSha256'] and sha(lock)==fixed['originalLockSha256']
(H/'published-dev-fetch.json').write_text(json.dumps({'command':command,'exit':r.returncode,
    'originalManifestAndLockGuardedBeforeAndAfter':True,'originalLockSha256':sha(lock),'noCompilationRequested':True},indent=2)+'\n')
print(json.dumps({'exit':r.returncode,'originalPublishedLockUnchanged':True}))
raise SystemExit(r.returncode)

## Standards

No Standards findings in `f3b52078…96b4cd12`.

- **Documented violations:** none. The manifest preserves native defaults under ADR 0012, retains upstream `Cargo.toml.orig`, and documents the Browser exception. Sampled build evidence uses the shared cache with pre-Cargo source, lock, tool and artifact guards; selector checks preserve complete foreign dependency rows.
- **Baseline smells:** none warrant reporting. The repeated store dependency expresses Cargo’s target-specific feature union. Extracting the small consumer’s repeated open/close operations would weaken its direct compatibility example.
- **Scope:** reviewed all five changed files and relevant repository rules, provenance, fixed-consumer continuity, build driver and cleanup receipts. Read-only review; no compilation or runtime tests rerun. Evidence archive packaging was outside this review.

import hashlib,importlib.util,json,subprocess,sys,time,tomllib
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m97-20261019')
U=Path('/tmp/mio81-final-peer-assertion-sdk-root-20261007/build-current-sdk.py')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(U)=='2b7e969a1f90fc93eacc80d8b62890f0bb0ef8f40dc140d9398ef1a6029671e1'
s=importlib.util.spec_from_file_location('m97_graph_sdk',U);sdk=importlib.util.module_from_spec(s);sys.modules[s.name]=sdk;s.loader.exec_module(sdk)
phase=sys.argv[1];out=H/('graphs-'+phase);out.mkdir()
plans=[('original-own-native-dev','x86_64-unknown-linux-gnu',H/'sync-dev-original-lock-before/Cargo.toml',[],True),
       ('original-own-browser-dev','wasm32-unknown-unknown',H/'sync-dev-original-lock-before/Cargo.toml',[],True),
       ('current-own-native-dev','x86_64-unknown-linux-gnu',H/'sync-dev-fork-lock-before/Cargo.toml',[],True),
       ('current-own-browser-dev','wasm32-unknown-unknown',H/'sync-dev-fork-lock-before/Cargo.toml',[],True)]
sources=sdk.current_sources();tools=sdk.tool_snapshot();inputs=json.loads((H/'fixed-consumer-inputs.json').read_text())
for _,_,manifest,_,_ in plans:
    for p in [manifest,manifest.parent/'Cargo.lock']:inputs[str(p)]=sha(p)
original=H/'sync-dev-original-lock-before/Cargo.lock'
for _,_,manifest,_,_ in plans:assert (manifest.parent/'Cargo.lock').read_bytes()==original.read_bytes()
def guard():
    assert sdk.current_sources()==sources and sdk.tool_snapshot()==tools
    assert all(sha(p)==d for p,d in inputs.items())
guard();records={}
with sdk.cargo_cache.cache_lease(R/'target'):
    for name,target,manifest,extra,dev in plans:
        guard();edges='normal,build,dev' if dev else 'normal,build'
        command=['rtk','proxy','cargo','tree','--locked','--offline','--manifest-path',str(manifest),
                 '--target',target,'--edges',edges,'--prefix','none','--format','{p}|{f}',*extra]
        start=time.monotonic();r=subprocess.run(command,cwd=R,env=sdk.cargo_cache.build_environment(R/'target'),capture_output=True,text=True)
        (out/(name+'.stdout.log')).write_text(r.stdout);(out/(name+'.stderr.log')).write_text(r.stderr)
        guard();assert r.returncode==0,(name,r.stderr)
        store=[line for line in r.stdout.splitlines() if line.startswith('p2panda-store v0.7.1|')]
        sync=[line for line in r.stdout.splitlines() if line.startswith('p2panda-sync v0.7.1 ')]
        assert store,name
        records[name]={'command':command,'exit':r.returncode,'seconds':time.monotonic()-start,
                       'storeLines':sorted(set(store)), 'syncLines':sorted(set(sync)),
                       'sqlxPresent':any(line.startswith('sqlx v0.8.6|') for line in r.stdout.splitlines()),
                       'stdoutSha256':sha(out/(name+'.stdout.log')),'stderrSha256':sha(out/(name+'.stderr.log'))}
        print(json.dumps({'graph':name,'store':records[name]['storeLines'],'sqlx':records[name]['sqlxPresent']}),flush=True)
guard()
(out/'receipt.json').write_text(json.dumps({'sourceDigest':sdk.json_digest(sources),'allSourceLockToolInputsUnchanged':True,
    'cargoCompilationInvoked':False,'graphs':records,'fixedInputs':inputs},indent=2)+'\n')

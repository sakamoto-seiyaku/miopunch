import subprocess,sys,json
from pathlib import Path
H=Path('/tmp/miopunch-m97-20261019');driver=H/'build-v2.py'
plans=[('native-default-green','build',H/'current-default/Cargo.toml',[]),
 ('native-no-default-green','build',H/'current-no-default/Cargo.toml',[]),
 ('native-test-utils-green','build',H/'current-no-default/Cargo.toml',['--features','p2panda-sync/test_utils']),
 ('browser-traits-green','check',H/'browser-platform-selector/Cargo.toml',['--target','wasm32-unknown-unknown'])]
for name,action,manifest,extra in plans:
 cmd=[action,'--locked','--offline','--manifest-path',str(manifest),*extra,'--jobs','2']
 if action=='build':cmd+=['--bin','m97-native-store-consumer']
 for phase,args in [('prepare',cmd),('run',[])]:
  r=subprocess.run(['rtk','proxy','python3',str(driver),phase,name,*args]);assert r.returncode==0,(name,phase)
 if action=='build':
  r=subprocess.run(['rtk','proxy','python3',str(H/'run-consumer.py'),name]);assert r.returncode==0
print('GREEN isolated consumer cohort complete',flush=True)

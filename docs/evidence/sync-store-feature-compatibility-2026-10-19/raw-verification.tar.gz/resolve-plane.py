import html
import json
import re
import subprocess
from pathlib import Path

H = Path('/tmp/miopunch-m97-20261019')
OUT = H / 'plane-final'
OUT.mkdir(exist_ok=True)
M97 = '7b26895f-f16c-4ef6-bcdb-c239939358b7'
M91 = '6d5cd846-3c1b-4c21-977e-fdafc208f876'
DONE = '482063eb-b551-43e7-b35f-64371e164235'
BASE = ['rtk', 'proxy', '/home/js/.agents/skills/plane-ops/scripts/plane-ops.sh',
        '--defaults', 'docs/agents/plane-defaults.json']

def call(name, args):
    r = subprocess.run(BASE + args + ['--json'], capture_output=True, text=True, check=True)
    d = json.loads(r.stdout)
    (OUT / (name + '.json')).write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n')
    return d

def plain(s):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', s))).strip()

source = (H / 'source-commit.txt').read_text().strip()
evidence = (H / 'evidence-commit.txt').read_text().strip()
a = call('m97-before', ['work-item', 'get', M97])
parent = call('m91-before', ['work-item', 'get', M91])
relations = call('m97-relations-before', ['work-item', 'relations', 'list', M97])
comments = call('m97-comments-before', ['work-item', 'comments', 'list', M97])
assert a['parent'] == M91 and a['assignees'] == ['de705fdc-c1ec-4e53-b30d-8509dc7f5bc6']
assert a['description_html'].count('[ ]') == 4
assert source not in json.dumps(comments)
body = (H / 'resolution-template.html').read_text().replace('SOURCE_COMMIT', source).replace('EVIDENCE_COMMIT', evidence)
(OUT / 'resolution.html').write_text(body)
comment = call('m97-resolution', ['work-item', 'comments', 'create', M97, '--html', body])
assert comment.get('id')
requested = a['description_html'].replace('[ ]', '[x]')
call('m97-updated', ['work-item', 'update', M97, '--raw-json',
                    json.dumps({'state': DONE, 'description_html': requested}, ensure_ascii=False)])
marker = '<h2>Decisions so far</h2><ul>'
text = parent['description_html']
assert marker in text
start = text.index(marker) + len(marker)
end = text.index('</ul>', start)
url = 'http://192.168.4.22:2080/work/projects/aa58cd82-2afc-404b-a097-58ef553c7ca4/issues/' + M97
assert url not in text[start:end]
entry = f'<li><a href="{url}">MIOPUNCH-97：恢复 native sync 存储 defaults 并保留 Browser traits-only 图</a>：原消费者含 sync defaults=false 均恢复 SQLite／macros 事务和持久重开，显式声明 futures-channel/sink；正常／workspace／真实 own-dev／test-utils／WASI 图已区分核对。11 项持久化与副本测试、3 组当前 SDK（含 5 项权限／路径负例及 Browser 五记录完整保存、应用、重开、重复同步）通过，sync Rust／wire 不变。实施 {source[:8]}，证据 {evidence[:8]}；整体 M91 继续。</li>'

new_parent = text[:end] + entry + text[end:]
call('m91-updated', ['work-item', 'update', M91, '--raw-json',
                    json.dumps({'description_html': new_parent}, ensure_ascii=False)])
after = call('m97-readback', ['work-item', 'get', M97])
parent_after = call('m91-readback', ['work-item', 'get', M91])
relations_after = call('m97-relations-readback', ['work-item', 'relations', 'list', M97])
comments_after = call('m97-comments-readback', ['work-item', 'comments', 'list', M97])
assert after['state'] == DONE
for key in ['parent', 'labels', 'assignees', 'name', 'priority']:
    assert after[key] == a[key]
assert plain(after['description_html']) == plain(requested)
for key in ['state', 'parent', 'labels', 'assignees', 'name', 'priority']:
    assert parent_after[key] == parent[key]
assert plain(parent_after['description_html']) == plain(new_parent)

def ids(value):
    if isinstance(value, list):
        return [ids(v) for v in value]
    if isinstance(value, dict):
        return {k: ids(v) for k, v in value.items() if k in
                ['id', 'blocked_by', 'blocking', 'relates_to', 'duplicates', 'duplicate_of', 'start_after', 'start_before']}
    return value

assert ids(relations_after) == ids(relations)
serialized = json.dumps(comments_after, ensure_ascii=False)
assert comment['id'] in serialized and source in serialized and evidence in serialized
print(json.dumps({'m97State': 'Done', 'sourceCommit': source, 'evidenceCommit': evidence,
                  'resolutionComment': comment['id'], 'parentDecisionAdded': True,
                  'descriptionLabelsParentAssigneeAndRelationsVerified': True, 'm91RemainsOpen': True}))

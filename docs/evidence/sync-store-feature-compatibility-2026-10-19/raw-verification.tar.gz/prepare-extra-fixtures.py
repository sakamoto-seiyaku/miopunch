import hashlib,json,re,shutil,tomllib
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m97-20261019')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add_local_rows(lock,names):
    pattern=r'(\[\[package\]\]\nname = "mio83-replica-red-selected"[\s\S]*?dependencies = \[\n)([\s\S]*?)(\n\])'
    match=re.search(pattern,lock);assert match
    entries=set(re.findall(r' "([^"]+)",',match.group(2)))|set(names)
    result=lock[:match.start(2)]+'\n'.join(' "'+e+'",' for e in sorted(entries))+lock[match.end(2):]
    foreign=lambda s:[r for r in tomllib.loads(s)['package'] if r['name']!='mio83-replica-red-selected']
    assert foreign(lock)==foreign(result)
    return result
for name,parent,extra,names in [
    ('browser-platform-selector','browser-selector','getrandom02 = { package = "getrandom", version = "=0.2.17", features = ["js"] }\n',['getrandom 0.2.17']),
    ('current-storage-diagnostic','current-no-default','futures-channel = { version = "=0.3.34", features = ["sink"] }\n',['futures-channel'])]:
    d=H/name;d.mkdir()
    manifest=(H/parent/'Cargo.toml').read_text().replace('[patch.crates-io]',extra+'\n[patch.crates-io]')
    (d/'Cargo.toml').write_text(manifest)
    (d/'Cargo.lock').write_text(add_local_rows((H/parent/'Cargo.lock').read_text(),names))
dev=H/'dev-before';dev.mkdir()
copy=dev/'sync-package';shutil.copytree(R/'vendor/p2panda-sync',copy)
manifest=(H/'current-no-default/Cargo.toml').read_text().replace('[workspace]\nresolver = "2"','[workspace]\nresolver = "2"\nmembers = ["sync-package"]')
manifest=manifest.replace(str(R/'vendor/p2panda-sync'),str(copy))
(dev/'Cargo.toml').write_text(manifest);(dev/'Cargo.lock').write_bytes((H/'current-no-default/Cargo.lock').read_bytes())
driver=(H/'build.py').read_text()
driver=driver.replace("assert pin_rows(lock) == pin_rows(canonical), 'selector changed complete locked dependency rows'",
                     "foreign = lambda rows: [r for r in rows if r['name'] != 'mio83-replica-red-selected']\n        assert foreign(pin_rows(lock)) == foreign(pin_rows(canonical)), 'selector changed complete foreign dependency rows'")
(H/'build-v2.py').write_text(driver)
graph=(H/'inspect-graphs.py').read_text().replace("H/'browser-selector/Cargo.toml'","H/'browser-platform-selector/Cargo.toml'")
graph=graph.replace("H/'current-no-default/Cargo.toml',['-p','p2panda-sync'],True)","H/'dev-before/Cargo.toml',['-p','p2panda-sync'],True)")
graph=graph.replace("H/'browser-platform-selector/Cargo.toml',['-p','p2panda-sync'],True)","H/'dev-before/Cargo.toml',['-p','p2panda-sync'],True)")
graph=graph.replace("assert tomllib.loads((manifest.parent/'Cargo.lock').read_text())['package']==expected",
                    "assert [r for r in tomllib.loads((manifest.parent/'Cargo.lock').read_text())['package'] if r['name']!='mio83-replica-red-selected']==[r for r in expected if r['name']!='mio83-replica-red-selected']")
(H/'inspect-graphs-v2.py').write_text(graph)
(H/'extra-fixture-preparation.json').write_text(json.dumps({'browserPlatformOnlyAdjustment':'Explicit pinned getrandom 0.2/js and 0.4/wasm_js; no store or sync features added',
    'storageDiagnosticOnlyAdjustment':'Direct futures-channel/sink isolates storage capability loss after the unassisted fork failed its own Sink requirements',
    'devGraphRoot':'Workspace member source copy makes sync own dev-dependencies selected, unlike a dependency subtree',
    'devCopiedSourceHashes':{str(p):sha(p) for p in copy.rglob('*') if p.is_file()},
    'foreignLockRowsPreserved':True},indent=2)+'\n')
print('Prepared platform-only browser, isolated storage diagnostic, and real sync workspace-dev fixtures')

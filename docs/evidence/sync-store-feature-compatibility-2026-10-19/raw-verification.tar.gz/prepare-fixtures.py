import hashlib,json,re,tomllib
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m97-20261019');P=Path('/tmp/miopunch-m96-20261019')
OFFICIAL=Path('/tmp/miopunch-fork-audit-20261012/baselines/p2panda-sync/p2panda-sync-0.7.1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert all((R/'vendor/p2panda-sync'/p.relative_to(OFFICIAL)).read_bytes()==p.read_bytes()
           for p in (OFFICIAL/'src').rglob('*') if p.is_file())
base=(P/'baseline-selector/Cargo.toml').read_text().split('\n[[bin]]')[0]
# Add direct traits-only store access, so SQLite/macros can only come from sync.
extra='''p2panda-store = { version = "=0.7.1", default-features = false }
p2panda-sync = { version = "=0.7.1", default-features = SYNC_DEFAULT }
getrandom = { version = "=0.4.3", default-features = false, features = ["wasm_js"], optional = RANDOM_OPTIONAL }

'''
base=base.replace('[patch.crates-io]',extra+'[patch.crates-io]')
lock=(P/'baseline-selector/Cargo.lock').read_text()
pattern=r'(\[\[package\]\]\nname = "mio83-replica-red-selected"[\s\S]*?dependencies = \[\n)([\s\S]*?)(\n\])'
match=re.search(pattern,lock);assert match
entries=set(re.findall(r' "([^"]+)",',match.group(2)))
entries.update(['p2panda-store','p2panda-sync','getrandom 0.4.3'])
lock=lock[:match.start(2)]+'\n'.join(' "'+e+'",' for e in sorted(entries))+lock[match.end(2):]
rows=lambda s:[r for r in tomllib.loads(s)['package'] if r['name']!='mio83-replica-red-selected']
assert rows(lock)==rows((P/'baseline-selector/Cargo.lock').read_text())
variants=[('original-default',True,True,False),('original-no-default',True,False,False),
          ('current-default',False,True,False),('current-no-default',False,False,False),
          ('browser-selector',False,False,True)]
for name,official,defaults,browser in variants:
    d=H/name;d.mkdir()
    text=base.replace('SYNC_DEFAULT',str(defaults).lower()).replace('RANDOM_OPTIONAL',str(not browser).lower())
    if official:text=text.replace(str(R/'vendor/p2panda-sync'),str(OFFICIAL))
    if browser:
        text+='\n[lib]\npath = "'+str(H/'browser-store-consumer.rs')+'"\n'
    else:
        text=text.replace('tokio = { version = "=1.53.1", features = ["full"], optional = true }',
                          'tokio = { version = "=1.53.1", features = ["full"] }')
        assert 'tokio = { version = "=1.53.1", features = ["full"] }' in text
        text+='\n[[bin]]\nname = "m97-native-store-consumer"\npath = "'+str(H/'native-store-consumer.rs')+'"\n'
    (d/'Cargo.toml').write_text(text);(d/'Cargo.lock').write_text(lock)
canonical=H/'baseline-selector';canonical.mkdir()
(canonical/'Cargo.lock').write_text(lock)
fixed={str(p):sha(p) for p in [H/'native-store-consumer.rs',H/'browser-store-consumer.rs',
                              OFFICIAL/'Cargo.toml',*list((OFFICIAL/'src').rglob('*.rs'))]}
(H/'fixed-consumer-inputs.json').write_text(json.dumps(fixed,indent=2)+'\n')
driver=(P/'build.py').read_text().replace('miopunch-m96-20261019','miopunch-m97-20261019')
# Pin the latest completed SDKs; retain the independent historical counterpart fixture.
driver=driver.replace('/tmp/miopunch-m95-20261019/final-native-sdk','/tmp/miopunch-m96-20261019/final-native-sdk')
driver=driver.replace('/tmp/miopunch-m95-20261019/final-browser-sdk','/tmp/miopunch-m96-20261019/final-browser-sdk')
(H/'build.py').write_text(driver)
(H/'fixture-preparation.json').write_text(json.dumps({'officialAndForkRustSourcesIdentical':True,
    'allForeignLockedPackageRowsIdenticalToM96':True,'newDirectDependenciesOnlyInLocalSelectorRow':sorted(entries),
    'browserRandomBackend':'explicit existing pinned getrandom/wasm_js, as required by browser platform, without SQLite'},indent=2)+'\n')
print(json.dumps({'fixedInputs':len(fixed),'variants':len(variants),'foreignLockRowsUnchanged':True}))

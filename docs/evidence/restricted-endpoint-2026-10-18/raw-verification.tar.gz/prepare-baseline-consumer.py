import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path('/home/js/Git/miopunch')
HERE = Path('/tmp/miopunch-m92-20261018')
ORIGINAL = Path('/tmp/miopunch-fork-audit-20261012/baselines/iroh/iroh-1.2.0')
baseline = HERE / 'original-selector'
saved = HERE / 'original-baseline' / 'selector-inputs'
saved.mkdir()
for name in ['Cargo.toml', 'Cargo.lock']:
    shutil.copy2(baseline / name, saved / name)
shutil.copy2(HERE / 'fixed-consumer-inputs.json', saved / 'fixed-consumer-inputs.json')

manifest = f'''[package]
name = "m92-original-consumer"
version = "0.1.0"
edition = "2024"
publish = false
autobins = false

[workspace]
resolver = "2"

[[bin]]
name = "m92-original-consumer"
path = "{HERE}/original-consumer.rs"

[dependencies]
iroh = {{ path = "{ORIGINAL}", default-features = false, features = ["tls-ring"] }}

[patch.crates-io]
'''
for name in ['iroh-relay', 'noq', 'noq-proto', 'netwatch', 'portmapper']:
    manifest += f'{name} = {{ path = "{ROOT}/vendor/{name}" }}\n'
manifest += '\n[profile.dev]\ndebug = "line-tables-only"\nincremental = false\n\n[profile.test]\ndebug = "line-tables-only"\nincremental = false\n'
(baseline / 'Cargo.toml').write_text(manifest)
lock = (ROOT / 'Cargo.lock').read_text()
start = lock.index('[[package]]\nname = "miopunch-native-probe"\n')
end = lock.index('[[package]]', start + 1)
local = '[[package]]\nname = "m92-original-consumer"\nversion = "0.1.0"\ndependencies = [\n "iroh",\n]\n\n'
(baseline / 'Cargo.lock').write_text(lock[:start] + local + lock[end:])
fixed = json.loads((HERE / 'fixed-consumer-inputs.json').read_text())
for name in ['Cargo.toml', 'Cargo.lock']:
    fixed[str(baseline / name)] = hashlib.sha256((baseline / name).read_bytes()).hexdigest()
(HERE / 'fixed-consumer-inputs.json').write_text(json.dumps(fixed, indent=2) + '\n')
print('Prepared dependency consumer; only its local package lock record changed, no dependency resolution.')

//! Restricted consumers use the same public endpoint/stream seam as applications.

use std::{
    io,
    net::{Ipv4Addr, SocketAddr},
    sync::{Arc, Mutex},
    time::Duration,
};

use iroh::{
    Endpoint, EndpointAddr,
    endpoint::{
        AdmissionOutcome, AfterHandshakeOutcome, Connection, ControlConnection, EndpointAdmission,
        EndpointHooks, PortmapperConfig, RestrictedEndpoint, presets,
    },
};

const ALPN: &[u8] = b"test/restricted-endpoint/1";
const CONTROL_ALPN: &[u8] = b"test/restricted-control/1";
type Events = Arc<Mutex<Vec<String>>>;

#[derive(Debug)]
struct ExchangeAdmission {
    label: &'static str,
    events: Events,
}

impl EndpointAdmission for ExchangeAdmission {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        connection.send_control(b"authorized-control").await?;
        if connection.recv_control().await? != b"authorized-control" {
            return Err(io::Error::other("unexpected protected control message"));
        }
        self.events.lock().unwrap().push(format!("{}:gate", self.label));
        let path = connection.paths().iter().find(|path| path.is_ip())
            .ok_or_else(|| io::Error::other("no UDP candidate"))?.id();
        let permit = connection.qualify_data_path(path, Vec::new()).await?;
        self.events.lock().unwrap().push(format!("{}:path", self.label));
        Ok(AdmissionOutcome::Accept(permit))
    }

    fn is_current(&self, _connection: &ControlConnection) -> bool {
        true
    }
}

#[derive(Debug)]
struct LegacyCheck {
    label: &'static str,
    events: Events,
}

impl EndpointHooks for LegacyCheck {
    async fn after_handshake(&self, _connection: &Connection) -> AfterHandshakeOutcome {
        let mut events = self.events.lock().unwrap();
        assert!(events.contains(&format!("{}:gate", self.label)));
        assert!(events.contains(&format!("{}:path", self.label)));
        events.push(format!("{}:hook", self.label));
        AfterHandshakeOutcome::Accept
    }
}

async fn endpoint(label: &'static str, events: Events) -> RestrictedEndpoint {
    Endpoint::builder(presets::Minimal)
        .portmapper_config(PortmapperConfig::Disabled)
        .alpns(vec![ALPN.to_vec()])
        .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0)))
        .unwrap()
        .hooks(LegacyCheck { label, events: events.clone() })
        .restricted(ExchangeAdmission { label, events })
        .bind().await.unwrap()
}

fn direct(endpoint: &RestrictedEndpoint) -> EndpointAddr {
    EndpointAddr::new(endpoint.id()).with_addrs(
        endpoint.addr().ip_addrs().copied().map(iroh_base::TransportAddr::Ip),
    )
}

#[tokio::test]
async fn control_and_path_checks_precede_legacy_hook_and_original_connection_handoff() {
    let events = Events::default();
    let client = endpoint("client", events.clone()).await;
    let server = endpoint("server", events.clone()).await;
    let result = tokio::time::timeout(Duration::from_secs(10), async {
        tokio::join!(async {
            let connection: Connection = client.connect(direct(&server), ALPN).await.unwrap();
            events.lock().unwrap().push("client:handoff".to_string());
            let (mut send, mut recv) = connection.open_bi().await.unwrap();
            send.write_all(b"business-ping").await.unwrap();
            send.finish().unwrap();
            let reply = recv.read_to_end(64).await.unwrap();
            (connection, reply)
        }, async {
            let connection: Connection = server.accept().await.unwrap().await.unwrap();
            events.lock().unwrap().push("server:handoff".to_string());
            let (mut send, mut recv) = connection.accept_bi().await.unwrap();
            let request = recv.read_to_end(64).await.unwrap();
            send.write_all(b"business-pong").await.unwrap();
            send.finish().unwrap();
            (connection, request)
        })
    }).await;
    client.close().await;
    server.close().await;
    let ((_, reply), (_, request)) = result.expect("bounded restricted exchange");
    assert_eq!(request, b"business-ping");
    assert_eq!(reply, b"business-pong");
    let events = events.lock().unwrap();
    for label in ["client", "server"] {
        let actual: Vec<_> = events.iter().filter(|event| event.starts_with(label)).cloned().collect();
        assert_eq!(actual, ["gate", "path", "hook", "handoff"].map(|stage| format!("{label}:{stage}")));
    }
}

#[derive(Debug)]
struct ControlOnlyAdmission;

impl EndpointAdmission for ControlOnlyAdmission {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        connection.send_control(b"bootstrap-only").await?;
        if connection.recv_control().await? != b"bootstrap-only" {
            return Err(io::Error::other("incorrect bootstrap proof"));
        }
        Ok(AdmissionOutcome::ControlOnly)
    }

    fn is_current(&self, _connection: &ControlConnection) -> bool {
        true
    }
}

#[derive(Debug)]
struct BusinessHookMustNotRun;

impl EndpointHooks for BusinessHookMustNotRun {
    async fn after_handshake(&self, _connection: &Connection) -> AfterHandshakeOutcome {
        panic!("a control-only scope must not expose Connection to a business hook")
    }
}

#[tokio::test]
async fn control_only_admission_delivers_framed_control_without_business_handoff() {
    let bind = || async {
        Endpoint::builder(presets::Minimal)
            .portmapper_config(PortmapperConfig::Disabled)
            .alpns(vec![ALPN.to_vec()])
            .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0))).unwrap()
            .hooks(BusinessHookMustNotRun)
            .restricted(ControlOnlyAdmission)
            .bind().await.unwrap()
    };
    let client = bind().await;
    let server = bind().await;
    let result = tokio::time::timeout(Duration::from_secs(10), async {
        tokio::join!(async {
            let connection: ControlConnection = client.connect_control(direct(&server), ALPN).await.unwrap();
            connection.send_control(b"admission-request").await.unwrap();
            let response = connection.recv_control().await.unwrap();
            (connection, response)
        }, async {
            let connection: ControlConnection = server.accept().await.unwrap().accept_control().unwrap().await.unwrap();
            let request = connection.recv_control().await.unwrap();
            connection.send_control(b"awaiting-approval").await.unwrap();
            (connection, request)
        })
    }).await;
    client.close().await;
    server.close().await;
    let ((_, response), (_, request)) = result.expect("bounded control-only exchange");
    assert_eq!(request, b"admission-request");
    assert_eq!(response, b"awaiting-approval");
}

#[derive(Debug)]
struct RoutingAdmission(ExchangeAdmission);

impl EndpointAdmission for RoutingAdmission {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        if connection.alpn() == CONTROL_ALPN {
            EndpointAdmission::admit(&ControlOnlyAdmission, connection).await
        } else {
            EndpointAdmission::admit(&self.0, connection).await
        }
    }

    fn is_current(&self, _connection: &ControlConnection) -> bool {
        true
    }
}

#[derive(Debug)]
struct RoutedBusiness;

impl iroh::protocol::ProtocolHandler for RoutedBusiness {
    async fn on_accepting(&self, _accepting: iroh::endpoint::Accepting)
        -> Result<Connection, iroh::protocol::AcceptError>
    {
        panic!("restricted routing must not expose the ordinary Accepting state")
    }

    async fn accept(&self, connection: Connection) -> Result<(), iroh::protocol::AcceptError> {
        let (mut send, mut recv) = connection.accept_bi().await?;
        let message = recv.read_to_end(64).await.map_err(iroh::protocol::AcceptError::from_err)?;
        send.write_all(&message).await.map_err(iroh::protocol::AcceptError::from_err)?;
        send.finish()?;
        send.stopped().await.map_err(iroh::protocol::AcceptError::from_err)?;
        Ok(())
    }
}

#[derive(Debug)]
struct RoutedControl;

impl iroh::protocol::ControlProtocolHandler for RoutedControl {
    async fn accept(&self, connection: ControlConnection) -> Result<(), iroh::protocol::AcceptError> {
        let message = connection.recv_control().await?;
        connection.send_control(&message).await?;
        let done = connection.recv_control().await?;
        assert_eq!(done, b"done");
        Ok(())
    }
}

#[tokio::test]
async fn restricted_router_delivers_original_business_and_separate_control_handlers() {
    use iroh::protocol::RestrictedRouter;
    let events = Events::default();
    let bind = |label| {
        let events = events.clone();
        async move {
            Endpoint::builder(presets::Minimal)
                .portmapper_config(PortmapperConfig::Disabled)
                .alpns(vec![ALPN.to_vec(), CONTROL_ALPN.to_vec()])
                .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0))).unwrap()
                .hooks(LegacyCheck { label, events: events.clone() })
                .restricted(RoutingAdmission(ExchangeAdmission { label, events }))
                .bind().await.unwrap()
        }
    };
    let client = bind("client").await;
    let server = bind("server").await;
    let router = RestrictedRouter::builder(server.clone())
        .accept(ALPN, RoutedBusiness)
        .accept_control(CONTROL_ALPN, RoutedControl)
        .spawn();
    let result = tokio::time::timeout(Duration::from_secs(10), async {
        let connection: Connection = client.connect(direct(router.endpoint()), ALPN).await.unwrap();
        let (mut send, mut recv) = connection.open_bi().await.unwrap();
        send.write_all(b"routed-business").await.unwrap();
        send.finish().unwrap();
        let business = recv.read_to_end(64).await.unwrap();
        let control = client.connect_control(direct(router.endpoint()), CONTROL_ALPN).await.unwrap();
        control.send_control(b"routed-control").await.unwrap();
        let bootstrap = control.recv_control().await.unwrap();
        control.send_control(b"done").await.unwrap();
        (connection, control, business, bootstrap)
    }).await;
    client.close().await;
    router.shutdown().await.unwrap();
    let (_, _, business, bootstrap) = result.expect("bounded restricted routing");
    assert_eq!(business, b"routed-business");
    assert_eq!(bootstrap, b"routed-control");
}

#[derive(Debug)]
struct WaitingAdmission {
    entered: Arc<tokio::sync::Notify>,
}

impl EndpointAdmission for WaitingAdmission {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        connection.send_control(b"wait-for-decision").await?;
        if connection.recv_control().await? != b"wait-for-decision" {
            return Err(io::Error::other("incorrect control phase"));
        }
        self.entered.notify_one();
        std::future::pending().await
    }

    fn is_current(&self, _connection: &ControlConnection) -> bool {
        true
    }
}

async fn waiting_endpoint(entered: Arc<tokio::sync::Notify>) -> RestrictedEndpoint {
    Endpoint::builder(presets::Minimal)
        .portmapper_config(PortmapperConfig::Disabled)
        .alpns(vec![ALPN.to_vec()])
        .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0))).unwrap()
        .hooks(BusinessHookMustNotRun)
        .restricted(WaitingAdmission { entered })
        .admission_timeout(Duration::from_secs(10))
        .bind().await.unwrap()
}

#[tokio::test]
async fn cancellation_closes_original_attempt_and_releases_the_peers_pending_policy() {
    let client_entered = Arc::new(tokio::sync::Notify::new());
    let server_entered = Arc::new(tokio::sync::Notify::new());
    let client = waiting_endpoint(client_entered.clone()).await;
    let server = waiting_endpoint(server_entered.clone()).await;
    let token = tokio_util::sync::CancellationToken::new();
    let receiver = server.clone();
    let mut incoming = tokio::spawn(async move { receiver.accept().await.unwrap().await });
    let attempt = client.connect_with_opts(direct(&server), ALPN,
        iroh::endpoint::ConnectOptions::new().with_attempt_cancellation(token.clone()),
    ).await.unwrap();
    let mut outgoing = tokio::spawn(async move { attempt.await });
    let entered = tokio::time::timeout(Duration::from_secs(3), async {
        tokio::join!(client_entered.notified(), server_entered.notified());
    }).await;
    token.cancel();
    let outgoing_result = tokio::time::timeout(Duration::from_secs(2), &mut outgoing).await;
    let incoming_result = tokio::time::timeout(Duration::from_secs(2), &mut incoming).await;
    if outgoing_result.is_err() {
        outgoing.abort();
        let _ = outgoing.await;
    }
    if incoming_result.is_err() {
        incoming.abort();
        let _ = incoming.await;
    }
    client.close().await;
    server.close().await;
    assert!(entered.is_ok(), "both real policies entered the protected wait");
    let outgoing = outgoing_result.expect("cancellation must finish the local attempt");
    let incoming = incoming_result.expect("peer closure must release pending policy without waiting for its setup deadline");
    assert!(matches!(outgoing.unwrap(), Err(iroh::endpoint::ConnectingError::AttemptCancelled { .. })));
    assert!(matches!(incoming.unwrap(), Err(iroh::endpoint::ConnectingError::ConnectionError { .. })));
}

#[derive(Debug)]
struct RevocableAdmission {
    exchange: ExchangeAdmission,
    retained: Arc<Mutex<Option<iroh::endpoint::WeakControlConnection>>>,
}

impl EndpointAdmission for RevocableAdmission {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        *self.retained.lock().unwrap() = Some(connection.weak_handle());
        EndpointAdmission::admit(&self.exchange, connection).await
    }

    fn is_current(&self, _connection: &ControlConnection) -> bool {
        true
    }
}

#[tokio::test]
async fn restricted_policy_can_revoke_after_original_connection_handoff_without_a_business_handle() {
    let events = Events::default();
    let retained = Arc::new(Mutex::new(None));
    let client = endpoint("client", events.clone()).await;
    let server = Endpoint::builder(presets::Minimal)
        .portmapper_config(PortmapperConfig::Disabled)
        .alpns(vec![ALPN.to_vec()])
        .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0))).unwrap()
        .hooks(LegacyCheck { label: "server", events: events.clone() })
        .restricted(RevocableAdmission {
            exchange: ExchangeAdmission { label: "server", events },
            retained: retained.clone(),
        }).bind().await.unwrap();
    let connections = tokio::time::timeout(Duration::from_secs(5), async {
        tokio::join!(client.connect(direct(&server), ALPN), async {
            server.accept().await.unwrap().await
        })
    }).await;
    let result = if let Ok((Ok(outgoing), Ok(incoming))) = &connections {
        let weak = retained.lock().unwrap().as_ref().unwrap().clone();
        assert!(weak.is_open());
        assert!(weak.close(7u32.into(), b"authorization revoked"));
        let closed = tokio::time::timeout(Duration::from_secs(2), async {
            tokio::join!(outgoing.closed(), incoming.closed())
        }).await;
        let refuses_stream = incoming.open_bi().await.is_err();
        Some((closed, refuses_stream, weak.is_open()))
    } else { None };
    client.close().await;
    server.close().await;
    let (closed, refuses_stream, still_open) = result.expect("ordinary connections were handed off");
    assert!(closed.is_ok(), "revocation reaches both original connections");
    assert!(refuses_stream);
    assert!(!still_open);
}

async fn configured<P: EndpointAdmission + 'static, H: EndpointHooks + 'static>(
    policy: P, hooks: H,
) -> RestrictedEndpoint {
    Endpoint::builder(presets::Minimal)
        .portmapper_config(PortmapperConfig::Disabled)
        .alpns(vec![ALPN.to_vec()])
        .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0))).unwrap()
        .hooks(hooks)
        .restricted(policy)
        .admission_timeout(Duration::from_secs(3))
        .bind().await.unwrap()
}

async fn rejected_policy(policy: impl EndpointAdmission + 'static) {
    let client = endpoint("client", Events::default()).await;
    let server = configured(policy, BusinessHookMustNotRun).await;
    let result = tokio::time::timeout(Duration::from_secs(5), async {
        tokio::join!(client.connect(direct(&server), ALPN), async {
            server.accept().await.unwrap().await
        })
    }).await;
    client.close().await;
    server.close().await;
    let (outgoing, incoming) = result.expect("rejected admission is bounded");
    assert!(incoming.is_err(), "server must not hand off business: {incoming:?}");
    assert!(outgoing.is_err(), "peer must not hand off business: {outgoing:?}");
}

#[derive(Debug)]
struct MissingDecision;
impl EndpointAdmission for MissingDecision {
    fn is_current(&self, _connection: &ControlConnection) -> bool { true }
}

#[tokio::test]
async fn missing_decision_does_not_reach_legacy_hooks_or_business() {
    rejected_policy(MissingDecision).await;
}

#[derive(Debug)]
struct DenyAdmission;
impl EndpointAdmission for DenyAdmission {
    async fn admit(&self, _connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        Ok(AdmissionOutcome::Reject { error_code: 7u32.into(), reason: b"not authorized".to_vec() })
    }
    fn is_current(&self, _connection: &ControlConnection) -> bool { true }
}

#[tokio::test]
async fn explicit_rejection_does_not_reach_legacy_hooks_or_business() {
    rejected_policy(DenyAdmission).await;
}

#[derive(Debug)]
struct MissingDataPath;
impl EndpointAdmission for MissingDataPath {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        connection.send_control(b"authorized-control").await?;
        if connection.recv_control().await? != b"authorized-control" {
            return Err(io::Error::other("incorrect control proof"));
        }
        connection.qualify_data_path(iroh::endpoint::PathId::MAX, Vec::new())
            .await.map(AdmissionOutcome::Accept)
    }
    fn is_current(&self, _connection: &ControlConnection) -> bool { true }
}

#[tokio::test]
async fn unqualified_path_does_not_reach_legacy_hooks_or_business() {
    rejected_policy(MissingDataPath).await;
}

#[derive(Debug)]
struct RejectAfterChecks(LegacyCheck);
impl EndpointHooks for RejectAfterChecks {
    async fn after_handshake(&self, connection: &Connection) -> AfterHandshakeOutcome {
        EndpointHooks::after_handshake(&self.0, connection).await;
        AfterHandshakeOutcome::Reject { error_code: 9u32.into(), reason: b"legacy veto".to_vec() }
    }
}

#[tokio::test]
async fn legacy_hook_rejects_after_new_checks_before_either_business_handoff() {
    let events = Events::default();
    let client = endpoint("client", events.clone()).await;
    let server = configured(
        ExchangeAdmission { label: "server", events: events.clone() },
        RejectAfterChecks(LegacyCheck { label: "server", events: events.clone() }),
    ).await;
    let result = tokio::time::timeout(Duration::from_secs(5), async {
        tokio::join!(client.connect(direct(&server), ALPN), async {
            server.accept().await.unwrap().await
        })
    }).await;
    client.close().await;
    server.close().await;
    let (outgoing, incoming) = result.expect("legacy veto is bounded");
    assert!(incoming.is_err());
    assert!(outgoing.is_err());
    let events = events.lock().unwrap();
    let server_events: Vec<_> = events.iter().filter(|event| event.starts_with("server")).cloned().collect();
    assert_eq!(server_events, ["server:gate", "server:path", "server:hook"]);
}

#[tokio::test]
async fn control_only_decision_cannot_be_used_by_business_connect_or_incoming_future() {
    let client = configured(ControlOnlyAdmission, BusinessHookMustNotRun).await;
    let server = configured(ControlOnlyAdmission, BusinessHookMustNotRun).await;
    let result = tokio::time::timeout(Duration::from_secs(5), async {
        tokio::join!(client.connect(direct(&server), ALPN), async {
            server.accept().await.unwrap().await
        })
    }).await;
    client.close().await;
    server.close().await;
    let (outgoing, incoming) = result.expect("scope mismatch is bounded");
    assert!(incoming.is_err());
    assert!(outgoing.is_err());
}

#[tokio::test]
async fn accept_with_and_alpn_inspection_preserve_restricted_delivery() {
    let events = Events::default();
    let client = endpoint("client", events.clone()).await;
    let server = endpoint("server", events.clone()).await;
    let config = Arc::new(server.create_server_config_builder(vec![ALPN.to_vec()]).build());
    let result = tokio::time::timeout(Duration::from_secs(5), async {
        let (outgoing, (incoming, alpn, not_admitted_early)) = tokio::join!(
            client.connect(direct(&server), ALPN), async {
                let mut accepting = server.accept().await.unwrap().accept_with(config).unwrap();
                let alpn = accepting.alpn().await.unwrap();
                let not_admitted_early = events.lock().unwrap().is_empty();
                (accepting.await, alpn, not_admitted_early)
            }
        );
        let outgoing = outgoing.unwrap();
        let incoming = incoming.unwrap();
        let (reply, request) = tokio::join!(async {
            let (mut send, mut recv) = outgoing.open_bi().await.unwrap();
            send.write_all(b"custom-config-ping").await.unwrap();
            send.finish().unwrap();
            recv.read_to_end(64).await.unwrap()
        }, async {
            let (mut send, mut recv) = incoming.accept_bi().await.unwrap();
            let request = recv.read_to_end(64).await.unwrap();
            send.write_all(b"custom-config-pong").await.unwrap();
            send.finish().unwrap();
            request
        });
        (outgoing, incoming, alpn, not_admitted_early, reply, request)
    }).await;
    client.close().await;
    server.close().await;
    let (_, _, alpn, not_admitted_early, reply, request) = result.expect("custom accepting path is bounded");
    assert_eq!(alpn, ALPN);
    assert!(not_admitted_early, "ALPN inspection cannot run or bypass admission");
    assert_eq!(request, b"custom-config-ping");
    assert_eq!(reply, b"custom-config-pong");
}

#[tokio::test]
async fn dropping_pending_future_closes_original_connection_and_releases_peer() {
    let client_entered = Arc::new(tokio::sync::Notify::new());
    let server_entered = Arc::new(tokio::sync::Notify::new());
    let client = waiting_endpoint(client_entered.clone()).await;
    let server = waiting_endpoint(server_entered.clone()).await;
    let receiver = server.clone();
    let mut incoming = tokio::spawn(async move { receiver.accept().await.unwrap().await });
    let attempt = client.connect_with_opts(direct(&server), ALPN, Default::default()).await.unwrap();
    let outgoing = tokio::spawn(async move { attempt.await });
    let entered = tokio::time::timeout(Duration::from_secs(3), async {
        tokio::join!(client_entered.notified(), server_entered.notified());
    }).await;
    // Abort drops the pending future; it does not close either endpoint or
    // manually close the underlying connection being tested.
    outgoing.abort();
    let outgoing = outgoing.await;
    let result = tokio::time::timeout(Duration::from_secs(2), &mut incoming).await;
    if result.is_err() {
        incoming.abort();
        let _ = incoming.await;
    }
    client.close().await;
    server.close().await;
    assert!(entered.is_ok());
    assert!(outgoing.unwrap_err().is_cancelled());
    assert!(matches!(result.expect("dropping local pending owner closes peer").unwrap(),
        Err(iroh::endpoint::ConnectingError::ConnectionError { .. })));
}

#[tokio::test]
async fn original_caller_deadline_bounds_control_wait_and_releases_peer() {
    let client_entered = Arc::new(tokio::sync::Notify::new());
    let server_entered = Arc::new(tokio::sync::Notify::new());
    let client = waiting_endpoint(client_entered.clone()).await;
    let server = waiting_endpoint(server_entered.clone()).await;
    let deadline = n0_future::time::Instant::now() + Duration::from_millis(500);
    let result = tokio::time::timeout(Duration::from_secs(3), async {
        tokio::join!(async {
            client.connect_with_opts(direct(&server), ALPN,
                iroh::endpoint::ConnectOptions::new().with_caller_deadline(deadline),
            ).await.unwrap().await
        }, async { server.accept().await.unwrap().await })
    }).await;
    let entered = tokio::time::timeout(Duration::from_millis(50), async {
        tokio::join!(client_entered.notified(), server_entered.notified());
    }).await;
    client.close().await;
    server.close().await;
    assert!(entered.is_ok(), "both policies reached control before the caller deadline");
    let (outgoing, incoming) = result.expect("original deadline bounds the whole wait");
    assert!(matches!(outgoing, Err(iroh::endpoint::ConnectingError::AttemptTimedOut { .. })));
    assert!(matches!(incoming, Err(iroh::endpoint::ConnectingError::ConnectionError { .. })));
}

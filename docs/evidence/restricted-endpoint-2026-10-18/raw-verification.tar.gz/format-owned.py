import difflib
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/home/js/Git/miopunch')
HERE = Path('/tmp/miopunch-m92-20261018')
BASE = 'c08e9b4b32350f0588b533d6617b31fe9c724b62'
DIRECT = [ROOT/'vendor/iroh/src/endpoint/restricted.rs', ROOT/'tests/restricted_endpoint.rs',
          *sorted((ROOT/'tests/restricted_endpoint_consumers').glob('*.rs'))]
EXISTING = ['vendor/iroh/src/endpoint.rs', 'vendor/iroh/src/endpoint/connection.rs',
            'vendor/iroh/src/protocol.rs', 'vendor/iroh/src/socket.rs']

out = HERE/'formatting'
out.mkdir(exist_ok=False)
report = []
for path in DIRECT:
    old = path.read_bytes()
    subprocess.run(['rtk','proxy','rustfmt','--edition','2024','--config','skip_children=true',str(path)], check=True, cwd=ROOT)
    report.append({'path':str(path.relative_to(ROOT)), 'newFileFormatted':True,
        'beforeSha256':hashlib.sha256(old).hexdigest(), 'afterSha256':hashlib.sha256(path.read_bytes()).hexdigest()})
for name in EXISTING:
    path = ROOT/name
    baseline = subprocess.check_output(['rtk','proxy','git','show',BASE+':'+name],cwd=ROOT,text=True).splitlines(keepends=True)
    current = path.read_text().splitlines(keepends=True)
    owned = [(j1,j2) for tag,i1,i2,j1,j2 in difflib.SequenceMatcher(None,baseline,current,autojunk=False).get_opcodes() if tag!='equal' and j1!=j2]
    copy = out/(name.replace('/','_'))
    copy.write_text(''.join(current))
    subprocess.run(['rtk','proxy','rustfmt','--edition','2024','--config','skip_children=true',str(copy)],check=True,cwd=ROOT)
    formatted = copy.read_text().splitlines(keepends=True)
    merged=[]; selected=0; preserved=0
    for tag,i1,i2,j1,j2 in difflib.SequenceMatcher(None,current,formatted,autojunk=False).get_opcodes():
        touches = any((i1<end and i2>start) if i1!=i2 else start<=i1<end for start,end in owned)
        if tag!='equal' and touches:
            merged.extend(formatted[j1:j2]);selected+=1
        else:
            merged.extend(current[i1:i2]);preserved+=tag!='equal'
    path.write_text(''.join(merged))
    report.append({'path':name,'ownedFormattingChanges':selected,'preservedPreexistingFormattingDifferences':preserved,
        'beforeSha256':hashlib.sha256(''.join(current).encode()).hexdigest(), 'afterSha256':hashlib.sha256(path.read_bytes()).hexdigest()})
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))

import hashlib
import json
import re
import shutil
import tomllib
from pathlib import Path

ROOT = Path('/home/js/Git/miopunch')
HERE = Path('/tmp/miopunch-m92-20261018')
ORIGINAL = Path('/tmp/miopunch-fork-audit-20261012/baselines/iroh/iroh-1.2.0')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

# Preserve the original consumer before changing any production source. These
# are the two known source breaks; M92 adds a parallel interface, while M95
# restores these original contracts after the SDK migrations.
consumer = HERE / 'original-consumer.rs'
consumer.write_text('''use iroh::endpoint::{Accepting, AfterHandshakeOutcome, IncomingZeroRttConnection};

fn incoming(accepting: Accepting) -> IncomingZeroRttConnection {
    accepting.into_0rtt()
}

fn outcome(result: AfterHandshakeOutcome) -> bool {
    match result {
        AfterHandshakeOutcome::Accept => true,
        AfterHandshakeOutcome::Reject { .. } => false,
    }
}

fn main() {
    let _ = incoming;
    assert!(outcome(AfterHandshakeOutcome::Accept));
}
''')

baseline = HERE / 'original-selector'
baseline.mkdir()
manifest = (ROOT / 'vendor/iroh/Cargo.toml').read_text()
manifest = manifest.replace('path = "src/lib.rs"', f'path = "{ORIGINAL}/src/lib.rs"')
manifest = manifest.replace('build = "build.rs"', f'build = "{ORIGINAL}/build.rs"')
manifest = manifest.replace('readme = "README.md"', f'readme = "{ORIGINAL}/README.md"')
manifest += f'\n[workspace]\n\n[[example]]\nname = "m92-original-consumer"\npath = "{consumer}"\n\n[patch.crates-io]\n'
for name in ['iroh-relay', 'noq', 'noq-proto', 'netwatch', 'portmapper']:
    manifest += f'{name} = {{ path = "{ROOT}/vendor/{name}" }}\n'
manifest += '\n[profile.dev]\ndebug = "line-tables-only"\nincremental = false\n\n[profile.test]\ndebug = "line-tables-only"\nincremental = false\n'
(baseline / 'Cargo.toml').write_text(manifest)
shutil.copy2(ROOT / 'Cargo.lock', baseline / 'Cargo.lock')

selected = HERE / 'selector'
selected.mkdir()
old = Path('/tmp/miopunch-native-socket-api-20261012/selector')
manifest = (old / 'Cargo.toml').read_text()
manifest += f'\n[[test]]\nname = "restricted_endpoint"\npath = "{ROOT}/tests/restricted_endpoint.rs"\n'
manifest += f'\n[[test]]\nname = "admission_gate"\npath = "{ROOT}/tests/admission_gate.rs"\n'
manifest += f'\n[[test]]\nname = "mqtt_upgrade"\npath = "{ROOT}/tests/mqtt_upgrade.rs"\n'
(selected / 'Cargo.toml').write_text(manifest)
shutil.copy2(old / 'Cargo.lock', selected / 'Cargo.lock')

frozen = {str(consumer): sha(consumer)}
for p in [baseline, selected]:
    frozen[str(p / 'Cargo.toml')] = sha(p / 'Cargo.toml')
    frozen[str(p / 'Cargo.lock')] = sha(p / 'Cargo.lock')
for p in ORIGINAL.rglob('*'):
    if p.is_file() and (p.suffix == '.rs' or p.name in {'Cargo.toml', 'build.rs'}):
        frozen[str(p)] = sha(p)
(HERE / 'fixed-consumer-inputs.json').write_text(json.dumps(frozen, indent=2) + '\n')
print(json.dumps({'fixedConsumerSha256': sha(consumer), 'baselineLibrarySource': str(ORIGINAL), 'baselineDependencyLock': sha(baseline / 'Cargo.lock'), 'testSelectorLock': sha(selected / 'Cargo.lock')}))

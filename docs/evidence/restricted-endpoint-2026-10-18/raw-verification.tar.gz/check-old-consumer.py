import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m92-20261018')
sys.path.insert(0,str(ROOT/'scripts'));import cargo_cache
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
r=json.loads((H/'typed-consumers-final/receipt.json').read_text());assert r['passed']
c=json.loads((H/'verified-affected-tests-v5-context.json').read_text());p=H/'original-consumer.rs';assert sha(p)=='e59e299a02e620408c28b0398b1e3ec8ab451ce9f9111e37af2f68e61bdcc769'
rlib=next((H/'typed-consumers-final/pinned').glob('libiroh-*.rlib'));inputs={**r['inputs'],str(rlib):r['librarySha256'],str(p):sha(p),str(Path(__file__)):sha(__file__)}
def guard():assert all(sha(p)==h for p,h in inputs.items())
guard();o=H/'original-consumer-current-known-breaks';o.mkdir(exist_ok=False)
with cargo_cache.cache_lease(ROOT/'target'):
 guard();command=['rtk','proxy',c['tools']['stableToolchain']['rustc'],'--edition=2024','--crate-type=lib','--emit=metadata','--error-format=json','--extern',f'iroh={rlib}','-L',f'dependency={ROOT}/target/debug/deps','--out-dir',str(o),str(p)]
 result=subprocess.run(command,capture_output=True,text=True,timeout=60);(o/'stderr.jsonl').write_text(result.stderr);(o/'stdout.log').write_text(result.stdout);guard()
 errors=[]
 for s in result.stderr.splitlines():
  try:d=json.loads(s)
  except:continue
  if d.get('level')=='error' and d.get('code'):errors.append(d['code']['code'])
 report={'command':command,'exit':result.returncode,'consumerSha256':sha(p),'expectedKnownBreaks':['E0004','E0308'],'actualErrors':sorted(errors),'knownBreaksConfirmed':result.returncode!=0 and set(errors)=={'E0004','E0308'},'compatibilityPassed':False,'deferredTask':'MIOPUNCH-95','inputs':inputs}
 (o/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k not in ['inputs','command']});assert report['knownBreaksConfirmed']

//! Restricted consumers use the same public endpoint/stream seam as applications.

use std::{
    io,
    net::{Ipv4Addr, SocketAddr},
    sync::{Arc, Mutex},
    time::Duration,
};

use iroh::{
    Endpoint, EndpointAddr,
    endpoint::{
        AdmissionOutcome, AfterHandshakeOutcome, Connection, ControlConnection, EndpointAdmission,
        EndpointHooks, PortmapperConfig, RestrictedEndpoint, presets,
    },
};

const ALPN: &[u8] = b"test/restricted-endpoint/1";
const CONTROL_ALPN: &[u8] = b"test/restricted-control/1";
type Events = Arc<Mutex<Vec<String>>>;

#[derive(Debug)]
struct ExchangeAdmission {
    label: &'static str,
    events: Events,
}

impl EndpointAdmission for ExchangeAdmission {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        connection.send_control(b"authorized-control").await?;
        if connection.recv_control().await? != b"authorized-control" {
            return Err(io::Error::other("unexpected protected control message"));
        }
        self.events.lock().unwrap().push(format!("{}:gate", self.label));
        let path = connection.paths().iter().find(|path| path.is_ip())
            .ok_or_else(|| io::Error::other("no UDP candidate"))?.id();
        let permit = connection.qualify_data_path(path, Vec::new()).await?;
        self.events.lock().unwrap().push(format!("{}:path", self.label));
        Ok(AdmissionOutcome::Accept(permit))
    }

    fn is_current(&self, _connection: &ControlConnection) -> bool {
        true
    }
}

#[derive(Debug)]
struct LegacyCheck {
    label: &'static str,
    events: Events,
}

impl EndpointHooks for LegacyCheck {
    async fn after_handshake(&self, _connection: &Connection) -> AfterHandshakeOutcome {
        let mut events = self.events.lock().unwrap();
        assert!(events.contains(&format!("{}:gate", self.label)));
        assert!(events.contains(&format!("{}:path", self.label)));
        events.push(format!("{}:hook", self.label));
        AfterHandshakeOutcome::Accept
    }
}

async fn endpoint(label: &'static str, events: Events) -> RestrictedEndpoint {
    Endpoint::builder(presets::Minimal)
        .portmapper_config(PortmapperConfig::Disabled)
        .alpns(vec![ALPN.to_vec()])
        .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0)))
        .unwrap()
        .hooks(LegacyCheck { label, events: events.clone() })
        .restricted(ExchangeAdmission { label, events })
        .bind().await.unwrap()
}

fn direct(endpoint: &RestrictedEndpoint) -> EndpointAddr {
    EndpointAddr::new(endpoint.id()).with_addrs(
        endpoint.addr().ip_addrs().copied().map(iroh_base::TransportAddr::Ip),
    )
}

#[tokio::test]
async fn control_and_path_checks_precede_legacy_hook_and_original_connection_handoff() {
    let events = Events::default();
    let client = endpoint("client", events.clone()).await;
    let server = endpoint("server", events.clone()).await;
    let result = tokio::time::timeout(Duration::from_secs(10), async {
        tokio::join!(async {
            let connection: Connection = client.connect(direct(&server), ALPN).await.unwrap();
            events.lock().unwrap().push("client:handoff".to_string());
            let (mut send, mut recv) = connection.open_bi().await.unwrap();
            send.write_all(b"business-ping").await.unwrap();
            send.finish().unwrap();
            let reply = recv.read_to_end(64).await.unwrap();
            (connection, reply)
        }, async {
            let connection: Connection = server.accept().await.unwrap().await.unwrap();
            events.lock().unwrap().push("server:handoff".to_string());
            let (mut send, mut recv) = connection.accept_bi().await.unwrap();
            let request = recv.read_to_end(64).await.unwrap();
            send.write_all(b"business-pong").await.unwrap();
            send.finish().unwrap();
            (connection, request)
        })
    }).await;
    client.close().await;
    server.close().await;
    let ((_, reply), (_, request)) = result.expect("bounded restricted exchange");
    assert_eq!(request, b"business-ping");
    assert_eq!(reply, b"business-pong");
    let events = events.lock().unwrap();
    for label in ["client", "server"] {
        let actual: Vec<_> = events.iter().filter(|event| event.starts_with(label)).cloned().collect();
        assert_eq!(actual, ["gate", "path", "hook", "handoff"].map(|stage| format!("{label}:{stage}")));
    }
}

#[derive(Debug)]
struct ControlOnlyAdmission;

impl EndpointAdmission for ControlOnlyAdmission {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        connection.send_control(b"bootstrap-only").await?;
        if connection.recv_control().await? != b"bootstrap-only" {
            return Err(io::Error::other("incorrect bootstrap proof"));
        }
        Ok(AdmissionOutcome::ControlOnly)
    }

    fn is_current(&self, _connection: &ControlConnection) -> bool {
        true
    }
}

#[derive(Debug)]
struct BusinessHookMustNotRun;

impl EndpointHooks for BusinessHookMustNotRun {
    async fn after_handshake(&self, _connection: &Connection) -> AfterHandshakeOutcome {
        panic!("a control-only scope must not expose Connection to a business hook")
    }
}

#[tokio::test]
async fn control_only_admission_delivers_framed_control_without_business_handoff() {
    let bind = || async {
        Endpoint::builder(presets::Minimal)
            .portmapper_config(PortmapperConfig::Disabled)
            .alpns(vec![ALPN.to_vec()])
            .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0))).unwrap()
            .hooks(BusinessHookMustNotRun)
            .restricted(ControlOnlyAdmission)
            .bind().await.unwrap()
    };
    let client = bind().await;
    let server = bind().await;
    let result = tokio::time::timeout(Duration::from_secs(10), async {
        tokio::join!(async {
            let connection: ControlConnection = client.connect_control(direct(&server), ALPN).await.unwrap();
            connection.send_control(b"admission-request").await.unwrap();
            let response = connection.recv_control().await.unwrap();
            (connection, response)
        }, async {
            let connection: ControlConnection = server.accept().await.unwrap().accept_control().unwrap().await.unwrap();
            let request = connection.recv_control().await.unwrap();
            connection.send_control(b"awaiting-approval").await.unwrap();
            (connection, request)
        })
    }).await;
    client.close().await;
    server.close().await;
    let ((_, response), (_, request)) = result.expect("bounded control-only exchange");
    assert_eq!(request, b"admission-request");
    assert_eq!(response, b"awaiting-approval");
}

#[derive(Debug)]
struct RoutingAdmission(ExchangeAdmission);

impl EndpointAdmission for RoutingAdmission {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        if connection.alpn() == CONTROL_ALPN {
            EndpointAdmission::admit(&ControlOnlyAdmission, connection).await
        } else {
            EndpointAdmission::admit(&self.0, connection).await
        }
    }

    fn is_current(&self, _connection: &ControlConnection) -> bool {
        true
    }
}

#[derive(Debug)]
struct RoutedBusiness;

impl iroh::protocol::ProtocolHandler for RoutedBusiness {
    async fn on_accepting(&self, _accepting: iroh::endpoint::Accepting)
        -> Result<Connection, iroh::protocol::AcceptError>
    {
        panic!("restricted routing must not expose the ordinary Accepting state")
    }

    async fn accept(&self, connection: Connection) -> Result<(), iroh::protocol::AcceptError> {
        let (mut send, mut recv) = connection.accept_bi().await?;
        let message = recv.read_to_end(64).await.map_err(iroh::protocol::AcceptError::from_err)?;
        send.write_all(&message).await.map_err(iroh::protocol::AcceptError::from_err)?;
        send.finish()?;
        send.stopped().await.map_err(iroh::protocol::AcceptError::from_err)?;
        Ok(())
    }
}

#[derive(Debug)]
struct RoutedControl;

impl iroh::protocol::ControlProtocolHandler for RoutedControl {
    async fn accept(&self, connection: ControlConnection) -> Result<(), iroh::protocol::AcceptError> {
        let message = connection.recv_control().await?;
        connection.send_control(&message).await?;
        let done = connection.recv_control().await?;
        assert_eq!(done, b"done");
        Ok(())
    }
}

#[tokio::test]
async fn restricted_router_delivers_original_business_and_separate_control_handlers() {
    use iroh::protocol::RestrictedRouter;
    let events = Events::default();
    let bind = |label| {
        let events = events.clone();
        async move {
            Endpoint::builder(presets::Minimal)
                .portmapper_config(PortmapperConfig::Disabled)
                .alpns(vec![ALPN.to_vec(), CONTROL_ALPN.to_vec()])
                .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0))).unwrap()
                .hooks(LegacyCheck { label, events: events.clone() })
                .restricted(RoutingAdmission(ExchangeAdmission { label, events }))
                .bind().await.unwrap()
        }
    };
    let client = bind("client").await;
    let server = bind("server").await;
    let router = RestrictedRouter::builder(server.clone())
        .accept(ALPN, RoutedBusiness)
        .accept_control(CONTROL_ALPN, RoutedControl)
        .spawn();
    let result = tokio::time::timeout(Duration::from_secs(10), async {
        let connection: Connection = client.connect(direct(router.endpoint()), ALPN).await.unwrap();
        let (mut send, mut recv) = connection.open_bi().await.unwrap();
        send.write_all(b"routed-business").await.unwrap();
        send.finish().unwrap();
        let business = recv.read_to_end(64).await.unwrap();
        let control = client.connect_control(direct(router.endpoint()), CONTROL_ALPN).await.unwrap();
        control.send_control(b"routed-control").await.unwrap();
        let bootstrap = control.recv_control().await.unwrap();
        control.send_control(b"done").await.unwrap();
        (connection, control, business, bootstrap)
    }).await;
    client.close().await;
    router.shutdown().await.unwrap();
    let (_, _, business, bootstrap) = result.expect("bounded restricted routing");
    assert_eq!(business, b"routed-business");
    assert_eq!(bootstrap, b"routed-control");
}

#[derive(Debug)]
struct WaitingAdmission {
    entered: Arc<tokio::sync::Notify>,
}

impl EndpointAdmission for WaitingAdmission {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        connection.send_control(b"wait-for-decision").await?;
        if connection.recv_control().await? != b"wait-for-decision" {
            return Err(io::Error::other("incorrect control phase"));
        }
        self.entered.notify_one();
        std::future::pending().await
    }

    fn is_current(&self, _connection: &ControlConnection) -> bool {
        true
    }
}

async fn waiting_endpoint(entered: Arc<tokio::sync::Notify>) -> RestrictedEndpoint {
    Endpoint::builder(presets::Minimal)
        .portmapper_config(PortmapperConfig::Disabled)
        .alpns(vec![ALPN.to_vec()])
        .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0))).unwrap()
        .hooks(BusinessHookMustNotRun)
        .restricted(WaitingAdmission { entered })
        .admission_timeout(Duration::from_secs(10))
        .bind().await.unwrap()
}

#[tokio::test]
async fn cancellation_closes_original_attempt_and_releases_the_peers_pending_policy() {
    let client_entered = Arc::new(tokio::sync::Notify::new());
    let server_entered = Arc::new(tokio::sync::Notify::new());
    let client = waiting_endpoint(client_entered.clone()).await;
    let server = waiting_endpoint(server_entered.clone()).await;
    let token = tokio_util::sync::CancellationToken::new();
    let receiver = server.clone();
    let mut incoming = tokio::spawn(async move { receiver.accept().await.unwrap().await });
    let attempt = client.connect_with_opts(direct(&server), ALPN,
        iroh::endpoint::ConnectOptions::new().with_attempt_cancellation(token.clone()),
    ).await.unwrap();
    let mut outgoing = tokio::spawn(async move { attempt.await });
    let entered = tokio::time::timeout(Duration::from_secs(3), async {
        tokio::join!(client_entered.notified(), server_entered.notified());
    }).await;
    token.cancel();
    let outgoing_result = tokio::time::timeout(Duration::from_secs(2), &mut outgoing).await;
    let incoming_result = tokio::time::timeout(Duration::from_secs(2), &mut incoming).await;
    if outgoing_result.is_err() {
        outgoing.abort();
        let _ = outgoing.await;
    }
    if incoming_result.is_err() {
        incoming.abort();
        let _ = incoming.await;
    }
    client.close().await;
    server.close().await;
    assert!(entered.is_ok(), "both real policies entered the protected wait");
    let outgoing = outgoing_result.expect("cancellation must finish the local attempt");
    let incoming = incoming_result.expect("peer closure must release pending policy without waiting for its setup deadline");
    assert!(matches!(outgoing.unwrap(), Err(iroh::endpoint::ConnectingError::AttemptCancelled { .. })));
    assert!(matches!(incoming.unwrap(), Err(iroh::endpoint::ConnectingError::ConnectionError { .. })));
}

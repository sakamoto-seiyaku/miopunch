//! Restricted consumers use the same public endpoint/stream seam as applications.

use std::{
    io,
    net::{Ipv4Addr, SocketAddr},
    sync::{Arc, Mutex},
    time::Duration,
};

use iroh::{
    Endpoint, EndpointAddr,
    endpoint::{
        AdmissionOutcome, AfterHandshakeOutcome, Connection, ControlConnection, EndpointAdmission,
        EndpointHooks, PortmapperConfig, RestrictedEndpoint, presets,
    },
};

const ALPN: &[u8] = b"test/restricted-endpoint/1";
type Events = Arc<Mutex<Vec<String>>>;

#[derive(Debug)]
struct ExchangeAdmission {
    label: &'static str,
    events: Events,
}

impl EndpointAdmission for ExchangeAdmission {
    async fn admit(&self, connection: &ControlConnection) -> io::Result<AdmissionOutcome> {
        connection.send_control(b"authorized-control").await?;
        if connection.recv_control().await? != b"authorized-control" {
            return Err(io::Error::other("unexpected protected control message"));
        }
        self.events.lock().unwrap().push(format!("{}:gate", self.label));
        let path = connection.paths().iter().find(|path| path.is_ip())
            .ok_or_else(|| io::Error::other("no UDP candidate"))?.id();
        let permit = connection.qualify_data_path(path, Vec::new()).await?;
        self.events.lock().unwrap().push(format!("{}:path", self.label));
        Ok(AdmissionOutcome::Accept(permit))
    }

    fn is_current(&self, _connection: &ControlConnection) -> bool {
        true
    }
}

#[derive(Debug)]
struct LegacyCheck {
    label: &'static str,
    events: Events,
}

impl EndpointHooks for LegacyCheck {
    async fn after_handshake(&self, _connection: &Connection) -> AfterHandshakeOutcome {
        let mut events = self.events.lock().unwrap();
        assert!(events.contains(&format!("{}:gate", self.label)));
        assert!(events.contains(&format!("{}:path", self.label)));
        events.push(format!("{}:hook", self.label));
        AfterHandshakeOutcome::Accept
    }
}

async fn endpoint(label: &'static str, events: Events) -> RestrictedEndpoint {
    Endpoint::builder(presets::Minimal)
        .portmapper_config(PortmapperConfig::Disabled)
        .alpns(vec![ALPN.to_vec()])
        .bind_addr(SocketAddr::from((Ipv4Addr::LOCALHOST, 0)))
        .unwrap()
        .hooks(LegacyCheck { label, events: events.clone() })
        .restricted(ExchangeAdmission { label, events })
        .bind().await.unwrap()
}

fn direct(endpoint: &RestrictedEndpoint) -> EndpointAddr {
    EndpointAddr::new(endpoint.id()).with_addrs(
        endpoint.addr().ip_addrs().copied().map(iroh_base::TransportAddr::Ip),
    )
}

#[tokio::test]
async fn control_and_path_checks_precede_legacy_hook_and_original_connection_handoff() {
    let events = Events::default();
    let client = endpoint("client", events.clone()).await;
    let server = endpoint("server", events.clone()).await;
    let result = tokio::time::timeout(Duration::from_secs(10), async {
        tokio::join!(async {
            let connection: Connection = client.connect(direct(&server), ALPN).await.unwrap();
            events.lock().unwrap().push("client:handoff".to_string());
            let (mut send, mut recv) = connection.open_bi().await.unwrap();
            send.write_all(b"business-ping").await.unwrap();
            send.finish().unwrap();
            let reply = recv.read_to_end(64).await.unwrap();
            (connection, reply)
        }, async {
            let connection: Connection = server.accept().await.unwrap().await.unwrap();
            events.lock().unwrap().push("server:handoff".to_string());
            let (mut send, mut recv) = connection.accept_bi().await.unwrap();
            let request = recv.read_to_end(64).await.unwrap();
            send.write_all(b"business-pong").await.unwrap();
            send.finish().unwrap();
            (connection, request)
        })
    }).await;
    client.close().await;
    server.close().await;
    let ((_, reply), (_, request)) = result.expect("bounded restricted exchange");
    assert_eq!(request, b"business-ping");
    assert_eq!(reply, b"business-pong");
    let events = events.lock().unwrap();
    for label in ["client", "server"] {
        let actual: Vec<_> = events.iter().filter(|event| event.starts_with(label)).cloned().collect();
        assert_eq!(actual, ["gate", "path", "hook", "handoff"].map(|stage| format!("{label}:{stage}")));
    }
}

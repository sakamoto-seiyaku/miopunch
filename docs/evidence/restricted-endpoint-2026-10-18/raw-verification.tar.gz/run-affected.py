import json,os,socket,subprocess,time,tomllib
from pathlib import Path
H=Path('/tmp/miopunch-m92-20261018');R=Path('/home/js/Git/miopunch')
O=H/'affected-suite';O.mkdir(exist_ok=False)
config=O/'mosquitto.conf';config.write_text('listener 1883 0.0.0.0\nallow_anonymous true\npersistence false\n');config.chmod(0o644)
name='miopunch-m92-regression-'+str(time.time_ns())
def cmd(*args):return subprocess.check_output(['rtk','proxy',*args],text=True).strip()
report={'publicTraffic':False,'cases':[],'brokerImage':cmd('docker','image','inspect','eclipse-mosquitto:2','--format','{{.Id}}')}
try:
 cmd('docker','run','--detach','--name',name,'--publish','127.0.0.1::1883','--mount',f'type=bind,src={config},target=/mosquitto/config/mosquitto.conf,readonly',report['brokerImage'])
 address=cmd('docker','port',name,'1883/tcp');host,port=address.rsplit(':',1)
 for _ in range(100):
  try:
   with socket.create_connection((host,int(port)),timeout=.2):break
  except OSError:time.sleep(.05)
 else:raise RuntimeError('broker startup timeout')
 env=os.environ.copy();env['MIOPUNCH_MQTT_BROKER']=address
 tests=tomllib.loads((H/'final-selector-v4/Cargo.toml').read_text())['test']
 for t in tests:
  binary=t['name'];print('Running '+binary,flush=True)
  c=['rtk','proxy','python3',str(H/'run-tests.py'),'--timeout-seconds','150','verified-affected-tests-v5','final-runtime-'+binary,binary,'--test-threads=1','--nocapture']
  result=subprocess.run(c,cwd=R,env=env,capture_output=True,text=True)
  (O/(binary+'.log')).write_text(result.stdout+'\n'+result.stderr)
  receipt=H/('final-runtime-'+binary)/'receipt.json'
  row=json.loads(receipt.read_text()) if receipt.exists() else {'exit':result.returncode,'failure':'no runtime receipt'}
  report['cases'].append({'binary':binary,**row})
  print(json.dumps({'binary':binary,'exit':result.returncode,'passed':row.get('testsPassed'),'failed':row.get('testsFailed'),'forced':row.get('forcedTermination')}),flush=True)
  if result.returncode:break
finally:
 subprocess.run(['rtk','proxy','docker','logs',name],stdout=(O/'broker.log').open('w'),stderr=subprocess.STDOUT)
 subprocess.run(['rtk','proxy','docker','stop','--time','5',name],capture_output=True)
 state=json.loads(cmd('docker','inspect',name))[0]['State'];report['brokerExit']=state['ExitCode'];report['brokerStopped']=not state['Running']
 cmd('docker','rm',name);report['brokerRemoved']=subprocess.run(['rtk','proxy','docker','inspect',name],capture_output=True).returncode!=0
 report['passed']=len(report['cases'])==17 and all(r.get('exit')==0 and not r.get('forcedTermination') and r.get('nonemptyTestSelection') for r in report['cases']) and report['brokerStopped'] and report['brokerRemoved'] and report['brokerExit']==0
 report['testsPassed']=sum(r.get('testsPassed',0) for r in report['cases']);(O/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'caseCount':len(report['cases']),'testsPassed':report['testsPassed'],'brokerExit':report['brokerExit']}))
raise SystemExit(0 if report['passed'] else 1)

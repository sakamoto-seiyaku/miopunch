# Read-only build-cache duplication audit

All numbers are allocated decimal bytes unless labelled section bytes. Snapshot
is from the read-only audit before root's cache cleanup; no cache/source/artifact
was copied, changed, compiled, executed, stripped or deleted by this worker.
Measurements and recipes: [measurements.json](measurements.json).

## Ranked causes with direct evidence

1. **Accumulated incremental variants:** main target153.829GB contains70.810GB
   in1739 host incremental directories; miopunch library alone21.720GB/176 dirs,
   iroh5.212GB/27. Old S4 and IRC3 still contain13.837GB and5.226GB incremental
   state. This is reconstructible compiler state, not primary linked SDK output.
   Root's existing dev/test incremental=true sustained growth across work variants.

2. **Isolated per-run targets force cold graphs:** actual83 compiled529 units
   into a fresh2.203GB target. Its433 semantic library keys match the earlier
   graph, with only four reported feature differences. Independently,465 of477
   lib/proc-macro fingerprints match main settings **and dependency fingerprints**;
   empty output directories still prevent reuse. Matching fingerprints alone do
   not prove source freshness. Private76 uses its own4.486GB target for a genuinely
   different frozen source projection; don't conflate that required qualification
   boundary with a reason to clone a whole target for every output receipt.

3. **Executable variant accumulation / automatic bin builds:** main deps has445
   ELFs:193 normal bins26.032GB;252 test ELFs35.675GB. rlibs are only4.734GB,
   metadata2.289GB and shared libraries1.906GB. Largest groups include44 miopunch
   ELFs6.460GB,25 browser-network4.033GB and32 browser-probe3.650GB. Root Cargo
   integration test invocation also builds discovered application bins;83's actual
   test-only manifest avoids them with autobins=false. Use a stable selected-test
   entry instead of a newly named/copied package each run.

4. **Per-receipt Android compiler paths:** old builder fallback created
   `android-clang`/`ld.lld` and `-B` search paths under each new receipt directory
   (`scripts/build_android_pair.py`, former compiler helper). Two actual builds
   used the SAME shared Android target/clang14/NDK yet different wrapper path/hash
   and each logged378 Compiling lines including ring. This changes effective
   linker/CC inputs, not the intended toolchain. Root has independently corrected
   the helper; Cargo warm-reuse proof remains root's next check.

Host fingerprints all use ONE rustc identity (current1.98.1), so compiler-version
churn does not explain this host pool. Platforms must keep separate ABI outputs;
feature/test/check/build/proc-macro variants and actual source edits can legitimately
recompile. Iroh/noq each have two opaque source-path hashes and both relative/absolute dep-info paths that resolve to the same canonical vendor directory; workspace/path spelling can split identities, so fix canonical manifest/cwd/patch paths before attributing those variants to real source copies. Miopunch shows53 library fingerprints/nine feature sets, while serde has six fingerprints/one source+feature set/three profiles. Main has222 opaque profile hashes across3655 unit fingerprints, but
only5 ELF profile hashes; two dominate59.063GB and current normal bins use the
same dominant normal profile. Opaque hash/large size cannot label an artifact
obsolete or full-DWARF. Measured debug sections total29.531GB, including current
outputs; do not strip accepted originals to reclaim it.

## Minimal stable entry/cache policy

- One canonical source/manifest and shared target per actual platform build
  recipe. Unique receipts/deployment/package copies remain separate from caches.
  Explicitly record recipe, rustc/toolchain, features, profile, source hashes and
  actual Cargo fresh/compiled counts. No whole-target/source clones for receipt
  isolation. Legitimate frozen source projections stay explicit and reused.
- Keep dev/test profile and incremental=off consistent after the one-time
  migration. Keep Android wrappers in one stable toolchain path, independent
  of receipt paths. Avoid per-task debug/strip/package-profile overrides; strip
  deployment copies only. Existing check_tcp_portmap.py has such an override;
  it should be an explicit stable recipe if still needed.
- Reuse one stable selected-test manifest when avoiding unrelated auto bins;
  preserve root lock/features/dependency paths. Any intentional four-feature
  difference is a distinct recipe, not evidence every dependency must rebuild.
- Proof: one exact command twice, unchanged sources/recipe/shared target; second
  Cargo JSON must report zero freshly compiled units (all fresh=true). No warm
  claim based merely on success or elapsed time. Root runs this proof.

## Safe cleanup and bounded retention

First remove only idle **incremental subdirectories** after future incremental
is disabled; linked binaries, libraries, fingerprints, source and receipts stay.
Do not cargo-clean or remove whole targets. Root owns mutation authorization.

For optional TEST-only cache pruning, keep newest per(unit,features,profile,
flags,compile-kind), exempt all published artifact paths/current job pins and
retain every normal-bin ELF for the first pass. A scan of3509 published evidence
files exempts10 older test paths/1.463GB. Remaining91 candidates total12.801GB:
[test-elf-prune-review.json](test-elf-prune-review.json). This is a review list,
not deletion approval; root must intersect it with actual74/76/83 pins. All12
current top-level normal-bin hardlinks (1.828GB), all primary/published SDK
compiled artifacts, private76 build+source projection,83 target+pinned ELF and
raw/source receipts must remain. Retain rlib/rmeta/proc-macro/build/fingerprint
caches so pruning a test causes that target's compile/link when requested, not
a deletion-induced full dependency graph rebuild. Source/feature/profile changes
can still require legitimate library recompilation.

Keep this deterministic retention rule and a soft high-water mark (e.g.80GiB
for the managed main target), with disk preflight reserving space for an actual
selected build. If protected artifacts exceed the limit, report it; never evict
pins silently. After incremental+candidate pruning the observed main pool would
be about70.218GB before any new builds, retaining all normal-bin variants.
No CAS/whole-cache copying framework is needed. Existing private/old targets
remain separate preserved artifacts until root classifies their cache-only
subdirectories; this audit does not authorize deleting them.

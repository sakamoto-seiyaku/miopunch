#[allow(dead_code)]
fn check(node: &miopunch_native_probe::native_network::NativeNetwork,
         builder: iroh::endpoint::Builder) {
    let _ = node.bind_endpoint_with(builder);
}

from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/home/js/Git/miopunch')
OUT = Path('/tmp/mio-cache-emitter-cross-graph-20261005')

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def artifacts(path):
    return [entry for line in path.read_text().splitlines()
            if (entry := json.loads(line)).get('reason') == 'compiler-artifact']

def library(entries, name):
    entry = next(x for x in entries if x['target']['name'] == name
                 and any(filename.endswith('.rlib') for filename in x['filenames']))
    path = next(Path(x) for x in entry['filenames'] if x.endswith('.rlib'))
    return entry, path

a = json.loads(Path('/tmp/mio74-negative-native-build-20261005/receipt.json').read_text())
entries_b = artifacts(OUT / 'external-test/cargo.jsonl')
entries_final = artifacts(OUT / 'root-after-external/cargo.jsonl')
entry_b, path_b = library(entries_b, 'miopunch_native_probe')
entry_final, path_final = library(entries_final, 'miopunch_native_probe')
path_a = Path(a['rootLibrary']['path'])
assert path_a == path_final and path_a != path_b
assert path_a.name.startswith('libmiopunch_native_probe-') and path_b.name.startswith('libmiopunch_native_probe-')
assert sha(path_a) == a['rootLibrary']['sha256']
receipt_final = json.loads((OUT / 'root-after-external/receipt.json').read_text())
assert receipt_final['exit'] == 0 and receipt_final['rebuiltArtifacts'] == 0
receipt_first = json.loads(Path(a['cacheReceipt']).read_text())
assert receipt_first['command'] == receipt_final['command']
probe = OUT / 'type-identity.rs'
probe.write_text('''#[allow(dead_code)]
fn check(node: &miopunch_native_probe::native_network::NativeNetwork,
         builder: iroh::endpoint::Builder) {
    let _ = node.bind_endpoint_with(builder);
}
''')
results = []
for graph, entries, path in [('root', entries_final, path_a), ('external', entries_b, path_b)]:
    _, iroh = library(entries, 'iroh')
    command = ['rtk', 'proxy', 'rustc', '--edition=2024', '--crate-name', 'mio_cache_type_identity',
               '--crate-type', 'lib', '--emit', 'metadata', str(probe),
               '-L', 'dependency=' + str(ROOT / 'target/debug/deps'),
               '--extern', 'miopunch_native_probe=' + str(path), '--extern', 'iroh=' + str(iroh),
               '-o', str(OUT / (graph + '-type-identity.rmeta'))]
    with (OUT / (graph + '-type-identity.stdout.log')).open('w') as stdout, \
         (OUT / (graph + '-type-identity.stderr.log')).open('w') as stderr:
        result = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr)
    results.append({'graph': graph, 'command': command, 'exit': result.returncode,
                    'productPath': str(path), 'productSha256': sha(path),
                    'irohPath': str(iroh), 'irohSha256': sha(iroh)})
    assert result.returncode == 0, graph
report = {'scope': 'actual SDK compile-only cross-graph emitter regression; no SDK runtime',
          'firstOriginalCompileExit': 101, 'correctedFixtureCompileExit': a['exit'],
          'externalTestCompileOnlyExit': json.loads((OUT / 'external-test/receipt.json').read_text())['exit'],
          'rootAfterExternalExit': receipt_final['exit'],
          'rootAfterExternalRebuilt': receipt_final['rebuiltArtifacts'],
          'rootAfterExternalFresh': receipt_final['freshArtifacts'],
          'distinctHashedProductPaths': True, 'rootProductBytesUnchangedAcrossExternalGraph': True,
          'actualTypeIdentityCompiles': results, 'passed': True}
(OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'actualTypeIdentityCompiles'}))

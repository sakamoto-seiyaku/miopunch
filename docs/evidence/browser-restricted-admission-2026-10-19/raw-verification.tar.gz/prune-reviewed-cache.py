import hashlib,json,sys,os
from pathlib import Path
ROOT=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m94-20261019')
sys.path.insert(0,str(ROOT/'scripts'));import cargo_cache as cache
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
review=json.loads((H/'cache-review.json').read_text());assert not review['errors']
expected={'miopunch_native_probe-c70dc904ccfea2f3','maintained_contact_startup-e7fa67e5bfde6579','owned_lifecycle-39fd2a87fd1f347c'}
assert {Path(r['path']).name for r in review['exactList']}==expected
catalog=review['publishedEvidenceCatalog']
assert {str(p) for p in (ROOT/'docs/evidence').rglob('*') if p.is_file()}==set(catalog)
for p,r in catalog.items():
 st=Path(p).stat();assert st.st_size==r['bytes'] and st.st_mtime_ns==r['mtimeNs']
removed=[]
with cache.cache_lease(ROOT/'target') as before:
 assert not cache.active_compilers(ROOT)
 for r in review['exactList']:
  p=Path(r['path']);st=p.stat();assert p.parent==ROOT/'target/debug/deps' and not p.is_symlink() and st.st_nlink==1
  assert st.st_size==r['bytes'] and st.st_mtime==r['mtime'] and sha(p)==r['sha256']
  assert sha(r['fingerprint'])==r['fingerprintSha256'] and r['path'] not in review['publishedExemptions']
 for r in review['exactList']:
  Path(r['path']).unlink();removed.append(r)
 result={'reviewSha256':sha(H/'cache-review.json'),'reviewedExactListOnly':True,'publishedCatalogUnchanged':True,'noActiveCompilers':True,'before':before,'removed':removed,'after':cache.disk_state(ROOT/'target')}
(H/'cache-prune-receipt.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'removed':len(removed),'bytes':sum(r['bytes'] for r in removed),'diskAfter':result['after']}))

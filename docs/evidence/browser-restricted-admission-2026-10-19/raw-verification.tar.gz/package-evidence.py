import hashlib
import json
import tarfile
from pathlib import Path

ROOT = Path('/home/js/Git/miopunch')
HERE = Path('/tmp/miopunch-m94-20261019')
OUT = ROOT / 'docs/evidence/browser-restricted-admission-2026-10-19'
OUT.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

protected = read(HERE / 'protected-wip.json')
assert all(sha(ROOT / r['path']) == r['sha256'] for r in protected)
assert sha(HERE / 'baseline-sdk-story/run.mjs') == sha(HERE / 'final-sdk-story/run.mjs')
builds = {name: read(HERE / name / 'receipt.json') for name in
          ['typed-browser-sdk-v2', 'browser-default-check', 'native-shared-primitives-check']}
assert all(r['exit'] == 0 and r['sourceFrozenDuringBuild'] and r['qualifiedForFrozenRun']
           for r in builds.values())

cases = {}
for name in ['final-sdk-story', 'final-sdk-active-rtc', 'final-sdk-negatives',
             'typed-browser-serving-v2', 'final-browser-incoming-active-rtc']:
    d = HERE / name
    e = read(d / 'execution.json')
    r = read(d / 'runtime/private-runtime-receipt.json')
    assert e['qualified'] and r['qualified'] and r['cleanupQualified']
    assert r['business']['result'] == 'PONG' and r['approval']['new_records'] == 1
    assert r['pendingReopen']['id'] == r['completeReopen']['id']
    assert r['currentStrictPurpose2Qualified'] and r['businessQualified']
    cases[name] = {
        'qualified': True,
        'execution': e,
        'privateRawReceiptSha256': sha(d / 'runtime/private-runtime-receipt.json'),
        'strictRestrictedRequest': True,
        'approvalRecords': r['approval']['new_records'],
        'bothMaterialsDurable': all(r['materialCompletion']['status'][k]
                                   for k in ['authorization_saved', 'secret_saved']),
        'sameBrowserIdentityReopened': True,
        'sameNativeIdentityReopened': True,
        'memberReply': r['business']['result'],
        'initialCarrier': 'RTC' if r['nativeMemberReleased'].get('selected_rtc') else 'Relay',
        'browserClose': r['cleanup']['browser'],
        'socketImmediateObservationPassed': r['cleanup']['socketImmediateObservationPassed'],
        'lateSocketWaitMs': r['cleanup']['lateSocketWaitMs'],
        'websocketsClosedBeforeContext': r['cleanup']['websocketsClosedBeforeContext'],
        'nativeExit': r['cleanup']['nativeExit'],
        'ownedFixtureRemoved': r['cleanup']['ownedFixtureRemoved'],
        'privateMaterialCleanup': read(d / 'private-material-cleanup.json'),
    }
    case = cases[name]
    if 'improvement' in r:
        assert r['improvement']['result']['outcome'] == 'committed'
        assert r['nativeCommitted']['freshAck'] and r['nativeCommitted']['bothReady']
        assert r['nativeBusiness']['stable_id'] == r['nativeBeforeImprovement']['stable_id']
        case['existingNativeBrowserMemberImprovement'] = {
            'sameOriginal': True, 'freshAck': True, 'bothReady': True,
            'selectedRtc': any(p['selected'] and p['isRtc']
                               for p in r['afterImprovementSelection']['paths']),
            'explicitFixturePolicy': 'PreferDirect',
        }
    if 'negativeCases' in r:
        assert len(r['negativeCases']) == 5
        negative = []
        for n in r['negativeCases']:
            outcome = n.get('outcome', n)
            assert outcome['ordinaryHandle'] is False
            value = {'case': n['name'], 'localOrdinaryHandle': False,
                     'counterpartReleasesUnderItsCurrentView': n['nativeOrdinaryReleases']}
            if 'retired' in n:
                t = n['retired']
                assert t['activeAssociations'] == t['activePumpTasks'] == 0
                assert t['checkpoint']['originalOpen'] is False
                assert not t['checkpoint']['route']['active']
                assert not t['checkpoint']['route']['qualified']
                assert t['checkpoint']['route']['tx_bytes'] + t['checkpoint']['route']['rx_bytes'] == 0
                value.update(originalClosed=True, activeAssociations=0, activePumps=0,
                             routeActive=False, routeQualified=False, queuedBytes=0,
                             checkpointFreshAck=n['checkpoint']['checkpoint']['metadata']['freshAck'])
            negative.append(value)
        assert r['publicDeparture']['status']['stage'] == 'Removed'
        case['negativeCases'] = negative
        case['revocationPropagationScope'] = 'Browser-local departure refuses Browser delivery; the fixed counterpart has not received the new departure record.'
        initial = r['memberOpen']['diagnostics']['bootstrap']
        assert initial['finalReleaseFreshAck'] and initial['stableUnchanged'] and initial['bindingUnchanged']
        case['initialRtcFinalChecks'] = {'freshAck': True, 'stableUnchanged': True,
                                        'bindingUnchanged': True, 'beforeRetainFrames': initial['beforeRetainFrames']}
    if 'browserServedFirstRequest' in r:
        assert r['browserServedFirstRequest'] == {'response': 'AwaitingApproval', 'served': 'AwaitingApproval'}
        assert r['browserServedApproved'] == {'response': 'PendingMaterials', 'served': 'Complete'}
        assert r['browserPrecodeUsage'] == 1 and r['browserServedReplica']['complete']
        assert r['manualApplicantReopen']['sameIdentity']
        assert all(c['sdkClosed'] and c['websocketsClosedBeforeContext'] for c in r['extraBrowserCleanup'])
        case['browserIncoming'] = {'manualApproval': True, 'durableMaterials': True,
                                  'sameApplicantReopened': True, 'memberStream': True,
                                  'precodeUses': 1, 'precodeRetryDoesNotConsumeAgain': True,
                                  'replicaComplete': True, 'extraContextCleanup': r['extraBrowserCleanup']}
    if 'browserIncomingActive' in r:
        assert r['browserIncomingActive']['outcome'] == 'committed'
        sides = {}
        for side in ['initiator', 'responder']:
            before, after = r['browserIncomingActiveBefore'][side], r['browserIncomingActiveAfter'][side]
            b = after['bootstrap']
            assert before['memberStableId'] == after['memberStableId']
            assert b['finalReleaseFreshAck'] and b['stableUnchanged'] and b['bindingUnchanged']
            assert b['coordinator']['freshAck'] and b['coordinator']['bothReady']
            assert any(p['selected'] and p['isRtc'] for p in after['paths'])
            sides[side] = {'sameOriginal': True, 'freshAck': True, 'bothReady': True,
                           'selectedRtc': True, 'beforeRetainFrames': b['beforeRetainFrames']}
        case['browserIncomingActiveControl'] = {'sides': sides, 'originalMemberBusinessAfterRtc': True,
                                               'explicitFixturePolicy': 'PreferDirect'}

history = {}
for d in HERE.iterdir():
    if not d.is_dir() or not (d / 'execution.json').is_file():
        continue
    e = read(d / 'execution.json')
    r = read(d / 'runtime/private-runtime-receipt.json')
    history[d.name] = {'qualified': e['qualified'], 'runtimeExit': e['runtimeExit'],
                       'functionalPassed': r['passed'], 'sdkCleanupPassed': r['cleanupQualified'],
                       'firstFailureClass': r.get('firstFailure', {}).get('class'),
                       'privateRawReceiptSha256': sha(d / 'runtime/private-runtime-receipt.json')}

write('validation.json', {
    'baselineCommit': 'e697315e1ed43fa8560930aa189690f89c4e7e42',
    'implementationCommit': (HERE / 'source-commit.txt').read_text().strip(),
    'protectedPreexistingFileCount': len(protected), 'protectedPreexistingHashesUnchanged': True,
    'fixedBeforeEditJsConsumerSha256': sha(HERE / 'baseline-sdk-story/run.mjs'),
    'finalConsumerBytesEqualBeforeEditConsumer': True,
    'fixedNativeCounterpartSha256': '55bec236f396d72e96af508d98eebe904e1393f1639bd1dbae80e176cdf578c4',
    'builds': builds, 'selectedInputsAfterFinalChecks': read(HERE / 'final-selected-input-continuity.json'),
    'finalSdkCases': cases, 'runtimeHistoryIncludingFailures': history,
    'beforeEditBaselinePassed': read(HERE / 'baseline-sdk-story/execution.json')['qualified'],
    'scope': 'M94 Browser restricted migration; owned loopback only, no public/physical or Android throughput/power matrix',
})

files = set()
def include(p):
    if p.is_file():
        files.add(p)

for p in HERE.glob('*.py'):
    include(p)
for p in HERE.glob('*-context.json'):
    include(p)
for name in ['architecture-plan.md', 'review-spec.md', 'review-standards.md',
             'fixed-consumer-inputs.json', 'before-browser-edits.json', 'source-baseline.txt',
             'owned-source-files.json', 'source-commit.txt', 'final-selected-input-continuity.json',
             'cache-review.json', 'cache-prune-receipt.json', 'browser-consumer-inventory.json']:
    include(HERE / name)
for d in HERE.iterdir():
    if not d.is_dir():
        continue
    for name in ['Cargo.toml', 'Cargo.lock', 'receipt.json', 'preconditions.json',
                 'cargo.jsonl', 'cargo.stderr.log', 'selected-dependency-inputs.json',
                 'bindgen.stdout.log', 'bindgen.stderr.log', 'execute.py', 'run.mjs',
                 'execution.json', 'execution-preconditions.json', 'private-material-cleanup.json']:
        include(d / name)

manifest = {str(p.relative_to(HERE)): {'sha256': sha(p), 'bytes': p.stat().st_size}
            for p in sorted(files)}
archive = OUT / 'raw-verification.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for p in sorted(files):
        tar.add(p, arcname=str(p.relative_to(HERE)), recursive=False)
with tarfile.open(archive) as tar:
    assert set(tar.getnames()) == set(manifest)
    for member in tar:
        data = tar.extractfile(member).read()
        expected = manifest[member.name]
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
write('archive-manifest.json', {'members': manifest, 'archiveSha256': sha(archive),
    'archiveBytes': archive.stat().st_size, 'allMembersReadBackAndVerified': True,
    'excluded': ['Fixed SDK binaries/WASM and full selected sources remain under local receipt paths',
                 'Private runtime logs, identities, SDP, generated stores, private keys and NSS databases'],
    'sdkResults': 'Explicit allowlisted outcomes only in validation.json'})
print(json.dumps({'archiveMembers': len(manifest), 'archiveBytes': archive.stat().st_size,
                  'finalSdkCases': len(cases), 'historicalRunsIncludingFailures': len(history)}))

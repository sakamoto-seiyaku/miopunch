#!/usr/bin/env python3
"""One Y700 startup/reopen observation; no Browser or member attempt."""
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT = Path('/home/js/Git/miopunch')
sys.path.insert(0, str(ROOT / 'scripts'))
from android_pair_runtime import Device, NativeActor

BUILD = Path('/tmp/mio76-startup-cleanup-current-android-build-20261005')
FACILITY = Path('/tmp/mio76-explicit-public-emqx-facility-20261005.json')
RELAY = 'https://aps1-1.relay.n0.iroh.link./'
OUT = Path('/tmp/mio76-native-startup-physical-observation-20261005')
PREFIX = '[DEBUG-mio76-startup] '
NUMERIC = {'startedUtcMs', 'elapsedMs', 'budgetRemainingMs', 'budgetMs',
           'mqttDriverActive', 'mqttQueuedPackets', 'mqttSentPackets', 'mqttReceivedPackets',
           'localPublishedCount', 'localConnectedCount', 'localRelayErrorCount', 'socketCount'}
BOOLS = {'mqttRouteReady', 'waitOk', 'outerTimedOut', 'cleanupSucceeded'}

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def check_sources(manifest):
    mismatches = []
    for name, expected in manifest.items():
        path = Path(name[len('external:'):]) if name.startswith('external:') else ROOT / name
        if not path.is_file() or digest(path) != expected:
            mismatches.append(name)
    return mismatches

def observations(lines):
    result = []
    malformed = 0
    for line in lines:
        if not line.startswith(PREFIX):
            continue
        try:
            value = json.loads(line[len(PREFIX):])
            assert value.get('tag') == 'DEBUG-mio76-startup'
            assert value.get('stage') in {'mqtt-ready', 'relay-online', 'cleanup'}
            assert value.get('phase') in {'begin', 'progress', 'end'}
            safe = {key: value[key] for key in ('tag', 'stage', 'phase')}
            for key in NUMERIC:
                if key in value:
                    assert value[key] is None or type(value[key]) is int and value[key] >= 0
                    safe[key] = value[key]
            for key in BOOLS:
                if key in value:
                    assert type(value[key]) is bool
                    safe[key] = value[key]
            if 'errorKind' in value:
                assert value['errorKind'] is None or (type(value['errorKind']) is str
                       and value['errorKind'].isalpha() and len(value['errorKind']) <= 64)
                safe['errorKind'] = value['errorKind']
            result.append(safe)
        except (AssertionError, ValueError, TypeError):
            malformed += 1
    return {'observations': result, 'malformed': malformed}

def retirement(actor, cleanup):
    try:
        event = actor.wait_event('closed', timeout=1)
        keep = {'event', 'cleanupMs', 'socketsBefore', 'socketsImmediate', 'socketsLate',
                'endpointClosed', 'nodeClosed', 'mqttStatusClosed', 'mqttDriverJoined',
                'cleanupSucceeded', 'activeRtcAssociations', 'activeRtcPumps'}
        cleanup['sdkRetirement'] = {key: event[key] for key in keep if key in event}
    except (RuntimeError, TimeoutError) as error:
        cleanup['sdkRetirementMissing'] = type(error).__name__
    cleanup['startupDiagnostics'] = observations(actor.stderr)
    return cleanup

def cleanup_ok(cleanup, directory=False):
    sdk = cleanup.get('sdkRetirement', {})
    before, late = sdk.get('socketsBefore'), sdk.get('socketsLate')
    return (cleanup.get('forced') is False and cleanup.get('leaderWaitedFor') is True
        and cleanup.get('ownedRemoteProcessAbsent') is True
        and cleanup.get('ownedRemoteProcessAbsentLate') is True
        and cleanup.get('localReadersEnded') is True
        and (not directory or cleanup.get('ownedDirectoryRemoved') is True)
        and all(sdk.get(key) is True for key in ('endpointClosed', 'nodeClosed',
                'mqttStatusClosed', 'mqttDriverJoined', 'cleanupSucceeded'))
        and sdk.get('activeRtcAssociations') == 0 and sdk.get('activeRtcPumps') == 0
        and type(before) is int and type(late) is int and late <= before)

def main():
    OUT.mkdir(mode=0o700, exist_ok=False)
    report = {'scope': 'one Y700 Native startup and same-store reopen observation',
              'memberAttemptPerformed': False, 'browserRunPerformed': False,
              'independentStunRunPerformed': False, 'physicalWanQualified': False,
              'normalPublicCertificateValidation': True, 'originalStartupCeilingsSeconds': 10,
              'operations': [], 'passed': False}
    actor = None
    device = None
    try:
        build = json.loads((BUILD / 'build.json').read_text())
        before = json.loads((BUILD / 'sources-before.json').read_text())
        after = json.loads((BUILD / 'sources-after.json').read_text())
        assert build['exit'] == 0 and build['sourceFrozenDuringBuild'] is True
        assert before == after and not check_sources(after)
        deploy = build['deployment']['browser_wss_member_native']
        binary = Path(deploy['deployedPath'])
        assert digest(binary) == deploy['deployedSha256']
        assert digest(deploy['compiledPath']) == deploy['compiledSha256']
        assert build['artifacts'][deploy['compiledPath']] == deploy['compiledSha256']
        report['sourceBinding'] = {'manifestCount': len(after), 'allSourcesCurrent': True,
            'inactiveExceptions': 0, 'buildReceiptSha256': digest(BUILD / 'build.json'),
            'compiledSha256': deploy['compiledSha256'], 'deployedSha256': digest(binary),
            'facilitySha256': digest(FACILITY)}
        (OUT / 'sources-before.json').write_text(json.dumps(after, indent=2) + '\n')
        device = Device('TB322FC', 'network')
        actor = NativeActor(device)
        actor.deploy(binary, 'native', executable=True)
        facility_path = actor.deploy(FACILITY, 'facility.json')
        store = actor.directory + '/node-store'
        identity = None
        for name, argv in [('admission-startup', [store, facility_path, '-', 'admission']),
                           ('same-store-unified-reopen', [store, facility_path, '-', 'unified-member', RELAY])]:
            operation = {'name': name, 'readyObserved': False}
            report['operations'].append(operation)
            began = time.monotonic()
            actor.start(argv)
            try:
                ready = actor.wait_event('ready', timeout=25)
                operation['readyObserved'] = True
                operation['readyElapsedMs'] = round((time.monotonic() - began) * 1000, 3)
                operation['normalPublicTrust'] = ready.get('normalPublicTrust') is True
                operation['socketCount'] = ready.get('socketCount')
                operation['relayAddressCount'] = ready.get('relayAddresses')
                operation['knownMemberCount'] = len(ready.get('knownMembers', []))
                operation['unifiedMember'] = ready.get('unifiedMember')
                if identity is None:
                    identity = ready['id']
                else:
                    operation['sameSavedIdentity'] = ready['id'] == identity
                assert operation['normalPublicTrust']
                if name == 'same-store-unified-reopen':
                    assert operation['sameSavedIdentity']
            finally:
                operation['elapsedBeforeCleanupMs'] = round((time.monotonic() - began) * 1000, 3)
                operation['cleanup'] = retirement(actor, actor.close(remove_directory=False))
                operation['cleanup']['observedCleanupSucceeded'] = cleanup_ok(operation['cleanup'])
            assert operation['cleanup']['commandExit'] == 0
            assert operation['cleanup']['observedCleanupSucceeded']
        report['sourceBinding']['sourcesStableThroughRun'] = not check_sources(after)
        report['sourceBinding']['artifactStableThroughRun'] = digest(binary) == deploy['deployedSha256']
        assert report['sourceBinding']['sourcesStableThroughRun']
        assert report['sourceBinding']['artifactStableThroughRun']
        report['passed'] = True
    except Exception as error:
        report['failureClass'] = type(error).__name__
    finally:
        if actor:
            final = actor.close()
            report['finalOwnedCleanup'] = final
            report['passed'] = report['passed'] and final.get('ownedDirectoryRemoved') is True
            report['passed'] = report['passed'] and final.get('forced') is False
        if device:
            report['adbControlOperations'] = len(device.commands)
        (OUT / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({'passed': report['passed'], 'receipt': str(OUT / 'receipt.json'),
                          'readyObserved': [op['readyObserved'] for op in report['operations']]}))
    return 0 if report['passed'] else 1

if __name__ == '__main__':
    raise SystemExit(main())

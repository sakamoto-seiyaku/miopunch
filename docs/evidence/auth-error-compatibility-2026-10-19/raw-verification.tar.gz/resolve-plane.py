import html
import json
import re
import subprocess
from pathlib import Path

H = Path('/tmp/miopunch-m96-20261019')
OUT = H / 'plane-final'
OUT.mkdir(exist_ok=True)
M96 = 'd70bb533-2c01-4f8a-9663-dd56b805ad0f'
M91 = '6d5cd846-3c1b-4c21-977e-fdafc208f876'
DONE = '482063eb-b551-43e7-b35f-64371e164235'
BASE = ['rtk', 'proxy', '/home/js/.agents/skills/plane-ops/scripts/plane-ops.sh',
        '--defaults', 'docs/agents/plane-defaults.json']

def call(name, args):
    r = subprocess.run(BASE + args + ['--json'], capture_output=True, text=True, check=True)
    d = json.loads(r.stdout)
    (OUT / (name + '.json')).write_text(json.dumps(d, ensure_ascii=False, indent=2) + '\n')
    return d

def plain(s):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', '', s))).strip()

source = (H / 'source-commit.txt').read_text().strip()
evidence = (H / 'evidence-commit.txt').read_text().strip()
a = call('m96-before', ['work-item', 'get', M96])
parent = call('m91-before', ['work-item', 'get', M91])
relations = call('m96-relations-before', ['work-item', 'relations', 'list', M96])
comments = call('m96-comments-before', ['work-item', 'comments', 'list', M96])
assert a['parent'] == M91 and a['assignees'] == ['de705fdc-c1ec-4e53-b30d-8509dc7f5bc6']
assert a['description_html'].count('[ ]') == 4
assert source not in json.dumps(comments)
body = (H / 'resolution-template.html').read_text().replace('SOURCE_COMMIT', source).replace('EVIDENCE_COMMIT', evidence)
(OUT / 'resolution.html').write_text(body)
comment = call('m96-resolution', ['work-item', 'comments', 'create', M96, '--html', body])
assert comment.get('id')
requested = a['description_html'].replace('[ ]', '[x]')
call('m96-updated', ['work-item', 'update', M96, '--raw-json',
                    json.dumps({'state': DONE, 'description_html': requested}, ensure_ascii=False)])
marker = '<h2>Decisions so far</h2><ul>'
text = parent['description_html']
assert marker in text
start = text.index(marker) + len(marker)
end = text.index('</ul>', start)
url = 'http://192.168.4.22:2080/work/projects/aa58cd82-2afc-404b-a097-58ef553c7ca4/issues/' + M96
assert url not in text[start:end]
entry = f'<li><a href="{url}">MIOPUNCH-96：恢复 p2panda-auth 旧错误并接通独立 checked error</a>：旧错误枚举／process 原消费者不改源码通过，checked policy 保持因果前态检查与拒绝隔离；21 项受影响测试及当前双端 SDK 审批、保存、重开、replica 和 RTC／权限负例通过。实施 {source[:8]}，证据 {evidence[:8]}；整体 M91 继续。</li>'
new_parent = text[:end] + entry + text[end:]
call('m91-updated', ['work-item', 'update', M91, '--raw-json',
                    json.dumps({'description_html': new_parent}, ensure_ascii=False)])
after = call('m96-readback', ['work-item', 'get', M96])
parent_after = call('m91-readback', ['work-item', 'get', M91])
relations_after = call('m96-relations-readback', ['work-item', 'relations', 'list', M96])
comments_after = call('m96-comments-readback', ['work-item', 'comments', 'list', M96])
assert after['state'] == DONE
for key in ['parent', 'labels', 'assignees', 'name', 'priority']:
    assert after[key] == a[key]
assert plain(after['description_html']) == plain(requested)
for key in ['state', 'parent', 'labels', 'assignees', 'name', 'priority']:
    assert parent_after[key] == parent[key]
assert plain(parent_after['description_html']) == plain(new_parent)

def ids(value):
    if isinstance(value, list):
        return [ids(v) for v in value]
    if isinstance(value, dict):
        return {k: ids(v) for k, v in value.items() if k in
                ['id', 'blocked_by', 'blocking', 'relates_to', 'duplicates', 'duplicate_of', 'start_after', 'start_before']}
    return value

assert ids(relations_after) == ids(relations)
serialized = json.dumps(comments_after, ensure_ascii=False)
assert comment['id'] in serialized and source in serialized and evidence in serialized
print(json.dumps({'m96State': 'Done', 'sourceCommit': source, 'evidenceCommit': evidence,
                  'resolutionComment': comment['id'], 'parentDecisionAdded': True,
                  'descriptionLabelsParentAssigneeAndRelationsVerified': True, 'm91RemainsOpen': True}))

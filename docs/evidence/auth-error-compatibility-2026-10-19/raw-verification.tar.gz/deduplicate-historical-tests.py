import hashlib,json,os,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m96-20261019');OLD=Path('/tmp/miopunch-m93-20261018')
sys.path.insert(0,str(R/'scripts'));import cargo_cache as cache
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
names={'resources','unified_connection','native_restricted_admission','member_path_protocol',
       'restricted_protocol_interop','rtc_invalidation_barrier','rtc_release_validation'}
groups={}
for p in sorted(OLD.glob('*/pinned/*')):
    if p.name not in names or not p.is_file() or p.is_symlink():continue
    st=p.stat()
    if st.st_size<80*1024**2:continue
    groups.setdefault((st.st_size,sha(p)),[]).append(p)
plans=[];saved=0
for (size,digest),paths in groups.items():
    canonical=paths[0];seen={(canonical.stat().st_dev,canonical.stat().st_ino)}
    for p in paths[1:]:
        st=p.stat();inode=(st.st_dev,st.st_ino)
        if inode in seen:continue
        seen.add(inode)
        if st.st_nlink!=1:continue
        plans.append({'path':str(p),'canonical':str(canonical),'sha256':digest,'bytes':size,
                      'inode':st.st_ino,'mtimeNs':st.st_mtime_ns})
        saved+=size
    if saved>=2*1024**3:break
assert plans
protected=json.loads((H/'protected-wip.json').read_text())
assert all(sha(R/r['path'])==r['sha256'] for r in protected)
live=[]
for d in Path('/proc').iterdir():
    if not d.name.isdigit():continue
    try:
        if (d/'comm').read_text().strip() in names:
            live.append(str((d/'exe').resolve(strict=True)))
    except (OSError,ValueError):continue
assert not live,live
(H/'historical-test-dedup-review.json').write_text(json.dumps({'reason':'Replace only byte-identical immutable historical test duplicates with hardlinks. Every existing evidence path and file byte remains; SDK pins and Cargo target are excluded. No SDK, source, lock, receipt or log is changed.','plans':plans,'potentialSavedBytes':saved,'noRelevantRunningTest':True},indent=2)+'\n')
with cache.cache_lease(R/'target',min_free=0) as before:
    assert not cache.active_compilers(R)
    for row in plans:
        p=Path(row['path']);c=Path(row['canonical']);st=p.stat()
        assert st.st_ino==row['inode'] and st.st_mtime_ns==row['mtimeNs'] and st.st_nlink==1
        assert sha(p)==sha(c)==row['sha256']
    for row in plans:
        p=Path(row['path']);c=Path(row['canonical']);tmp=p.with_name(p.name+'.dedup-link')
        assert not tmp.exists();os.link(c,tmp);os.replace(tmp,p)
        assert sha(p)==row['sha256'] and p.stat().st_ino==c.stat().st_ino
    after=cache.disk_state(R/'target')
assert all(sha(R/r['path'])==r['sha256'] for r in protected)
(H/'historical-test-dedup-receipt.json').write_text(json.dumps({'allOriginalPathsAndBytesPreserved':True,'sdkPinsAndCargoTargetUntouched':True,'plans':plans,'before':before,'after':after},indent=2)+'\n')
print(json.dumps({'deduplicatedFiles':len(plans),'savedBytes':saved,'diskAfter':after}))

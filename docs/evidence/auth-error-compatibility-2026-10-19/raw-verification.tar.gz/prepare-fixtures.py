import hashlib,json,re,shutil
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m96-20261019');P=Path('/tmp/miopunch-m95-20261019')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
original=Path('/tmp/p2panda-0.7.1/p2panda-auth');projection=H/'official-auth'
assert all((projection/p.relative_to(original)).read_bytes()==p.read_bytes() for p in (original/'src').rglob('*') if p.is_file())
root=(R/'Cargo.toml').read_text()
workspace=root[root.index('[workspace.dependencies]'):root.index('\n[dependencies]')]
manifest=(original/'Cargo.toml').read_text()+'\n[workspace]\nresolver = "2"\n\n[workspace.lints.clippy]\nunused_async = "warn"\nneedless_pass_by_ref_mut = "warn"\n\n'+workspace
(projection/'Cargo.toml').write_text(manifest)
base=(P/'affected-selector/Cargo.toml').read_text().split('\n[[test]]')[0]
start=base.index('[dependencies]');end=base.index('[patch.crates-io]')
dep=base[start:end]
def optional(match):
    name,value=match.group(1),match.group(2)
    if name in ['p2panda-auth','p2panda-core']:
        return match.group()
    if value.lstrip().startswith('{'):
        value=value.rstrip().removesuffix('}').rstrip()+', optional = true }'
    else:
        value='{ version = '+value+', optional = true }'
    return name+' = '+value
dep=re.sub(r'^([\w-]+) = (.+)$',optional,dep,flags=re.M)
base=base[:start]+dep+base[end:]
base+='\n[[bin]]\nname = "m96-original-auth-consumer"\npath = "'+str(H/'original-auth-consumer.rs')+'"\n'
for name,official in [('baseline-selector',False),('original-selector',True)]:
    d=H/name;d.mkdir()
    text=base.replace(str(R/'vendor/p2panda-auth'),str(projection)) if official else base
    (d/'Cargo.toml').write_text(text)
    (d/'Cargo.lock').write_bytes((P/'affected-selector/Cargo.lock').read_bytes())
fixed={str(p):sha(p) for p in [H/'original-auth-consumer.rs',projection/'Cargo.toml',original/'Cargo.toml',*list((original/'src').rglob('*.rs')),*list((projection/'src').rglob('*.rs'))]}
(H/'fixed-consumer-inputs.json').write_text(json.dumps(fixed,indent=2)+'\n')
driver=(P/'build.py').read_text().replace('miopunch-m95-20261019','miopunch-m96-20261019')
a=driver.index("        if manifest.parent.name in ('original-selector'")
b=driver.index('    fixed[str(canonical)]',a)
driver=driver[:a]+'''        assert all(row in pins(root) or row[2] is None for row in pins(selected)), 'selector changed external pins'
    canonical = HERE / 'baseline-selector/Cargo.lock'
    if selectors:
        assert pin_rows(lock) == pin_rows(canonical), 'selector changed complete locked dependency rows'
'''+driver[b:]
# Keep only relevant immutable SDKs and the separately used historical counterpart as artifact preconditions.
a=driver.index('    for receipt in [');b=driver.index('        pinned = ',a)
driver=driver[:a]+"    for receipt in [Path('/tmp/miopunch-m95-20261019/final-native-sdk/receipt.json'), Path('/tmp/miopunch-m95-20261019/final-browser-sdk/receipt.json'), Path('/tmp/miopunch-m93-20261018/old-native-counterpart-build/receipt.json')]:\n"+driver[b:]
(H/'build.py').write_text(driver)
print(json.dumps({'fixedInputs':len(fixed),'sameOfficialRustBytes':True,'noDependencyRowsChanged':True}))

import hashlib,json,subprocess,sys,time
from pathlib import Path
H=Path('/tmp/miopunch-m96-20261019');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
name=sys.argv[1];build=H/name;r=json.loads((build/'receipt.json').read_text())
assert r['exit']==0 and r['qualifiedForFrozenRun'] and r['sourceFrozenDuringBuild']
fixed=json.loads((H/'fixed-consumer-inputs.json').read_text());assert all(sha(p)==h for p,h in fixed.items())
binary=build/'pinned/m96-original-auth-consumer';assert sha(binary)==r['artifacts'][str(binary)]
out=H/(name+'-runtime');out.mkdir();started=time.monotonic()
result=subprocess.run([str(binary)],capture_output=True,text=True,timeout=10)
(out/'stdout.log').write_text(result.stdout);(out/'stderr.log').write_text(result.stderr)
assert sha(binary)==r['artifacts'][str(binary)] and all(sha(p)==h for p,h in fixed.items())
receipt={'exit':result.returncode,'seconds':time.monotonic()-started,'forcedTermination':False,
         'binarySha256':sha(binary),'consumerSha256':sha(H/'original-auth-consumer.rs'),
         'buildReceiptSha256':sha(build/'receipt.json'),'fixedInputsUnchanged':True,
         'stdoutSha256':sha(out/'stdout.log'),'stderrSha256':sha(out/'stderr.log')}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
raise SystemExit(result.returncode)

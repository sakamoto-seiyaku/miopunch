import hashlib
import json
import tarfile
from pathlib import Path

ROOT = Path('/home/js/Git/miopunch')
HERE = Path('/tmp/miopunch-m96-20261019')
OUT = ROOT / 'docs/evidence/auth-error-compatibility-2026-10-19'
OUT.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_text())

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

protected = read(HERE / 'protected-wip.json')
assert all(sha(ROOT / r['path']) == r['sha256'] for r in protected)
cases = {}
for name in ['final-sdk-story', 'final-sdk-negatives',
             'final-browser-incoming-active-rtc']:
    d = HERE / name
    e = read(d / 'execution.json')
    r = read(d / 'runtime/private-runtime-receipt.json')
    assert e['qualified'] and r['qualified'] and r['cleanupQualified']
    assert r['business']['result'] == 'PONG' and r['approval']['new_records'] == 1
    assert r['pendingReopen']['id'] == r['completeReopen']['id']
    assert r['currentStrictPurpose2Qualified'] and r['businessQualified']
    cases[name] = {
        'qualified': True,
        'execution': e,
        'privateRawReceiptSha256': sha(d / 'runtime/private-runtime-receipt.json'),
        'strictRestrictedRequest': True,
        'approvalRecords': r['approval']['new_records'],
        'bothMaterialsDurable': all(r['materialCompletion']['status'][k]
                                   for k in ['authorization_saved', 'secret_saved']),
        'sameBrowserIdentityReopened': True,
        'sameNativeIdentityReopened': True,
        'memberReply': r['business']['result'],
        'initialCarrier': 'RTC' if r['nativeMemberReleased'].get('selected_rtc') else 'Relay',
        'browserClose': r['cleanup']['browser'],
        'socketImmediateObservationPassed': r['cleanup']['socketImmediateObservationPassed'],
        'lateSocketWaitMs': r['cleanup']['lateSocketWaitMs'],
        'websocketsClosedBeforeContext': r['cleanup']['websocketsClosedBeforeContext'],
        'nativeExit': r['cleanup']['nativeExit'],
        'ownedFixtureRemoved': r['cleanup']['ownedFixtureRemoved'],
        'privateMaterialCleanup': read(d / 'private-material-cleanup.json'),
    }
    case = cases[name]
    if 'improvement' in r:
        assert r['improvement']['result']['outcome'] == 'committed'
        assert r['nativeCommitted']['freshAck'] and r['nativeCommitted']['bothReady']
        assert r['nativeBusiness']['stable_id'] == r['nativeBeforeImprovement']['stable_id']
        case['existingNativeBrowserMemberImprovement'] = {
            'sameOriginal': True, 'freshAck': True, 'bothReady': True,
            'selectedRtc': any(p['selected'] and p['isRtc']
                               for p in r['afterImprovementSelection']['paths']),
            'explicitFixturePolicy': 'PreferDirect',
        }
    if 'negativeCases' in r:
        assert len(r['negativeCases']) == 5
        negative = []
        for n in r['negativeCases']:
            outcome = n.get('outcome', n)
            assert outcome['ordinaryHandle'] is False
            value = {'case': n['name'], 'localOrdinaryHandle': False,
                     'counterpartReleasesUnderItsCurrentView': n['nativeOrdinaryReleases']}
            if 'retired' in n:
                t = n['retired']
                assert t['activeAssociations'] == t['activePumpTasks'] == 0
                assert t['checkpoint']['originalOpen'] is False
                assert not t['checkpoint']['route']['active']
                assert not t['checkpoint']['route']['qualified']
                assert t['checkpoint']['route']['tx_bytes'] + t['checkpoint']['route']['rx_bytes'] == 0
                value.update(originalClosed=True, activeAssociations=0, activePumps=0,
                             routeActive=False, routeQualified=False, queuedBytes=0,
                             checkpointFreshAck=n['checkpoint']['checkpoint']['metadata']['freshAck'])
            negative.append(value)
        assert r['publicDeparture']['status']['stage'] == 'Removed'
        case['negativeCases'] = negative
        case['revocationPropagationScope'] = 'Browser-local departure refuses Browser delivery; the fixed counterpart has not received the new departure record.'
        initial = r['memberOpen']['diagnostics']['bootstrap']
        assert initial['finalReleaseFreshAck'] and initial['stableUnchanged'] and initial['bindingUnchanged']
        case['initialRtcFinalChecks'] = {'freshAck': True, 'stableUnchanged': True,
                                        'bindingUnchanged': True, 'beforeRetainFrames': initial['beforeRetainFrames']}
    if 'browserServedFirstRequest' in r:
        assert r['browserServedFirstRequest'] == {'response': 'AwaitingApproval', 'served': 'AwaitingApproval'}
        assert r['browserServedApproved'] == {'response': 'PendingMaterials', 'served': 'Complete'}
        assert r['browserPrecodeUsage'] == 1 and r['browserServedReplica']['complete']
        assert r['manualApplicantReopen']['sameIdentity']
        assert all(c['sdkClosed'] and c['websocketsClosedBeforeContext'] for c in r['extraBrowserCleanup'])
        case['browserIncoming'] = {'manualApproval': True, 'durableMaterials': True,
                                  'sameApplicantReopened': True, 'memberStream': True,
                                  'precodeUses': 1, 'precodeRetryDoesNotConsumeAgain': True,
                                  'replicaComplete': True, 'extraContextCleanup': r['extraBrowserCleanup']}
    if 'browserIncomingActive' in r:
        assert r['browserIncomingActive']['outcome'] == 'committed'
        sides = {}
        for side in ['initiator', 'responder']:
            before, after = r['browserIncomingActiveBefore'][side], r['browserIncomingActiveAfter'][side]
            b = after['bootstrap']
            assert before['memberStableId'] == after['memberStableId']
            assert b['finalReleaseFreshAck'] and b['stableUnchanged'] and b['bindingUnchanged']
            assert b['coordinator']['freshAck'] and b['coordinator']['bothReady']
            assert any(p['selected'] and p['isRtc'] for p in after['paths'])
            sides[side] = {'sameOriginal': True, 'freshAck': True, 'bothReady': True,
                           'selectedRtc': True, 'beforeRetainFrames': b['beforeRetainFrames']}
        case['browserIncomingActiveControl'] = {'sides': sides, 'originalMemberBusinessAfterRtc': True,
                                               'explicitFixturePolicy': 'PreferDirect'}

builds = {name: read(HERE / name / 'receipt.json') for name in
          ['restored-auth-green', 'affected-auth-tests', 'final-native-sdk', 'final-browser-sdk']}
continuity = {}
for name, receipt in builds.items():
    assert receipt['exit'] == 0 and receipt['sourceFrozenDuringBuild'] and receipt['qualifiedForFrozenRun']
    inputs = read(HERE / name / 'selected-dependency-inputs.json')
    assert all(sha(p) == digest for p, digest in inputs['inputs'].items())
    assert all(sha(ROOT / p) == digest for p, digest in inputs['copiedRepositoryInputs'].items())
    assert all(sha(p) == digest for p, digest in receipt['artifacts'].items())
    continuity[name] = {'allActualSelectedInputsUnchanged': True, 'inputCount': len(inputs['inputs']),
                        'repositoryInputCount': len(inputs['copiedRepositoryInputs']),
                        'immutableArtifactsUnchanged': True, 'sourceDigest': receipt['sourceDigestAfter']}
(HERE / 'final-selected-input-continuity.json').write_text(json.dumps(continuity, indent=2) + '\n')
tests = {name: read(HERE / name / 'receipt.json') for name in
         ['runtime-auth-compatibility', 'runtime-management-auth', 'runtime-management-store', 'runtime-offline-replica']}
assert all(r['exit'] == 0 and r['testsFailed'] == 0 and r['postconditionsPassed']
           and r['nonemptyTestSelection'] and not r['forcedTermination'] for r in tests.values())
assert sum(r['testsPassed'] for r in tests.values()) == 21
original = {name: read(HERE / name / 'receipt.json') for name in
            ['original-auth-baseline-v2', 'original-auth-baseline-v2-runtime',
             'current-auth-red', 'restored-auth-green-runtime']}
assert original['current-auth-red']['exit'] == 101
assert all(r['exit'] == 0 for n, r in original.items() if n != 'current-auth-red')
write('validation.json', {
    'baselineCommit': (HERE / 'source-baseline.txt').read_text().strip(),
    'implementationCommit': (HERE / 'source-commit.txt').read_text().strip(),
    'protectedPreexistingFileCount': len(protected), 'protectedPreexistingHashesUnchanged': True,
    'beforeProductionEdits': read(HERE / 'before-production-edits.json'),
    'originalContractContinuity': read(HERE / 'original-contract-continuity.json'),
    'sameConsumerOfficialAndForkBuildsAndRuntimes': original,
    'fixedConsumerInputs': read(HERE / 'fixed-consumer-inputs.json'),
    'finalBuilds': builds, 'actualSelectedInputContinuity': continuity,
    'affectedRuntimeTests': tests, 'selectedTestEntriesPassed': 21,
    'subprocessWorkerScope': 'One selected store entry is the existing worker, also invoked by the actual process-restart parent test.',
    'finalSdkCases': cases,
    'historicalTestStorage': [read(HERE / 'historical-test-compression.json'),
                              read(HERE / 'historical-test-compression-round2.json')],
    'failedPreparations': read(HERE / 'failed-preparations.json'),
    'scope': 'M96 independent checked-auth error and affected application regressions; owned loopback only; broader M91 and public/physical matrix remain separate',
})

files = set()
def include(p):
    if p.is_file(): files.add(p)
for pattern in ['*.py', '*-context.json', '*.rs']:
    for p in HERE.glob(pattern): include(p)
for name in ['review-spec.md', 'review-standards.md', 'fixed-consumer-inputs.json',
             'before-production-edits.json', 'source-baseline.txt', 'owned-source-files.json',
             'source-commit.txt', 'source-commit-receipt.json', 'final-selected-input-continuity.json',
             'sdk-consumer-delta.json', 'original-contract-continuity.json', 'failed-preparations.json',
             'historical-test-compression.json', 'historical-test-compression-round2.json', 'cache-review.json']:
    include(HERE / name)
for d in HERE.iterdir():
    if not d.is_dir(): continue
    sdk_run = (d / 'execution.json').is_file()
    for name in ['Cargo.toml', 'Cargo.lock', 'receipt.json', 'preconditions.json',
                 'cargo.jsonl', 'cargo.stderr.log', 'selected-dependency-inputs.json',
                 'bindgen.stdout.log', 'bindgen.stderr.log', 'execute.py', 'run.mjs',
                 'execution.json', 'execution-preconditions.json', 'private-material-cleanup.json']:
        include(d / name)
    if not sdk_run:
        for name in ['stdout.log', 'stderr.log', 'runtime-driver.py']: include(d / name)
for directory in ['before-source', 'official-auth/src']:
    for p in (HERE / directory).rglob('*'):
        if p.suffix in ['.rs', '.md']: include(p)

manifest = {str(p.relative_to(HERE)): {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(files)}
archive = OUT / 'raw-verification.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for p in sorted(files): tar.add(p, arcname=str(p.relative_to(HERE)), recursive=False)
with tarfile.open(archive) as tar:
    assert set(tar.getnames()) == set(manifest)
    for member in tar:
        data = tar.extractfile(member).read(); expected = manifest[member.name]
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
write('archive-manifest.json', {'members': manifest, 'archiveSha256': sha(archive),
    'archiveBytes': archive.stat().st_size, 'allMembersReadBackAndVerified': True,
    'excluded': ['Fixed executables/WASM and selected source copies remain under local receipt paths',
                 'Private SDK runtime logs, identities, SDP, stores, private keys and NSS databases',
                 'Losslessly compressed historical test executables remain local at their receipt paths'],
    'sdkResults': 'Explicit scalar/hash allowlist in validation.json'})
print(json.dumps({'archiveMembers': len(manifest), 'archiveBytes': archive.stat().st_size,
                  'finalSdkCases': len(cases), 'testEntriesPassed': 21}))


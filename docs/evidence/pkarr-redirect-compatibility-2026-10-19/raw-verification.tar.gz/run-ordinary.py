import argparse,hashlib,json,subprocess,threading,time
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
H=Path('/tmp/miopunch-m99-20261019');R=Path('/home/js/Git/miopunch')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('build');p.add_argument('--expect-failure',action='store_true');a=p.parse_args()
B=H/a.build;b=read(B/'receipt.json');c=read(H/(a.build+'-context.json'));i=read(B/'selected-dependency-inputs.json')
assert b['exit']==0 and b['qualifiedForFrozenRun'] and b['sourceFrozenDuringBuild']
assert all(sha(p)==v for p,v in i['inputs'].items())
assert all(sha(R/p)==v for p,v in i['copiedRepositoryInputs'].items())
assert all(sha(p)==v for p,v in b['artifacts'].items())
binary=Path(next(p for p in b['artifacts'] if 'm99-' in Path(p).name))
O=H/a.name;O.mkdir();(O/'preconditions.json').write_text(json.dumps({'allActualSelectedInputsAndArtifactHashesPassedBeforeActors':True,'buildReceiptSha256':sha(B/'receipt.json'),'buildContextSha256':sha(H/(a.build+'-context.json')),'driverSha256':sha(__file__),'binarySha256':sha(binary)},indent=2)+'\n')
events=[];packets={};lock=threading.Lock();servers=[];threads=[]
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):self.transact()
 def do_PUT(self):self.transact()
 def transact(self):
  body=self.rfile.read(int(self.headers.get('Content-Length','0')))
  with lock:events.append({'facility':self.server.facility,'method':self.command,'pathSha256':hashlib.sha256(self.path.encode()).hexdigest(),'bodyBytes':len(body),'bodySha256':hashlib.sha256(body).hexdigest()})
  if self.server.redirect:
   self.send_response(307);self.send_header('Location',self.server.redirect+self.path);out=b''
  elif self.command=='PUT':
   packets[self.path]=body;self.send_response(200);out=b''
  elif self.path in packets:
   self.send_response(200);out=packets[self.path]
  else:self.send_response(404);out=b''
  self.send_header('Content-Length',str(len(out)));self.send_header('Connection','close');self.end_headers();self.wfile.write(out)
def server(facility,redirect=None):
 s=ThreadingHTTPServer(('127.0.0.1',0),Handler);s.facility=facility;s.redirect=redirect
 t=threading.Thread(target=s.serve_forever);t.start();servers.append(s);threads.append(t);return 'http://127.0.0.1:'+str(s.server_port)
results=[];started=time.monotonic()
try:
 target=server('target');origin=server('redirect',target)
 for mode in ['raw-new','publisher-resolver']:
  offset=len(events)
  run=subprocess.run([str(binary),mode,origin+'/pkarr'],capture_output=True,text=True,timeout=12)
  (O/(mode+'.stdout.log')).write_text(run.stdout);(O/(mode+'.stderr.log')).write_text(run.stderr)
  actual=events[offset:];ok=run.returncode==0
  assert ok != a.expect_failure, (mode,run.returncode,run.stderr)
  if ok:
   assert 'SIGNED_PUBLISH_RESOLVE_OK' in run.stdout
   assert {e['method'] for e in actual if e['facility']=='target'}=={'GET','PUT'}
  else:assert not any(e['facility']=='target' for e in actual)
  assert 'ENDPOINT_CLOSE_RETURNED' in run.stdout
  results.append({'mode':mode,'exit':run.returncode,'ordinarySuccess':ok,'expectedFailureObserved':a.expect_failure,'events':actual,'normalEndpointClose':True})
finally:
 for s in servers:s.shutdown();s.server_close()
 for t in threads:t.join(timeout=2)
assert all(not t.is_alive() for t in threads)
assert all(sha(p)==v for p,v in i['inputs'].items())
assert all(sha(p)==v for p,v in b['artifacts'].items())
report={'qualified':True,'seconds':time.monotonic()-started,'cases':results,'ownedServersClosedAndThreadsJoined':True,'forcedTermination':False,'noPublicTraffic':True,'binarySha256':sha(binary),'sourceDigestAtBuild':b['sourceDigestAfter']}
(O/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'qualified':True,'exits':[r['exit'] for r in results],'ownedServersClosedAndThreadsJoined':True}))

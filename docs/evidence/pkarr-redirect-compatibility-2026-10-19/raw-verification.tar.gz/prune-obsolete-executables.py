import fcntl,gzip,hashlib,json,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m99-20261019');sys.path.insert(0,str(R/'scripts'));import cargo_cache as cache
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected={}
for name in ['original-ordinary-before','original-private-builder-qualified-before','ordinary-green']:
 r=json.loads((H/name/'receipt.json').read_text())
 for p,d in r['artifacts'].items():expected[d]={'retainedImmutablePin':p,'bytes':Path(p).stat().st_size,'buildReceipt':str(H/name/'receipt.json')}
cli=R/'target/debug/miopunch-native-probe';dest=H/'obsolete-cli-fixture.bin.gz';h=sha(cli)
assert not dest.exists()
with cli.open('rb') as src,gzip.open(dest,'wb',compresslevel=1) as dst:
 while b:=src.read(1024*1024):dst.write(b)
digest=hashlib.sha256()
with gzip.open(dest,'rb') as f:
 while b:=f.read(1024*1024):digest.update(b)
assert digest.hexdigest()==h
expected[h]={'retainedLosslessArchive':str(dest),'compressedSha256':sha(dest),'roundTripSha256':h,'bytes':cli.stat().st_size,'reason':'Unused CLI executable from failed broad test selector, never executed. Actual focused tests and SDKs do not select it.'}
live=set()
for p in Path('/proc').iterdir():
 if p.name.isdigit():
  try:live.add(str((p/'exe').resolve(strict=True)))
  except OSError:pass
with (R/'target/.miopunch-build.lock').open('a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX);assert not cache.active_compilers(R)
 rows=[]
 for folder in [R/'target/debug',R/'target/debug/deps',R/'target/debug/examples']:
  for p in folder.iterdir():
   if not p.is_file() or p.is_symlink() or p.stat().st_size not in {x['bytes'] for x in expected.values()}:continue
   with p.open('rb') as f:header=f.read(4)
   if header!=b'\x7fELF':continue
   d=sha(p)
   if d not in expected:continue
   assert str(p) not in live
   rows.append({'path':str(p),'sha256':d,'bytes':p.stat().st_size,**expected[d]})
 review={'reason':'Only exact duplicate cache executables of fixed original consumers, a superseded ordinary diagnostic, and an unused failed-selector CLI. Retain all libraries, SDKs, focused/final tests and raw logs.','files':rows}
 (H/'obsolete-executable-cache-review.json').write_text(json.dumps(review,indent=2)+'\n')
 before=cache.disk_state(R/'target')
 for row in rows:
  p=Path(row['path']);assert sha(p)==row['sha256'];p.unlink()
 after=cache.disk_state(R/'target')
(H/'obsolete-executable-cache-prune.json').write_text(json.dumps({'reviewSha256':sha(H/'obsolete-executable-cache-review.json'),'removedCachePaths':len(rows),'before':before,'after':after,'fixedConsumerPinsAndLosslessCliBytesRetained':True,'noLibrariesSdkOrFinalTestsRemoved':True,'diskLimitsUnchanged':True},indent=2)+'\n')
print(json.dumps({'removedPaths':len(rows),'after':after}))

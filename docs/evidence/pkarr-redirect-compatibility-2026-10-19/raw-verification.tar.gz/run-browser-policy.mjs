import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {createServer} from 'node:http';
import {createRequire} from 'node:module';
const require=createRequire('/home/js/Git/miopunch/browser-probe/harness/package.json');
const {chromium}=require('playwright-core');
const here=path.dirname(new URL(import.meta.url).pathname);
const pkg=path.join(here,'browser-policy-final/pkg');
const output=path.join(here,'runtime-browser-policy');fs.mkdirSync(output);
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const read=p=>JSON.parse(fs.readFileSync(p));
const build=read(path.join(here,'browser-policy-final/receipt.json'));
const inputs=read(path.join(here,'browser-policy-final/selected-dependency-inputs.json'));
const guard=()=>{
 if(build.exit!==0||!build.qualifiedForFrozenRun||!build.sourceFrozenDuringBuild)throw Error('unqualified build');
 for(const [p,h] of Object.entries({...inputs.inputs,...build.artifacts}))if(sha(fs.readFileSync(p))!==h)throw Error('source/artifact changed: '+p);
 const g=read(path.join(here,'runtime-source-guard.json'));
 for(const [p,h] of Object.entries(g.sources))if(sha(fs.readFileSync(path.join('/home/js/Git/miopunch',p)))!==h)throw Error('source guard changed: '+p);
};
guard();const report={qualified:false,events:[],cleanup:{},noPublicTraffic:true};
const packets=new Map();let backend,origin,browserServer,browser,context;
const listen=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r('http://127.0.0.1:'+s.address().port)));
function cors(res){res.setHeader('Access-Control-Allow-Origin','*');res.setHeader('Access-Control-Allow-Methods','PUT, GET, OPTIONS');res.setHeader('Access-Control-Allow-Headers','*');res.setHeader('Connection','close');}
try{
 backend=createServer(async(req,res)=>{
  cors(res);if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
  const chunks=[];for await(const c of req)chunks.push(c);const b=Buffer.concat(chunks);
  report.events.push({facility:'target',method:req.method,pathSha256:sha(req.url),bodyBytes:b.length,bodySha256:sha(b)});
  if(req.method==='PUT'){packets.set(req.url,b);res.end();}else if(packets.has(req.url)){res.end(packets.get(req.url));}else{res.writeHead(404);res.end();}
 });
 const target=await listen(backend);
 origin=createServer(async(req,res)=>{
  cors(res);
  if(req.url.startsWith('/pkarr/')){
   const chunks=[];for await(const c of req)chunks.push(c);const b=Buffer.concat(chunks);
   report.events.push({facility:'redirect',method:req.method,pathSha256:sha(req.url),bodyBytes:b.length,bodySha256:sha(b)});
   res.writeHead(307,{Location:target+req.url});res.end();return;
  }
  if(req.url==='/'){res.setHeader('Content-Type','text/html');res.end('<!doctype html><title>M99 Browser policy fixture</title>');return;}
  const relative=decodeURIComponent(req.url.split('?')[0]).slice(1);
  const file=path.resolve(pkg,relative);
  if(!file.startsWith(pkg+'/')||!fs.existsSync(file)){res.writeHead(404);res.end();return;}
  res.setHeader('Content-Type',file.endsWith('.wasm')?'application/wasm':'text/javascript');res.end(fs.readFileSync(file));
 });
 const base=await listen(origin);
 browserServer=await chromium.launchServer({executablePath:'/home/js/.cache/ms-playwright/chromium-1243/chrome-linux64/chrome',headless:true,args:['--no-sandbox','--disable-background-networking','--disable-component-update','--no-first-run','--disable-default-apps','--disable-sync']});
 browser=await chromium.connect(browserServer.wsEndpoint());context=await browser.newContext();
 await context.route('**/*',async route=>{
  const url=new URL(route.request().url());
  if(url.hostname!=='127.0.0.1')throw Error('unexpected non-loopback URL');
  await route.continue();
 });
 const page=await context.newPage();await page.goto(base);
 report.result=await page.evaluate(async url=>{
  const sdk=await import('/miopunch_browser_probe.js');await sdk.default();
  return JSON.parse(await sdk.check_constraints(url));
 },base+'/pkarr');
 if(!Object.values(report.result).every(v=>v===true))throw Error('failed wasm assertions');
 for(const facility of ['redirect','target']){
  const events=report.events.filter(e=>e.facility===facility);
  if(events.length!==2||events[0].method!=='PUT'||events[1].method!=='GET')throw Error('constrained requests escaped into HTTP');
 }
 report.passed=true;
}finally{
 if(context){await context.close();report.cleanup.contextClosed=true;}
 if(browser){await browser.close();report.cleanup.browserDisconnected=!browser.isConnected();}
 if(browserServer){await browserServer.close();report.cleanup.browserProcessExited=browserServer.process().exitCode!==null;report.cleanup.browserExit=browserServer.process().exitCode;}
 for(const [name,server] of [['origin',origin],['target',backend]])if(server){await new Promise(r=>server.close(r));report.cleanup[name+'Closed']=!server.listening;}
 guard();report.sourceArtifactPostconditionsPassed=true;
 report.qualified=report.passed&&Object.entries(report.cleanup).every(([k,v])=>k==='browserExit'?v===0:v===true);
 fs.writeFileSync(path.join(output,'receipt.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report));
}
if(!report.qualified)process.exitCode=1;

//! Resource policy through public nodes, real admission, relay actors and TLS.
use std::{collections::BTreeSet, net::Ipv4Addr, time::Duration};

use iroh::{Endpoint, EndpointAddr, endpoint::presets};
use iroh_relay::server::{RelayConfig as ServerRelayConfig, Server, ServerConfig};
use miopunch_native_probe::control_protocol::AuthenticatedControl;
use miopunch_native_probe::{
    admission_gate::{ADMISSION_REQUEST_ALPN, ProtocolScope},
    manual_admission::{AdmissionStage, ManualExchange},
    native_network::NativeNetwork,
    resources::{Resource, ResourceConfig, ResourceTable, ResourceUse},
};

struct PkarrFixture {
    url: iroh::RelayUrl,
    requests: std::sync::Arc<std::sync::Mutex<Vec<String>>>,
    packets: std::sync::Arc<std::sync::Mutex<std::collections::BTreeMap<String, Vec<u8>>>>,
    task: tokio::task::JoinHandle<()>,
}

impl PkarrFixture {
    async fn start() -> Self {
        Self::start_with_redirect(None).await
    }

    async fn start_with_redirect(redirect: Option<String>) -> Self {
        use tokio::io::{AsyncReadExt, AsyncWriteExt};
        let listener = tokio::net::TcpListener::bind((Ipv4Addr::LOCALHOST, 0))
            .await
            .unwrap();
        let url = format!("http://{}/pkarr", listener.local_addr().unwrap())
            .parse()
            .unwrap();
        let requests = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let packets = std::sync::Arc::new(std::sync::Mutex::new(std::collections::BTreeMap::<
            String,
            Vec<u8>,
        >::new()));
        let recorded = requests.clone();
        let stored = packets.clone();
        let task = tokio::spawn(async move {
            while let Ok((mut stream, _)) = listener.accept().await {
                let mut bytes = Vec::new();
                let end = loop {
                    let mut part = [0; 4096];
                    let count = stream.read(&mut part).await.unwrap();
                    if count == 0 {
                        return;
                    }
                    bytes.extend_from_slice(&part[..count]);
                    if let Some(end) = bytes.windows(4).position(|part| part == b"\r\n\r\n") {
                        break end + 4;
                    }
                    assert!(bytes.len() < 8192);
                };
                let header = String::from_utf8(bytes[..end].to_vec()).unwrap();
                let request = header.lines().next().unwrap().to_owned();
                recorded.lock().unwrap().push(request.clone());
                let length = header
                    .lines()
                    .find_map(|line| {
                        line.to_ascii_lowercase()
                            .strip_prefix("content-length: ")
                            .and_then(|value| value.parse::<usize>().ok())
                    })
                    .unwrap_or(0);
                assert!(length < 65536);
                while bytes.len() < end + length {
                    let mut part = [0; 4096];
                    let count = stream.read(&mut part).await.unwrap();
                    if count == 0 {
                        return;
                    }
                    bytes.extend_from_slice(&part[..count]);
                }
                let fields: Vec<_> = request.split_whitespace().collect();
                let (status, body) = if redirect.is_some() {
                    ("302 Found", vec![])
                } else {
                    match fields[0] {
                        "PUT" => {
                            stored
                                .lock()
                                .unwrap()
                                .insert(fields[1].to_owned(), bytes[end..end + length].to_vec());
                            ("200 OK", vec![])
                        }
                        "GET" => match stored.lock().unwrap().get(fields[1]).cloned() {
                            Some(body) => ("200 OK", body),
                            None => ("404 Not Found", vec![]),
                        },
                        _ => panic!("unexpected fixture method"),
                    }
                };
                let location = redirect
                    .as_ref()
                    .map(|url| format!("Location: {url}\r\n"))
                    .unwrap_or_default();
                let response = format!(
                    "HTTP/1.1 {status}\r\n{location}Content-Length: {}\r\nConnection: close\r\n\r\n",
                    body.len()
                );
                stream.write_all(response.as_bytes()).await.unwrap();
                stream.write_all(&body).await.unwrap();
            }
        });
        Self {
            url,
            requests,
            packets,
            task,
        }
    }

    async fn close(self) -> Vec<String> {
        self.task.abort();
        let _ = self.task.await;
        self.requests.lock().unwrap().clone()
    }
}


#[tokio::test]
async fn disabled_pkarr_lookup_facility_is_never_accessed() {
    use iroh::address_lookup::PkarrResolver;
    let facility = PkarrFixture::start().await;
    let dir = tempfile::tempdir().unwrap();
    let node = NativeNetwork::create(dir.path().join("node"))
        .await
        .unwrap();
    let mut config = ResourceConfig::with_defaults(ResourceTable {
        revision: 1,
        resources: vec![Resource {
            url: facility.url.to_string(),
            uses: BTreeSet::from([ResourceUse::Lookup]),
            limitation: "controlled HTTP lookup".into(),
        }],
    });
    config
        .disabled
        .insert((facility.url.to_string(), ResourceUse::Lookup));
    node.save_resource_configuration(&config).unwrap();
    let endpoint = node
        .bind_endpoint_with(
            Endpoint::builder(presets::Minimal)
                .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled)
                .address_lookup(PkarrResolver::builder(
                    std::ops::Deref::deref(&facility.url).clone(),
                )),
        )
        .await
        .unwrap();
    let attempted = tokio::time::timeout(
        Duration::from_secs(1),
        endpoint.connect_control(iroh::SecretKey::generate().public(), ADMISSION_REQUEST_ALPN),
    )
    .await;
    assert!(!matches!(attempted, Ok(Ok(_))));
    endpoint.close().await;
    node.close().await;
    let accesses = facility.close().await;
    eprintln!("MIO38_LOOKUP disabled=true actual_http_requests={accesses:?}");
    assert!(
        accesses.is_empty(),
        "a disabled lookup facility must not be queried"
    );
}

#[tokio::test]
async fn disabled_pkarr_publication_facility_is_never_accessed() {
    use iroh::address_lookup::{AddrFilter, PkarrPublisher};
    let facility = PkarrFixture::start().await;
    let dir = tempfile::tempdir().unwrap();
    let node = NativeNetwork::create(dir.path().join("node"))
        .await
        .unwrap();
    let mut config = ResourceConfig::with_defaults(ResourceTable {
        revision: 1,
        resources: vec![],
    });
    config.disabled_uses.insert(ResourceUse::Lookup);
    node.save_resource_configuration(&config).unwrap();
    let endpoint = node
        .bind_endpoint_with(
            Endpoint::builder(presets::Minimal)
                .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled)
                .address_lookup(
                    PkarrPublisher::builder(std::ops::Deref::deref(&facility.url).clone())
                        .addr_filter(AddrFilter::unfiltered())
                        .republish_interval(Duration::from_millis(50)),
                ),
        )
        .await
        .unwrap();
    endpoint.set_user_data_for_address_lookup(Some("changed".parse().unwrap()));
    tokio::time::sleep(Duration::from_millis(300)).await;
    endpoint.close().await;
    node.close().await;
    let requests = facility.close().await;
    eprintln!("MIO38_LOOKUP publication_disabled=true actual_http_requests={requests:?}");
    assert!(
        requests.is_empty(),
        "a disabled lookup facility must not receive identity publication or refreshes"
    );
}

#[tokio::test]
async fn disabled_lookup_added_after_bind_through_wrappers_is_never_accessed() {
    use iroh::address_lookup::{AddrFilter, FilteredAddressLookup, PkarrPublisher, PkarrResolver};
    let facility = PkarrFixture::start().await;
    let dir = tempfile::tempdir().unwrap();
    let node = NativeNetwork::create(dir.path().join("node"))
        .await
        .unwrap();
    let mut config = ResourceConfig::with_defaults(ResourceTable {
        revision: 1,
        resources: vec![],
    });
    config.disabled_uses.insert(ResourceUse::Lookup);
    node.save_resource_configuration(&config).unwrap();
    let endpoint = node
        .bind_endpoint_with(
            Endpoint::builder(presets::Minimal)
                .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled),
        )
        .await
        .unwrap();
    let lookup = endpoint
        .pkarr_resolver(PkarrResolver::builder(
            std::ops::Deref::deref(&facility.url).clone(),
        ))
        .unwrap();
    let lookup = std::sync::Arc::new(FilteredAddressLookup::new(lookup, AddrFilter::unfiltered()));
    endpoint.address_lookup().unwrap().add(lookup);
    let publisher = endpoint
        .pkarr_publisher(
            PkarrPublisher::builder(std::ops::Deref::deref(&facility.url).clone())
                .addr_filter(AddrFilter::unfiltered()),
        )
        .unwrap();
    endpoint
        .address_lookup()
        .unwrap()
        .add(std::sync::Arc::new(FilteredAddressLookup::new(
            publisher,
            AddrFilter::unfiltered(),
        )));
    let attempted = tokio::time::timeout(
        Duration::from_secs(1),
        endpoint.connect_control(iroh::SecretKey::generate().public(), ADMISSION_REQUEST_ALPN),
    )
    .await;
    assert!(!matches!(attempted, Ok(Ok(_))));
    endpoint.close().await;
    node.close().await;
    let requests = facility.close().await;
    eprintln!(
        "MIO38_LOOKUP added_after_bind=true filtered_arc_wrappers=true actual_http_requests={requests:?}"
    );
    assert!(requests.is_empty());
}

#[tokio::test]
async fn allowed_signed_pkarr_lookup_reaches_real_admission_with_data_relay_disabled() {
    use iroh::address_lookup::{AddrFilter, PkarrPublisher, PkarrResolver};
    let facility = PkarrFixture::start().await;
    let dir = tempfile::tempdir().unwrap();
    let mut admin = NativeNetwork::create(dir.path().join("admin"))
        .await
        .unwrap();
    let mut joining = NativeNetwork::join(
        dir.path().join("joining"),
        admin.manual_invitation().unwrap(),
    )
    .await
    .unwrap();
    let mut config = ResourceConfig::with_defaults(ResourceTable {
        revision: 1,
        resources: vec![Resource {
            url: facility.url.to_string(),
            uses: BTreeSet::from([ResourceUse::Lookup]),
            limitation: "controlled pkarr store forwards actual signed packets".into(),
        }],
    });
    config.disabled_uses.insert(ResourceUse::DataRelay);
    admin.save_resource_configuration(&config).unwrap();
    joining.save_resource_configuration(&config).unwrap();
    let url = std::ops::Deref::deref(&facility.url).clone();
    let server = admin
        .bind_endpoint_with(
            Endpoint::builder(presets::Minimal)
                .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled)
                .alpns(vec![ADMISSION_REQUEST_ALPN.to_vec()])
                .bind_addr((Ipv4Addr::LOCALHOST, 0))
                .unwrap()
                .address_lookup(
                    PkarrPublisher::builder(url.clone()).addr_filter(AddrFilter::unfiltered()),
                ),
        )
        .await
        .unwrap();
    let client = joining
        .bind_endpoint_with(
            Endpoint::builder(presets::Minimal)
                .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled)
                .alpns(vec![ADMISSION_REQUEST_ALPN.to_vec()])
                .bind_addr((Ipv4Addr::LOCALHOST, 0))
                .unwrap()
                .address_lookup(PkarrResolver::builder(url)),
        )
        .await
        .unwrap();
    tokio::time::timeout(Duration::from_secs(3), async {
        while facility.packets.lock().unwrap().is_empty() {
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .expect("actual signed identity/address publication");
    let (outgoing, incoming) = tokio::time::timeout(Duration::from_secs(5), async {
        tokio::join!(
            client.connect_control(server.id(), ADMISSION_REQUEST_ALPN),
            async {
                server
                    .accept()
                    .await
                    .unwrap()
                    .accept_control()
                    .unwrap()
                    .await
            }
        )
    })
    .await
    .unwrap();
    let outgoing = std::sync::Arc::new(outgoing.unwrap());
    let incoming = std::sync::Arc::new(incoming.unwrap());
    let (requested, served) = tokio::join!(
        joining.request_manual_admission(&outgoing),
        admin.serve_manual_admission(&incoming)
    );
    assert!(matches!(
        requested.unwrap(),
        ManualExchange::AwaitingApproval
    ));
    assert_eq!(served.unwrap(), AdmissionStage::AwaitingApproval);
    outgoing.close(0u32.into(), b"done");
    incoming.close(0u32.into(), b"done");
    client.close().await;
    server.close().await;
    joining.close().await;
    admin.close().await;
    let requests = facility.close().await;
    assert!(requests.iter().any(|request| request.starts_with("PUT ")));
    assert!(requests.iter().any(|request| request.starts_with("GET ")));
    eprintln!(
        "MIO38_LOOKUP allowed_signed_pkarr=true data_relay_disabled=true id_only_tls=true actual_admission=AwaitingApproval actual_http_requests={requests:?}"
    );
}

#[tokio::test]
async fn allowed_lookup_cannot_redirect_access_to_a_disabled_facility() {
    use iroh::address_lookup::PkarrResolver;
    let forbidden = PkarrFixture::start().await;
    let redirecting = PkarrFixture::start_with_redirect(Some(forbidden.url.to_string())).await;
    let dir = tempfile::tempdir().unwrap();
    let node = NativeNetwork::create(dir.path().join("node"))
        .await
        .unwrap();
    let entries = [&redirecting.url, &forbidden.url]
        .into_iter()
        .map(|url| Resource {
            url: url.to_string(),
            uses: BTreeSet::from([ResourceUse::Lookup]),
            limitation: "controlled HTTP facility".into(),
        })
        .collect();
    let mut config = ResourceConfig::with_defaults(ResourceTable {
        revision: 1,
        resources: entries,
    });
    config
        .disabled
        .insert((forbidden.url.to_string(), ResourceUse::Lookup));
    node.save_resource_configuration(&config).unwrap();
    let endpoint = node
        .bind_endpoint_with(
            Endpoint::builder(presets::Minimal)
                .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled)
                .address_lookup(PkarrResolver::builder(
                    std::ops::Deref::deref(&redirecting.url).clone(),
                )),
        )
        .await
        .unwrap();
    let attempted = tokio::time::timeout(
        Duration::from_secs(1),
        endpoint.connect_control(iroh::SecretKey::generate().public(), ADMISSION_REQUEST_ALPN),
    )
    .await;
    assert!(!matches!(attempted, Ok(Ok(_))));
    endpoint.close().await;
    node.close().await;
    let allowed_requests = redirecting.close().await;
    let forbidden_requests = forbidden.close().await;
    eprintln!(
        "MIO38_LOOKUP redirect_allowed_requests={allowed_requests:?} redirect_forbidden_requests={forbidden_requests:?}"
    );
    assert!(!allowed_requests.is_empty());
    assert!(
        forbidden_requests.is_empty(),
        "an allowed facility must not substitute a forbidden redirect destination"
    );
}

#[tokio::test]
async fn explicit_pkarr_client_rechecks_permission_before_each_request() {
    use iroh::address_lookup::{EndpointData, EndpointInfo, PkarrRelayClient};
    use std::sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    };
    let facility = PkarrFixture::start().await;
    let endpoint = Endpoint::builder(presets::Minimal)
        .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled)
        .bind()
        .await
        .unwrap();
    let allowed = Arc::new(AtomicBool::new(true));
    let check = allowed.clone();
    let url = facility.url.clone();
    let client = PkarrRelayClient::builder(
        std::ops::Deref::deref(&url).clone(),
        endpoint.tls_config().clone(),
        endpoint.dns_resolver().unwrap().clone(),
    )
    .resource_policy(iroh::endpoint::RelayResourcePolicy::new(
        move |resource, usage| {
            *resource == url
                && matches!(usage, iroh::endpoint::RelayResourceUse::Lookup)
                && check.load(Ordering::SeqCst)
        },
    ))
    .build();
    let key = iroh::SecretKey::generate();
    let packet = EndpointInfo::from_parts(key.public(), EndpointData::default())
        .to_pkarr_signed_packet(&key, 30)
        .unwrap();
    client.publish(&packet).await.unwrap();
    assert_eq!(
        client
            .resolve(key.public())
            .await
            .unwrap()
            .to_relay_payload(),
        packet.to_relay_payload()
    );
    allowed.store(false, Ordering::SeqCst);
    assert!(client.publish(&packet).await.is_err());
    assert!(client.resolve(key.public()).await.is_err());
    endpoint.close().await;
    let requests = facility.close().await;
    assert_eq!(requests.len(), 2, "revoked requests must stop before HTTP");
}

#[tokio::test]
async fn allowed_pkarr_publication_cannot_redirect_on_retry_or_reconnect() {
    use iroh::address_lookup::PkarrPublisher;
    use std::sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
    };
    let forbidden = PkarrFixture::start().await;
    let redirecting = PkarrFixture::start_with_redirect(Some(forbidden.url.to_string())).await;
    let dir = tempfile::tempdir().unwrap();
    let node = NativeNetwork::create(dir.path().join("node"))
        .await
        .unwrap();
    let config = ResourceConfig::with_defaults(ResourceTable {
        revision: 1,
        resources: vec![Resource {
            url: redirecting.url.to_string(),
            uses: BTreeSet::from([ResourceUse::Lookup]),
            limitation: "owned redirect service; forbidden origin omitted".into(),
        }],
    });
    node.save_resource_configuration(&config).unwrap();
    let allowed = Arc::new(AtomicBool::new(true));
    let check = allowed.clone();
    let endpoint = node
        .bind_endpoint_with(
            Endpoint::builder(presets::Minimal)
                .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled)
                .address_lookup(
                    PkarrPublisher::builder(std::ops::Deref::deref(&redirecting.url).clone())
                        .resource_policy(iroh::endpoint::RelayResourcePolicy::new(move |_, _| {
                            check.load(Ordering::SeqCst)
                        })),
                ),
        )
        .await
        .unwrap();
    tokio::time::timeout(Duration::from_secs(4), async {
        while redirecting.requests.lock().unwrap().len() < 2 {
            tokio::time::sleep(Duration::from_millis(10)).await;
        }
    })
    .await
    .expect("real failed publication retried on a new HTTP connection");
    allowed.store(false, Ordering::SeqCst);
    let before = redirecting.requests.lock().unwrap().len();
    endpoint.set_user_data_for_address_lookup(Some("permission-changed".parse().unwrap()));
    tokio::time::sleep(Duration::from_millis(2200)).await;
    assert_eq!(
        redirecting.requests.lock().unwrap().len(),
        before,
        "revocation must apply to new publication and background retries"
    );
    endpoint.close().await;
    node.close().await;
    let permitted_requests = redirecting.close().await;
    let forbidden_requests = forbidden.close().await;
    assert!(permitted_requests.len() >= 2);
    assert!(
        permitted_requests
            .iter()
            .all(|request| request.starts_with("PUT "))
    );
    assert!(
        forbidden_requests.is_empty(),
        "every retry/reconnect must keep redirects disabled"
    );
}

#[tokio::test]
async fn pkarr_builder_preserves_both_endpoint_and_caller_restrictions() {
    use iroh::address_lookup::{PkarrPublisher, PkarrResolver};
    for endpoint_allows in [false, true] {
        let facility = PkarrFixture::start().await;
        let dir = tempfile::tempdir().unwrap();
        let node = NativeNetwork::create(dir.path().join("node"))
            .await
            .unwrap();
        let config = ResourceConfig::with_defaults(ResourceTable {
            revision: 1,
            resources: if endpoint_allows {
                vec![Resource {
                    url: facility.url.to_string(),
                    uses: BTreeSet::from([ResourceUse::Lookup]),
                    limitation: "owned lookup fixture".into(),
                }]
            } else {
                vec![]
            },
        });
        node.save_resource_configuration(&config).unwrap();
        let policy = iroh::endpoint::RelayResourcePolicy::new(move |_, _| !endpoint_allows);
        let url = std::ops::Deref::deref(&facility.url).clone();
        let endpoint = node
            .bind_endpoint_with(
                Endpoint::builder(presets::Minimal)
                    .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled)
                    .address_lookup(
                        PkarrPublisher::builder(url.clone()).resource_policy(policy.clone()),
                    )
                    .address_lookup(PkarrResolver::builder(url).resource_policy(policy)),
            )
            .await
            .unwrap();
        let attempted = tokio::time::timeout(
            Duration::from_millis(300),
            endpoint.connect_control(iroh::SecretKey::generate().public(), ADMISSION_REQUEST_ALPN),
        )
        .await;
        assert!(!matches!(attempted, Ok(Ok(_))));
        endpoint.close().await;
        node.close().await;
        assert!(
            facility.close().await.is_empty(),
            "neither policy may broaden the other"
        );
    }
}

#[tokio::test]
async fn prebuilt_unconstrained_pkarr_cannot_bypass_product_policy() {
    use iroh::address_lookup::{AddrFilter, FilteredAddressLookup, PkarrPublisher, PkarrResolver};
    use std::sync::Arc;
    let ordinary = Endpoint::builder(presets::Minimal)
        .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled)
        .bind()
        .await
        .unwrap();
    for before_bind in [true, false] {
        let forbidden = PkarrFixture::start().await;
        let redirecting = PkarrFixture::start_with_redirect(Some(forbidden.url.to_string())).await;
        let dir = tempfile::tempdir().unwrap();
        let node = NativeNetwork::create(dir.path().join("node"))
            .await
            .unwrap();
        node.save_resource_configuration(&ResourceConfig::with_defaults(ResourceTable {
            revision: 1,
            resources: vec![Resource {
                url: redirecting.url.to_string(),
                uses: BTreeSet::from([ResourceUse::Lookup]),
                limitation: "owned redirect origin".into(),
            }],
        }))
        .unwrap();
        let url = std::ops::Deref::deref(&redirecting.url).clone();
        let publisher = Arc::new(FilteredAddressLookup::new(
            PkarrPublisher::builder(url.clone())
                .build(ordinary.secret_key().clone(), ordinary.tls_config().clone()),
            AddrFilter::unfiltered(),
        ));
        let resolver = Arc::new(FilteredAddressLookup::new(
            PkarrResolver::builder(url).build(ordinary.tls_config().clone()),
            AddrFilter::unfiltered(),
        ));
        let mut builder = Endpoint::builder(presets::Minimal)
            .portmapper_config(iroh::endpoint::PortmapperConfig::Disabled);
        if before_bind {
            builder = builder
                .address_lookup(publisher.clone())
                .address_lookup(resolver.clone());
        }
        let endpoint = node.bind_endpoint_with(builder).await.unwrap();
        if !before_bind {
            endpoint.address_lookup().unwrap().add(publisher.clone());
            endpoint.address_lookup().unwrap().add(resolver.clone());
        }
        let attempted = tokio::time::timeout(
            Duration::from_millis(300),
            endpoint.connect_control(iroh::SecretKey::generate().public(), ADMISSION_REQUEST_ALPN),
        )
        .await;
        assert!(!matches!(attempted, Ok(Ok(_))));
        endpoint.close().await;
        drop(publisher);
        drop(resolver);
        node.close().await;
        assert!(
            redirecting.close().await.is_empty(),
            "ordinary prebuilt services require explicit constraints before product registration"
        );
        assert!(forbidden.close().await.is_empty());
    }
    ordinary.close().await;
}

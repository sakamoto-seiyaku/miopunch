import hashlib,json,tarfile
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m99-20261019');O=R/'docs/evidence/pkarr-redirect-compatibility-2026-10-19';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
def write(n,d):(O/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
protected=read(H/'protected-wip.json');assert all(sha(R/r['path'])==r['sha256'] for r in protected)
assert (H/'review-spec.md').is_file() and (H/'review-standards.md').is_file()
names=['focused-resource-tests','browser-policy-final','final-ordinary','final-native-sdk','final-browser-sdk','affected-fixture-typecheck'];builds={};continuity={}
for name in names:
 b=read(H/name/'receipt.json');i=read(H/name/'selected-dependency-inputs.json')
 assert b['exit']==0 and b['qualifiedForFrozenRun'] and b['sourceFrozenDuringBuild']
 assert all(sha(p)==h for p,h in i['inputs'].items())
 assert all(sha(R/p)==h for p,h in i['copiedRepositoryInputs'].items())
 assert all(sha(p)==h for p,h in b['artifacts'].items())
 builds[name]=b;continuity[name]={'allActualSelectedInputsUnchanged':True,'selectedInputCount':len(i['inputs']),'repositoryInputCount':len(i['copiedRepositoryInputs']),'immutableArtifactsUnchanged':True,'compiledGlobalSourceDigest':b['sourceDigestAfter'],'currentGraphQualification':read(H/'runtime-source-guard.json')['graphs'][name]}
write('selected-input-continuity.json',continuity)
(H/'final-selected-input-continuity.json').write_text(json.dumps(continuity,indent=2)+'\n')
ordinary={n:read(H/n/'receipt.json') for n in ['original-ordinary-runtime','original-private-builder-runtime','current-ordinary-red-runtime','final-ordinary-runtime']}
for n,r in ordinary.items():
 assert r['qualified'] and r['ownedServersClosedAndThreadsJoined'] and not r['forcedTermination']
 assert [c['exit'] for c in r['cases']]==([1,1] if n=='current-ordinary-red-runtime' else [0,0])
unit=read(H/'runtime-pkarr-resources/receipt.json');assert unit['exit']==unit['testsFailed']==0 and unit['testsPassed']==9 and unit['postconditionsPassed'] and not unit['forcedTermination']
browser=read(H/'runtime-browser-policy/receipt.json');assert browser['qualified'] and browser['cleanup']['browserExit']==0
assert len(browser['events'])==4
for facility in ['redirect','target']:assert [e['method'] for e in browser['events'] if e['facility']==facility]==['PUT','GET']
sdk=H/'final-sdk-story';e=read(sdk/'execution.json');r=read(sdk/'runtime/private-runtime-receipt.json')
assert e['qualified'] and r['qualified'] and r['cleanupQualified'] and r['currentStrictPurpose2Qualified']
assert e['rawReceiptSha256']==sha(sdk/'runtime/private-runtime-receipt.json')
assert r['business']['result']=='PONG' and r['approval']['new_records']==1
assert r['pendingReopen']['id']==r['completeReopen']['id']
assert all(r['materialCompletion']['status'][k] for k in ['authorization_saved','secret_saved'])
assert r['cleanup']['nativeExit']=={'code':0,'signal':None}
assert r['cleanup']['websocketsClosedBeforeContext'] and r['cleanup']['ownedFixtureRemoved']
assert read(sdk/'execution-preconditions.json')['pins'][str(H/'runtime-source-guard.json')]==sha(H/'runtime-source-guard-sdk-execution.json')
public_sdk={'execution':e,'privateRawReceiptSha256':sha(sdk/'runtime/private-runtime-receipt.json'),'strictRestrictedRequest':True,'approvalRecords':1,'bothMaterialsDurable':True,'sameBrowserIdentityReopened':True,'sameNativeIdentityReopened':True,'memberReply':'PONG','browserClose':r['cleanup']['browser'],'websocketsClosedBeforeContext':True,'socketImmediateObservationPassed':r['cleanup']['socketImmediateObservationPassed'],'nativeExit':r['cleanup']['nativeExit'],'ownedFixtureRemoved':True,'privateMaterialCleanup':read(sdk/'private-material-cleanup.json'),'actualExecutionGuardRetainedExact':read(H/'runtime-guard-continuity.json')}
write('validation.json',{'baselineCommit':(H/'source-baseline.txt').read_text().strip(),'implementationCommit':(H/'source-commit.txt').read_text().strip(),'protectedPreexistingFileCount':len(protected),'protectedHashesUnchanged':True,'beforeProductionEdits':read(H/'before-production-edits.json'),'originalContractContinuity':read(H/'original-contract-continuity.json'),'originalPrivateBuilderOverlay':{'qualification':'Test-only private-field constructor adapter appended to original source; existing build method unchanged. Not an original public consumer.','manifest':read(H/'original-private-builder-overlay.json'),'historicalManifests':read(H/'historical-selector-manifests.json')},'ordinaryRuntimeCases':ordinary,'productResourceTests':unit,'selectedTestSourceProvenance':read(H/'selected-resource-test-provenance.json'),'browserActualFetch':browser,'finalBuilds':builds,'actualSelectedInputContinuity':continuity,'finalSdkStory':public_sdk,'failedPreparations':read(H/'failed-preparations.json'),'reviews':{'Standards':0,'Spec':0,'reranBuildOrRuntime':False},'scope':'M99 ordinary pkarr redirects, explicit constrained clients/builders, saved product startup policy and Browser boundary. External service declarations are contracts, not sandboxing independently started tasks or live rebinding of separately built publisher actors. Broader public/physical matrix remains M91.'})
files=set()
def include(p):
 if p.is_file():files.add(p)
for pattern in ['*.py','*.rs','*-context.json']:
 for p in H.glob(pattern):include(p)
for n in ['review-spec.md','review-standards.md','review-summary.md','source-baseline.txt','source-commit.txt','source-commit-receipt.json','owned-source-files.json','implementation-owned-files.json','before-production-edits.json','fixed-consumer-inputs.json','original-private-builder-overlay.json','historical-selector-manifests.json','original-contract-continuity.json','selected-resource-test-provenance.json','runtime-source-guard.json','runtime-source-guard-sdk-execution.json','runtime-guard-continuity.json','final-selected-input-continuity.json','failed-preparations.json','historical-test-compression.json','historical-m98-fixture-compression.json','historical-ordinary-fixture-compression.json','obsolete-executable-cache-review.json','obsolete-executable-cache-prune.json','obsolete-m93-duplicate-cache-review-round2.json','obsolete-m98-intermediate-review.json','superseded-ordinary-fixture-review.json']:
 include(H/n)
include(H/'run-browser-policy.mjs')
for d in H.iterdir():
 if not d.is_dir():continue
 for n in ['Cargo.toml','Cargo.lock','receipt.json','preconditions.json','cargo.jsonl','cargo.stderr.log','selected-dependency-inputs.json','bindgen.stdout.log','bindgen.stderr.log','execute.py','run.mjs','execution.json','execution-preconditions.json','private-material-cleanup.json']:
  include(d/n)
for d in ['before-source','original-private-builder-overlay']:
 for p in (H/d).rglob('*'):
  if p.suffix in ['.rs','.md','.toml','.lock'] or p.name=='Cargo.lock':include(p)
# All ordinary-consumer logs contain only success markers/error categories;
# product-test/SDK logs with synthetic identities remain local.
for n in ordinary:
 for mode in ['raw-new','publisher-resolver']:
  for suffix in ['stdout.log','stderr.log']:include(H/n/(mode+'.'+suffix))
manifest={str(p.relative_to(H)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(files)}
archive=O/'raw-verification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for p in sorted(files):t.add(p,arcname=str(p.relative_to(H)),recursive=False)
with tarfile.open(archive) as t:
 assert set(t.getnames())==set(manifest)
 for m in t:
  data=t.extractfile(m).read();v=manifest[m.name]
  assert len(data)==v['bytes'] and hashlib.sha256(data).hexdigest()==v['sha256']
write('archive-manifest.json',{'members':manifest,'archiveSha256':sha(archive),'archiveBytes':archive.stat().st_size,'allMembersReadBackAndVerified':True,'excluded':['Private SDK receipts, synthetic identity/invitation/actor/store logs, keys and NSS data; scalar/hash allowlist only','Product test stdout/stderr identity logs remain local, raw log hashes retained','Immutable executables/WASM, selected source copies and losslessly compressed historical fixtures remain local with hash/restore receipts']})
(O/'review.md').write_text((H/'review-summary.md').read_text()+'\n'+(H/'review-standards.md').read_text()+'\n'+(H/'review-spec.md').read_text())
print(json.dumps({'archiveMembers':len(manifest),'archiveBytes':archive.stat().st_size,'productTestsPassed':9,'browserFetchPassed':True,'sdkStoryPassed':True}))

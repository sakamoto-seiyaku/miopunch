No Standards findings in 67d4f496…12623770 (one commit, seven changed files).

Documented violations: none. Ordinary constructors recover upstream redirect defaults under ADR 0012; constraints require explicit policy. Existing public signatures and trait implementations remain usable. Documentation distinguishes ordinary behavior, constrained behavior and third-party declarations.

Baseline smells: none warrant reporting. Constructor logic and endpoint/caller policy intersection are centralized. Wrapper delegation preserves the new capability contract. Publisher metadata reflects constraints enforced by its separately owned background client.

Evidence sampled: unchanged-consumer continuity, selected product-test provenance, shared-cache driver guards, complete foreign lock-row validation, final ordinary/SDK builds, successful fixture typecheck, Browser cleanup, runtime input freezing and reviewed cache pruning. Failed preparation receipts remain separately identifiable.

Limits: read-only review of every changed hunk; no builds, tests, edits or tracker writes. Evidence packaging was outside this review.

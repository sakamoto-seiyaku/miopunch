import hashlib,importlib.util,json,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m99-20261019');U=Path('/tmp/mio81-final-peer-assertion-sdk-root-20261007/build-current-sdk.py')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(U)=='2b7e969a1f90fc93eacc80d8b62890f0bb0ef8f40dc140d9398ef1a6029671e1'
s=importlib.util.spec_from_file_location('m99_capture',U);sdk=importlib.util.module_from_spec(s);sys.modules[s.name]=sdk;s.loader.exec_module(sdk)
sources=sdk.current_sources();tools=sdk.tool_snapshot();graphs={}
for name in sys.argv[1:]:
 d=H/name;c=H/(name+'-context.json');receipt=json.loads((d/'receipt.json').read_text());context=json.loads(c.read_text());selected=json.loads((d/'selected-dependency-inputs.json').read_text())
 assert receipt['exit']==0 and receipt['qualifiedForFrozenRun'] and receipt['sourceFrozenDuringBuild']
 assert context['tools']==tools
 for group in ['fixedInputs','selectorPins','artifactPins']:
  for p,h in context[group].items():
   if sha(p)==h:continue
   assert group=='fixedInputs' and p==str(H/'browser-policy-consumer.rs') and p not in selected['inputs']
   assert sha(H/'browser-policy-consumer-v1.rs')==h, (name,p)

 assert all(sha(p)==h for p,h in selected['inputs'].items()),name
 assert all(sha(R/p)==h for p,h in selected['copiedRepositoryInputs'].items()),name
 assert all(sha(p)==h for p,h in receipt['artifacts'].items()),name
 diff={p for p in set(sources)|set(context['sources']) if sources.get(p)!=context['sources'].get(p)}
 assert not {str(R/p) for p in diff}&set(selected['inputs']),(name,diff)
 graphs[name]={'buildReceiptSha256':sha(d/'receipt.json'),'buildContextSha256':sha(c),'selectedInputManifestSha256':sha(d/'selected-dependency-inputs.json'),'allActualSelectedInputsAndArtifactsUnchanged':True,'nonselectedGlobalSourceChanges':sorted(diff)}
(H/'runtime-source-guard.json').write_text(json.dumps({'sources':sources,'tools':tools,'graphs':graphs,'driverSha256':sha(__file__)},indent=2)+'\n')
print(json.dumps({'graphs':len(graphs),'sourceDigest':sdk.json_digest(sources)}))

## Standards

0 findings. See review-standards.md.

## Spec

0 findings. See review-spec.md.

Both reviewers inspected code and existing evidence without rerunning builds or runtime checks.

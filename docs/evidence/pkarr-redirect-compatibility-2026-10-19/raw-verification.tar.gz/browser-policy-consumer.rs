use iroh::{Endpoint, SecretKey};
use iroh::address_lookup::{AddressLookup, EndpointData, EndpointInfo, PkarrPublisher, PkarrRelayClient, PkarrResolver};
use iroh::endpoint::{presets, PortmapperConfig, RelayResourcePolicy};
use n0_future::StreamExt;
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub async fn check_constraints(url: String) -> Result<JsValue, JsValue> {
    let endpoint = Endpoint::builder(presets::Minimal)
        .portmapper_config(PortmapperConfig::Disabled).bind().await
        .map_err(|_| JsValue::from_str("ordinary bind failed"))?;
    let key = SecretKey::generate();
    let packet = EndpointInfo::from_parts(key.public(), EndpointData::default())
        .to_pkarr_signed_packet(&key, 30).unwrap();
    let ordinary = PkarrRelayClient::new(url.parse().unwrap());
    ordinary.publish(&packet).await.map_err(|_| JsValue::from_str("ordinary publish failed"))?;
    assert_eq!(ordinary.resolve(key.public()).await.map_err(|_| JsValue::from_str("ordinary resolve failed"))?.to_relay_payload(), packet.to_relay_payload());
    let constrained = PkarrRelayClient::builder(url.parse().unwrap())
        .resource_policy(RelayResourcePolicy::new(|_, _| true)).build();
    assert!(constrained.publish(&packet).await.is_err());
    assert!(constrained.resolve(key.public()).await.is_err());
    let publisher = PkarrPublisher::builder(url.parse().unwrap())
        .resource_policy(RelayResourcePolicy::new(|_, _| true))
        .build(key.clone(), endpoint.tls_config().clone());
    publisher.publish(&EndpointData::default());
    let resolver = PkarrResolver::builder(url.parse().unwrap())
        .resource_policy(RelayResourcePolicy::new(|_, _| true)).build(endpoint.tls_config().clone());
    assert!(resolver.resolve(key.public()).unwrap().next().await.unwrap().is_err());
    let registered = Endpoint::builder(presets::Minimal)
        .portmapper_config(PortmapperConfig::Disabled)
        .relay_resource_policy(RelayResourcePolicy::new(|_, _| true))
        .address_lookup(PkarrPublisher::builder(url.parse().unwrap()))
        .address_lookup(PkarrResolver::builder(url.parse().unwrap()))
        .bind().await.map_err(|_| JsValue::from_str("constrained bind failed"))?;
    registered.set_user_data_for_address_lookup(Some("browser-boundary".parse().unwrap()));
    let mut results = Box::pin(registered.address_lookup().unwrap().resolve(key.public()));
    assert!(results.next().await.unwrap().is_err());
    n0_future::time::sleep(std::time::Duration::from_millis(250)).await;
    drop(results);
    drop(publisher);
    registered.close().await;
    endpoint.close().await;
    Ok(JsValue::from_str(r#"{"ordinarySignedFetch":true,"constrainedRawDenied":true,"constrainedPublisherResolverDenied":true,"registeredExplicitPolicyDenied":true,"endpointCloseReturned":true}"#))
}

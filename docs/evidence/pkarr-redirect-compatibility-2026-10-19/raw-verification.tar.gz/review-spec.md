No Spec findings.

The change restores ordinary native redirects and adds explicit constraints through client, publisher and resolver builders. Endpoint policies are intersected with caller restrictions; constrained native requests disable redirects and recheck permission. Browser constrained requests stop before Fetch. Conservative registry checks and wrapper propagation prevent ordinary prebuilt services from bypassing product restrictions.

Reviewed evidence includes unchanged published/fork consumers, real RED failures, successful final signed PUT/GET, nine resource tests, Chromium cross-origin behavior, and the full Native/Browser SDK story with natural cleanup.

Limits: inspected existing source/controllers/receipts without rerunning checks. The inaccessible original client builder is covered by a clearly labelled private-field test adapter. External service declarations remain contracts, without sandboxing independently started actors; product policies remain startup snapshots.

import json,subprocess
from pathlib import Path
H=Path('/tmp/miopunch-m104-20261019');ID='2ed5ec95-0117-4e33-9f4b-29aba2653680'
BASE=['rtk','proxy','/home/js/.agents/skills/plane-ops/scripts/plane-ops.sh','--defaults','docs/agents/plane-defaults.json']
def call(name,args):
 r=subprocess.run(BASE+args+['--json'],capture_output=True,text=True,check=True);d=json.loads(r.stdout);(H/(name+'.json')).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n');return d
item=call('m104-before',['work-item','get',ID]);edges=call('m104-relations',['work-item','relations','list',ID]);members=call('members',['member','list']);comments=call('m104-comments',['work-item','comments','list',ID])
assert item['parent']=='6d5cd846-3c1b-4c21-977e-fdafc208f876' and item['assignees']==[] and item['state']=='e390ad0b-ae65-4e12-aa9c-4e34080f3d19'
assert not edges.get('blocked_by',[]),edges
member=json.dumps(members);assert 'de705fdc-c1ec-4e53-b30d-8509dc7f5bc6' in member and 'john' in member.lower()
requested=dict(assignees=['de705fdc-c1ec-4e53-b30d-8509dc7f5bc6'],state='b9e886ed-dd5f-491b-a8a0-8274b6c7fb8d')
call('m104-assigned',['work-item','update',ID,'--raw-json',json.dumps(requested)])
after=call('m104-claimed',['work-item','get',ID])
for k,v in requested.items():assert after[k]==v
for k in ['parent','labels','description_html','name','priority']:assert after[k]==item[k]
print(json.dumps({'claimed':104,'metadataPreserved':True,'blockers':edges}))

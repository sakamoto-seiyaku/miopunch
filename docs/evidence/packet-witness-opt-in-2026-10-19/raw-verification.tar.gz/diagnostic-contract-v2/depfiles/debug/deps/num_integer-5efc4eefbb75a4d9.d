/home/js/Git/miopunch/target/debug/deps/num_integer-5efc4eefbb75a4d9.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/roots.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/average.rs

/home/js/Git/miopunch/target/debug/deps/libnum_integer-5efc4eefbb75a4d9.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/roots.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/average.rs

/home/js/Git/miopunch/target/debug/deps/libnum_integer-5efc4eefbb75a4d9.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/roots.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/average.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/roots.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num-integer-0.1.47/src/average.rs:

/home/js/Git/miopunch/target/debug/deps/matchers-7e84c5c5e23a6f60.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/matchers-0.2.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libmatchers-7e84c5c5e23a6f60.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/matchers-0.2.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libmatchers-7e84c5c5e23a6f60.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/matchers-0.2.0/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/matchers-0.2.0/src/lib.rs:

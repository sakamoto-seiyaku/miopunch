/home/js/Git/miopunch/target/debug/deps/idna_adapter-84e445936976b2af.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libidna_adapter-84e445936976b2af.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libidna_adapter-84e445936976b2af.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs:

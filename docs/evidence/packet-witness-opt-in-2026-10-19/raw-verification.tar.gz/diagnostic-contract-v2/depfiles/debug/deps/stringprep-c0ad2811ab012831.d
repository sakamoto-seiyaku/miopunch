/home/js/Git/miopunch/target/debug/deps/stringprep-c0ad2811ab012831.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/rfc3454.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/tables.rs

/home/js/Git/miopunch/target/debug/deps/libstringprep-c0ad2811ab012831.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/rfc3454.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/tables.rs

/home/js/Git/miopunch/target/debug/deps/libstringprep-c0ad2811ab012831.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/rfc3454.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/tables.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/rfc3454.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/tables.rs:

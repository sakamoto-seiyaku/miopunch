/home/js/Git/miopunch/target/debug/deps/strsim-e96f377b311df5ea.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strsim-0.11.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libstrsim-e96f377b311df5ea.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strsim-0.11.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libstrsim-e96f377b311df5ea.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strsim-0.11.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strsim-0.11.1/src/lib.rs:

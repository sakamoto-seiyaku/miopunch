/home/js/Git/miopunch/target/debug/deps/sqlx_macros-ea25216cd146df78.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sqlx-macros-0.8.6/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsqlx_macros-ea25216cd146df78.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sqlx-macros-0.8.6/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sqlx-macros-0.8.6/src/lib.rs:

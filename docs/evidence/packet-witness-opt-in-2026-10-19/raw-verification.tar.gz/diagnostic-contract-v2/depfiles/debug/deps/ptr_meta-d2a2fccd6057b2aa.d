/home/js/Git/miopunch/target/debug/deps/ptr_meta-d2a2fccd6057b2aa.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/impls.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/../example.md

/home/js/Git/miopunch/target/debug/deps/libptr_meta-d2a2fccd6057b2aa.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/impls.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/../example.md

/home/js/Git/miopunch/target/debug/deps/libptr_meta-d2a2fccd6057b2aa.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/impls.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/../example.md

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/impls.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta-0.3.2/src/../example.md:

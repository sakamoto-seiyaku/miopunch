/home/js/Git/miopunch/target/debug/deps/idna_adapter-5b162f5448e04b9c.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libidna_adapter-5b162f5448e04b9c.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libidna_adapter-5b162f5448e04b9c.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs:

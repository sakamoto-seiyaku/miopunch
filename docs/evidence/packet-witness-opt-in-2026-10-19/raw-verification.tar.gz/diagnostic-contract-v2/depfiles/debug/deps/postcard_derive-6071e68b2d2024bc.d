/home/js/Git/miopunch/target/debug/deps/postcard_derive-6071e68b2d2024bc.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/postcard-derive-0.2.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/postcard-derive-0.2.2/src/max_size.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/postcard-derive-0.2.2/src/schema.rs

/home/js/Git/miopunch/target/debug/deps/libpostcard_derive-6071e68b2d2024bc.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/postcard-derive-0.2.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/postcard-derive-0.2.2/src/max_size.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/postcard-derive-0.2.2/src/schema.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/postcard-derive-0.2.2/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/postcard-derive-0.2.2/src/max_size.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/postcard-derive-0.2.2/src/schema.rs:

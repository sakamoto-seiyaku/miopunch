/home/js/Git/miopunch/target/debug/deps/smol_str-dc41e46cbf527135.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smol_str-0.1.24/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsmol_str-dc41e46cbf527135.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smol_str-0.1.24/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsmol_str-dc41e46cbf527135.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smol_str-0.1.24/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smol_str-0.1.24/src/lib.rs:

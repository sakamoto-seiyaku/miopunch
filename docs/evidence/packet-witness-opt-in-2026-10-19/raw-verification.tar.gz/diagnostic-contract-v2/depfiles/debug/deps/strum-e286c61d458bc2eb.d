/home/js/Git/miopunch/target/debug/deps/strum-e286c61d458bc2eb.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs

/home/js/Git/miopunch/target/debug/deps/libstrum-e286c61d458bc2eb.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs

/home/js/Git/miopunch/target/debug/deps/libstrum-e286c61d458bc2eb.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs:

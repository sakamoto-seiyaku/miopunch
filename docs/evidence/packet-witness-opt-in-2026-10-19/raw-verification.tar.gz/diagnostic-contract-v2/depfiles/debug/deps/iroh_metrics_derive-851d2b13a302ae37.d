/home/js/Git/miopunch/target/debug/deps/iroh_metrics_derive-851d2b13a302ae37.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-metrics-derive-1.0.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libiroh_metrics_derive-851d2b13a302ae37.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-metrics-derive-1.0.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-metrics-derive-1.0.1/src/lib.rs:

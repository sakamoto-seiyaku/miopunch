/home/js/Git/miopunch/target/debug/deps/iroh_dns-efbd83ee36aec932.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/attrs.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/dns.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/endpoint_info.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/pkarr.rs

/home/js/Git/miopunch/target/debug/deps/libiroh_dns-efbd83ee36aec932.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/attrs.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/dns.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/endpoint_info.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/pkarr.rs

/home/js/Git/miopunch/target/debug/deps/libiroh_dns-efbd83ee36aec932.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/attrs.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/dns.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/endpoint_info.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/pkarr.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/attrs.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/dns.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/endpoint_info.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-dns-1.3.0/src/pkarr.rs:

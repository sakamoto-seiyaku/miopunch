/home/js/Git/miopunch/target/debug/deps/munge_macro-76a2ab41fec54733.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge_macro-0.4.7/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libmunge_macro-76a2ab41fec54733.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge_macro-0.4.7/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge_macro-0.4.7/src/lib.rs:

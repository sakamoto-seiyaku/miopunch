/home/js/Git/miopunch/target/debug/deps/spez-a8d0493a5e78cb9d.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/parse.rs

/home/js/Git/miopunch/target/debug/deps/libspez-a8d0493a5e78cb9d.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/parse.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/parse.rs:

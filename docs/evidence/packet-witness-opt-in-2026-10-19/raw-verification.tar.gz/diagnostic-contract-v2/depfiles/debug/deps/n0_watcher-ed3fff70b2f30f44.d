/home/js/Git/miopunch/target/debug/deps/n0_watcher-ed3fff70b2f30f44.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/n0-watcher-1.0.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libn0_watcher-ed3fff70b2f30f44.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/n0-watcher-1.0.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libn0_watcher-ed3fff70b2f30f44.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/n0-watcher-1.0.0/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/n0-watcher-1.0.0/src/lib.rs:

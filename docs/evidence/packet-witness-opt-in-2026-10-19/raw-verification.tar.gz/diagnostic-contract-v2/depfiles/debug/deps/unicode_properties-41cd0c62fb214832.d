/home/js/Git/miopunch/target/debug/deps/unicode_properties-41cd0c62fb214832.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/tables.rs

/home/js/Git/miopunch/target/debug/deps/libunicode_properties-41cd0c62fb214832.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/tables.rs

/home/js/Git/miopunch/target/debug/deps/libunicode_properties-41cd0c62fb214832.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/tables.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/tables.rs:

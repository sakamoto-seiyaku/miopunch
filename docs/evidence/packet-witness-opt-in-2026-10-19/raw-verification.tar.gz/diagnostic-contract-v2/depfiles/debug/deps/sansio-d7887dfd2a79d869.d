/home/js/Git/miopunch/target/debug/deps/sansio-d7887dfd2a79d869.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sansio-1.0.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsansio-d7887dfd2a79d869.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sansio-1.0.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsansio-d7887dfd2a79d869.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sansio-1.0.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sansio-1.0.1/src/lib.rs:

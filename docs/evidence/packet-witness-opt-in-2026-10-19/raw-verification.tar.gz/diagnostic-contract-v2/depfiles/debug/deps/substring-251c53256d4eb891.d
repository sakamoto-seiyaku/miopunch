/home/js/Git/miopunch/target/debug/deps/substring-251c53256d4eb891.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/substring-1.4.5/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsubstring-251c53256d4eb891.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/substring-1.4.5/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsubstring-251c53256d4eb891.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/substring-1.4.5/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/substring-1.4.5/src/lib.rs:

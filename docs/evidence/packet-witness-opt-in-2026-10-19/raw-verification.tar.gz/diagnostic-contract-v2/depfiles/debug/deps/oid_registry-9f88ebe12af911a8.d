/home/js/Git/miopunch/target/debug/deps/oid_registry-9f88ebe12af911a8.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/deprecated.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/load.rs /home/js/Git/miopunch/target/debug/build/oid-registry-c94da442422c2ca2/out/oid_db.rs

/home/js/Git/miopunch/target/debug/deps/liboid_registry-9f88ebe12af911a8.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/deprecated.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/load.rs /home/js/Git/miopunch/target/debug/build/oid-registry-c94da442422c2ca2/out/oid_db.rs

/home/js/Git/miopunch/target/debug/deps/liboid_registry-9f88ebe12af911a8.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/deprecated.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/load.rs /home/js/Git/miopunch/target/debug/build/oid-registry-c94da442422c2ca2/out/oid_db.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/deprecated.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/oid-registry-0.8.1/src/load.rs:
/home/js/Git/miopunch/target/debug/build/oid-registry-c94da442422c2ca2/out/oid_db.rs:

# env-dep:OUT_DIR=/home/js/Git/miopunch/target/debug/build/oid-registry-c94da442422c2ca2/out

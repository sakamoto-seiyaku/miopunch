/home/js/Git/miopunch/target/debug/deps/munge-4c3606f396aac9c9.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/__macro.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/impls.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/internal.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/../example.md

/home/js/Git/miopunch/target/debug/deps/libmunge-4c3606f396aac9c9.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/__macro.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/impls.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/internal.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/../example.md

/home/js/Git/miopunch/target/debug/deps/libmunge-4c3606f396aac9c9.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/__macro.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/impls.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/internal.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/../example.md

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/__macro.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/impls.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/internal.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/munge-0.4.7/src/../example.md:

/home/js/Git/miopunch/target/debug/deps/potential_utf-aed6b76240d3f139.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/uchar.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/ustr.rs

/home/js/Git/miopunch/target/debug/deps/libpotential_utf-aed6b76240d3f139.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/uchar.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/ustr.rs

/home/js/Git/miopunch/target/debug/deps/libpotential_utf-aed6b76240d3f139.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/uchar.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/ustr.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/uchar.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/potential_utf-0.1.6/src/ustr.rs:

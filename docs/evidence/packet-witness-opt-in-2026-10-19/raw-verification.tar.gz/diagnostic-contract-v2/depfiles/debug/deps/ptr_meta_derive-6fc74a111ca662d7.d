/home/js/Git/miopunch/target/debug/deps/ptr_meta_derive-6fc74a111ca662d7.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta_derive-0.3.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta_derive-0.3.2/src/attributes.rs

/home/js/Git/miopunch/target/debug/deps/libptr_meta_derive-6fc74a111ca662d7.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta_derive-0.3.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta_derive-0.3.2/src/attributes.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta_derive-0.3.2/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ptr_meta_derive-0.3.2/src/attributes.rs:

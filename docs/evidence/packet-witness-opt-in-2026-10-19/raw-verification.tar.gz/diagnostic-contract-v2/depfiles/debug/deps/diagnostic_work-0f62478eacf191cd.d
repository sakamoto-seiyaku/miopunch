/home/js/Git/miopunch/target/debug/deps/diagnostic_work-0f62478eacf191cd.d: /home/js/Git/miopunch/tests/diagnostic_work.rs

/home/js/Git/miopunch/target/debug/deps/diagnostic_work-0f62478eacf191cd: /home/js/Git/miopunch/tests/diagnostic_work.rs

/home/js/Git/miopunch/tests/diagnostic_work.rs:

/home/js/Git/miopunch/target/debug/deps/is_terminal_polyfill-760898be35064943.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/is_terminal_polyfill-1.70.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libis_terminal_polyfill-760898be35064943.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/is_terminal_polyfill-1.70.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libis_terminal_polyfill-760898be35064943.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/is_terminal_polyfill-1.70.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/is_terminal_polyfill-1.70.2/src/lib.rs:

/home/js/Git/miopunch/target/debug/deps/netwatch-94d3e36573e47ff7.d: /home/js/Git/miopunch/vendor/netwatch/src/lib.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/ip.rs /home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/udp.rs

/home/js/Git/miopunch/target/debug/deps/libnetwatch-94d3e36573e47ff7.rlib: /home/js/Git/miopunch/vendor/netwatch/src/lib.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/ip.rs /home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/udp.rs

/home/js/Git/miopunch/target/debug/deps/libnetwatch-94d3e36573e47ff7.rmeta: /home/js/Git/miopunch/vendor/netwatch/src/lib.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/ip.rs /home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/udp.rs

/home/js/Git/miopunch/vendor/netwatch/src/lib.rs:
/home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs:
/home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs:
/home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs:
/home/js/Git/miopunch/vendor/netwatch/src/ip.rs:
/home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs:
/home/js/Git/miopunch/vendor/netwatch/src/netmon.rs:
/home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs:
/home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs:
/home/js/Git/miopunch/vendor/netwatch/src/udp.rs:

import hashlib,json,subprocess
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m104-20261019')
O=R/'docs/evidence/packet-witness-opt-in-2026-10-19'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
protected=json.loads((H/'protected-wip.json').read_text())
expected={r['path']:r['status'] for r in protected}
owned={str(p.relative_to(R)):sha(p) for p in O.iterdir() if p.is_file()}
def git(*args):return subprocess.check_output(['rtk','proxy','git',*args],cwd=R).decode()
def state():
    raw=subprocess.check_output(['rtk','proxy','git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R)
    return {line[3:].decode():line[:2].decode() for line in raw.split(b'\0') if line}
def guard():
    assert all(sha(R/r['path'])==r['sha256'] for r in protected)
    assert {p:s for p,s in state().items() if p not in owned}==expected
    assert all(sha(R/p)==d for p,d in owned.items())
guard();assert git('rev-parse','HEAD').strip()==(H/'source-commit.txt').read_text().strip()
assert not git('diff','--cached','--name-only').strip()
subprocess.run(['rtk','proxy','git','add','--',*owned],cwd=R,check=True)
assert set(git('diff','--cached','--name-only').splitlines())==set(owned)
subprocess.run(['rtk','proxy','git','diff','--cached','--check'],cwd=R,check=True)
guard()
subprocess.run(['rtk','proxy','git','commit','-m','MIOPUNCH-104: record explicit packet witness evidence'],cwd=R,check=True)
commit=git('rev-parse','HEAD').strip();guard()
assert state()==expected and not git('diff','--cached','--name-only').strip()
(H/'evidence-commit.txt').write_text(commit+'\n')
(H/'evidence-commit-receipt.json').write_text(json.dumps({'commit':commit,'files':owned,'protectedWipCount':len(protected),'protectedHashesAndDirtySetUnchanged':True,'indexEmpty':True},indent=2)+'\n')
print(json.dumps({'commit':commit,'evidenceFiles':len(owned),'protectedWip':len(protected)}))

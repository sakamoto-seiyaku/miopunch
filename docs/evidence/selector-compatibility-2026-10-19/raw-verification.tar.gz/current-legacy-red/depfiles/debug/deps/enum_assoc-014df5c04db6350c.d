/home/js/Git/miopunch/target/debug/deps/enum_assoc-014df5c04db6350c.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/README.md

/home/js/Git/miopunch/target/debug/deps/libenum_assoc-014df5c04db6350c.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/README.md

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/README.md:

# env-dep:CARGO_MANIFEST_DIR=/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1

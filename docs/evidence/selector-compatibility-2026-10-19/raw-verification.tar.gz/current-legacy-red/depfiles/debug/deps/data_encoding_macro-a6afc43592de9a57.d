/home/js/Git/miopunch/target/debug/deps/data_encoding_macro-a6afc43592de9a57.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libdata_encoding_macro-a6afc43592de9a57.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libdata_encoding_macro-a6afc43592de9a57.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs:

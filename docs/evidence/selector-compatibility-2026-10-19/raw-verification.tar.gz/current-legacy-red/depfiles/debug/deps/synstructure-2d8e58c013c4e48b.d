/home/js/Git/miopunch/target/debug/deps/synstructure-2d8e58c013c4e48b.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs

/home/js/Git/miopunch/target/debug/deps/libsynstructure-2d8e58c013c4e48b.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs

/home/js/Git/miopunch/target/debug/deps/libsynstructure-2d8e58c013c4e48b.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs:

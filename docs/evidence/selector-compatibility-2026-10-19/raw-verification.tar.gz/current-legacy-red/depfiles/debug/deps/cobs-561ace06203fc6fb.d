/home/js/Git/miopunch/target/debug/deps/cobs-561ace06203fc6fb.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/dec.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/enc.rs

/home/js/Git/miopunch/target/debug/deps/libcobs-561ace06203fc6fb.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/dec.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/enc.rs

/home/js/Git/miopunch/target/debug/deps/libcobs-561ace06203fc6fb.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/dec.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/enc.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/dec.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/enc.rs:

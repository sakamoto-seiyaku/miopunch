/home/js/Git/miopunch/target/debug/deps/netwatch-ef7dfa757574d1d1.d: /home/js/Git/miopunch/vendor/netwatch/src/lib.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/ip.rs /home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/udp.rs

/home/js/Git/miopunch/target/debug/deps/libnetwatch-ef7dfa757574d1d1.rlib: /home/js/Git/miopunch/vendor/netwatch/src/lib.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/ip.rs /home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/udp.rs

/home/js/Git/miopunch/target/debug/deps/libnetwatch-ef7dfa757574d1d1.rmeta: /home/js/Git/miopunch/vendor/netwatch/src/lib.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/ip.rs /home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/udp.rs

/home/js/Git/miopunch/vendor/netwatch/src/lib.rs:
/home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs:
/home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs:
/home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs:
/home/js/Git/miopunch/vendor/netwatch/src/ip.rs:
/home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs:
/home/js/Git/miopunch/vendor/netwatch/src/netmon.rs:
/home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs:
/home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs:
/home/js/Git/miopunch/vendor/netwatch/src/udp.rs:

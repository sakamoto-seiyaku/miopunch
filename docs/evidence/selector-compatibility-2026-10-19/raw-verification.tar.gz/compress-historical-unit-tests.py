import gzip,hashlib,json,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m101-20261019');sys.path.insert(0,str(R/'scripts'));import cargo_cache as cache
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
review=H/'historical-unit-test-compression-review.json';rows=json.loads(review.read_text())['artifacts'];out=H/'historical-unit-test-artifacts';out.mkdir()
with cache.cache_lease(R/'target',min_free=0) as before:
 assert not cache.active_compilers(R)
 for d in Path('/proc').iterdir():
  if not d.name.isdigit():continue
  try:assert str((d/'exe').resolve(strict=True)) not in {r['originalPath'] for r in rows}
  except OSError:pass
 for row in rows:
  p=Path(row['originalPath']);assert sha(p)==row['originalSha256'] and sha(row['buildReceipt'])==row['buildReceiptSha256']
  dest=out/(p.parent.parent.name+'-'+row['originalSha256']+'.bin.gz');assert not dest.exists()
  with p.open('rb') as src,gzip.open(dest,'wb',compresslevel=1) as dst:
   while b:=src.read(1024*1024):dst.write(b)
  digest=hashlib.sha256()
  with gzip.open(dest,'rb') as f:
   while b:=f.read(1024*1024):digest.update(b)
  assert digest.hexdigest()==row['originalSha256']
  row.update(compressedPath=str(dest),compressedSha256=sha(dest),compressedBytes=dest.stat().st_size,roundTripSha256=digest.hexdigest());assert sha(p)==row['originalSha256'];p.unlink()
  (H/'historical-unit-test-compression-progress.json').write_text(json.dumps(rows,indent=2)+'\n')
 after=cache.disk_state(R/'target')
(H/'historical-unit-test-compression.json').write_text(json.dumps({'reviewSha256':sha(review),'before':before,'after':after,'artifacts':rows,'allRawSdkAndPublicBoundaryConsumersRetained':True,'allUnitTestBytesLosslesslyPreserved':True,'noCargoCacheChanged':True},indent=2)+'\n')
print(json.dumps({'tests':len(rows),'savedBytes':sum(r['originalBytes']-r['compressedBytes'] for r in rows),'after':after}))

import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/tmp/miopunch-rtc-s11-20261004')
TARGET = Path('/tmp/miopunch-rtc-s11-target-20261004')
OUTPUT = Path('/tmp/mio-rtc-s11-final-runtime-20261004')
OUTPUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT/'scripts'))
from check_browser_rtc import source_snapshot, sha256
from check_browser_rtc_cross_network import build, artifacts
receipt = {'fixedBase': '10831294a0ecb73c262412c717525f04923d9090', 'sourceBefore': source_snapshot(), 'commands': [], 'passed': False,
           'driverSha256': sha256(Path(__file__)),
           'scope': 'fresh normal-feature five-artifact set after test builds; final controlled conditions and default-empty-profile shared STEP9 nonempty/abort compatibility'}
try:
    build(TARGET, OUTPUT/'build')
    receipt['builtArtifactSet'] = artifacts(TARGET)
    commands = [
        ('controlled-cross-network', '/tmp/mio-rtc-s11-cross-network-final-20261004', ['--case','rtc-cross-network']),
        ('default-member-replica', '/tmp/mio-rtc-s11-default-member-replica-final-20261004', ['--case','rtc-member-replica']),
    ]
    for label, destination, options in commands:
        argv = ['rtk','proxy','python3','scripts/check_browser_paths.py',*options,'--output',destination,'--target-dir',str(TARGET),'--skip-build']
        started = time.monotonic()
        log = OUTPUT/(label+'.log')
        with log.open('w') as stream:
            result = subprocess.run(argv,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=480)
        child = json.loads((Path(destination)/'results.json').read_text())
        receipt['commands'].append({'name':label,'argv':argv,'exit':result.returncode,'seconds':time.monotonic()-started,'output':destination,
            'childPassed':child['passed'], 'logSha256':sha256(log), 'builtArtifactSetAfter':artifacts(TARGET)})
        (OUTPUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
        print(label,result.returncode,flush=True)
        if result.returncode or not child['passed'] or receipt['builtArtifactSet'] != artifacts(TARGET):
            raise RuntimeError(label+' failed/artifacts changed')
    receipt['passed'] = True
except BaseException as error:
    receipt['failure'] = str(error)
finally:
    receipt['sourceAfter'] = source_snapshot()
    receipt['sourceUnchanged'] = receipt['sourceBefore'] == receipt['sourceAfter']
    receipt['passed'] &= receipt['sourceUnchanged']
    (OUTPUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(0 if receipt['passed'] else 1)

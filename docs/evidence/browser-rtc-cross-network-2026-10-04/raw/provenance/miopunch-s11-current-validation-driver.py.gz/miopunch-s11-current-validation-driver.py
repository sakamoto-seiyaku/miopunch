import ast
import importlib.util
import json
from pathlib import Path
import subprocess
import time

ROOT = Path('/tmp/miopunch-rtc-s11-20261004')
TARGET = Path('/tmp/miopunch-rtc-s11-target-20261004')
OUTPUT = Path('/tmp/mio-rtc-s11-current-validation-20261004')
OUTPUT.mkdir(exist_ok=False)
import sys
sys.path.insert(0, str(ROOT/'scripts'))
from check_browser_rtc import source_snapshot, sha256
receipt = {'fixedBase': '10831294a0ecb73c262412c717525f04923d9090', 'sourceBefore': source_snapshot(), 'commands': [], 'passed': False,
           'scope': 'full affected current library/member/store/replica and public RTC/default/observer guards; no unchanged slow legacy NAT/fork matrix',
           'driverSha256': sha256(Path(__file__))}
base = ['cargo', 'test', '--locked', '--offline', '-j', '2', '--target-dir', str(TARGET), '--features', 'rtc-probe,replica-test-hooks']
commands = [('library', base+['--lib'])]
for label, targets in (
    ('full-member-store-replica', ['management_auth','management_store','native_network','offline_replica','daily_management']),
    ('rtc-current-guards', ['admission_gate','admission_proof','member_attempt','member_path_protocol','rtc_control_release','rtc_path_qualification','rtc_release_validation','rtc_invalidation','rtc_invalidation_barrier','rtc_association','rtc_ice_profile']),
    ('resources-and-admission', ['resources','public_resources','udp_observation','manual_admission','admission_completion','precode']),
):
    commands.append((label, base+sum((['--test', target] for target in targets), [])))
check = ['cargo','check','--locked','--offline','-j','2','--target-dir',str(TARGET)]
commands += [('native-all-targets',check+['--features','rtc-probe,replica-test-hooks','--all-targets']),
    ('wasm-rtc',check+['-p','miopunch-browser-probe','--features','rtc-probe','--target','wasm32-unknown-unknown']),
    ('wasm-default',check+['-p','miopunch-browser-probe','--target','wasm32-unknown-unknown']),
    ('native-default',check+['--lib']), ('format',['cargo','fmt','--all','--','--check']), ('diff-check',['git','diff','--check']),
    ('evidence-parser-redaction',['python3','scripts/test_rtc_cross_network_evidence.py']),
    ('stun-public-socket',['python3','scripts/test_stun_udp_observer.py'])]
paths = list(receipt['sourceBefore'])
commands += [('node-syntax-'+Path(path).stem,['node','--check',path]) for path in paths if path.endswith('.mjs') and path in [str(p.relative_to(ROOT)) for p in (ROOT/'browser-probe/harness').glob('*cross-network*')]]
commands += [('node-shared-replica',['node','--check','browser-probe/harness/run-rtc-member-replica.mjs']),
    ('python-syntax',['python3','-c','import ast;from pathlib import Path;[ast.parse(Path(p).read_text()) for p in '+repr([p for p in paths if p.endswith('.py')])+']'])]
try:
    for label, argv in commands:
        started = time.monotonic()
        log = OUTPUT/(label+'.log')
        with log.open('w') as stream:
            result = subprocess.run(['rtk','proxy',*argv],cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=300)
        text = log.read_text()
        receipt['commands'].append({'name':label,'argv':['rtk','proxy',*argv],'exit':result.returncode,'seconds':time.monotonic()-started,
            'testResults':[line for line in text.splitlines() if line.startswith('test result:')], 'logSha256':sha256(log)})
        (OUTPUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
        print(label,result.returncode,flush=True)
        if result.returncode:
            raise RuntimeError(label+' failed')
    receipt['passed'] = True
except BaseException as error:
    receipt['failure'] = str(error)
finally:
    receipt['sourceAfter'] = source_snapshot()
    receipt['sourceUnchanged'] = receipt['sourceBefore'] == receipt['sourceAfter']
    receipt['passed'] &= receipt['sourceUnchanged']
    (OUTPUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(0 if receipt['passed'] else 1)

# Independent STEP11 Standards review

## Findings (Standards axis only)

**P2 - Preserve removal capacity when commands time out.** In `scripts/rtc_cross_network_topology.py:57-59`, `subprocess.run(["rtk", "proxy", *argv], ..., timeout=...)` owns only the RTK process; it does not create/terminate a command process group. A timed-out proxy can leave its Docker child completing creation after cleanup starts. In addition, `remaining(cleanup=True)` at lines 43-46 rejects every command once 120s has elapsed, while `close():180-189` spends up to 9s on capture stops before removal. The reverse process stops in `check_browser_rtc_cross_network.py:206-214` can themselves consume/exceed the 15s reserve. Thus a late work timeout can skip `docker rm`/`docker network rm` entirely and leave owned resources; container sleep expiry does not remove containers or bridges. This breaches the explicit runner rule in `docs/notes/2026-10-03-browser-webrtc-replan.md:200`: "所有未来runner需外层进程组deadline与finally清理", and STEP11 line 184's owned-topology cleanup. Minimal fix: supervise each command group, reap it before cleanup, and allocate the finite cleanup reserve so essential container/network removal and absence checks precede optional graceful waits/capture finalization when time is short. This is a static failure-path finding, not a failure claimed from the successful normal run.

**P3 - Possible Duplicated Code (heuristic).** `check_browser_rtc_cross_network.py:205-217` and `:297-309` repeat `for process in reversed(processes)`, exit/error classification, `if not lab.close()`, and receipt extension. The two paths must receive identical lifecycle fixes. Extract one small owned-cleanup helper returning receipts and aggregate success. This is a maintainability judgment, not a documented coding-standard violation.

No additional documented-standard breaches or supported baseline smells found. Explicit immutable profiles, separate BUSINESS/REPLICA qualification, original identity/session checks, preserved disabled URL checks, controlled topology scope, and finite-transfer limitations match the current documented boundaries. Archived Go/OpenSpec gates were excluded; tooling-enforced style issues were excluded.

## Inputs and scope

- Actual configured model/effort: GPT-6.1 Sol / HIGH, independently assigned Standards axis. No Spec aggregation.
- Worktree: `/tmp/miopunch-rtc-s11-20261004`; branch `codex/webrtc-s11-20261004`.
- Fixed base and uncommitted HEAD: `10831294a0ecb73c262412c717525f04923d9090`; `git log BASE..HEAD` empty.
- Complete staged source diff read in full: `rtk proxy git diff --cached --binary 10831294a0ecb73c262412c717525f04923d9090`. Pinned patch `/tmp/miopunch-s11-initial-staged-source-diff.patch`: 153695 bytes, SHA256 `35cfafea034a4133b19de2f2ac354fd62a853cfce4e228ef902d70a564f6f8f8`. Live cached diff independently matched this size/hash.
- Authorities read: root AGENTS.md, /home/js/.codex/RTK.md, docs/agents/domain.md, README.md, CONTEXT.md, current mainline/scenario notes, ADR0004/0005/0006, and browser-webrtc-replan shared restrictions/STEP11. No separate coding-standard document; research is not itself a product decision.
- Full Fowler baseline considered as heuristics with repository overrides: Mysterious Name, Duplicated Code, Feature Envy, Data Clumps, Primitive Obsession, Repeated Switches, Shotgun Surgery, Divergent Change, Speculative Generality, Message Chains, Middle Man, Refused Bequest.

## Evidence limits

Read-only evidence: current native affected validation passed (17 actual checks, 206 passing native entries; inert helpers and two no-broker branches do not add coverage); separate owned-broker receipt passed its exact two previously unexercised tests; current controlled prepare/direct/blocked/relay receipt passed with frozen source/artifacts, real both-M data, six captures, rule/conntrack/STUN correlation and final cleanup; default member/replica compatibility passed including nonempty durable save/reopen and target IndexedDB interruption.

The freeze identifies 76 source inputs and five built artifacts. Normal runtime precedes only the exact three-line host SIGTERM guard; no normal protocol runtime was repeated after that guard. The current-source SIGTERM audit passed actual absence, with signal at 9.689s and cleanup in 2.935s. Its original verifier failure and actual RTK outer exit -15 remain preserved. That early cancellation validates its own observed path; it does not exercise exhausted cleanup reserve or timed-out Docker-command descendants. Historical header-only/lossy captures, parser failure, and immediate-cleanup race failures were not counted as current qualification.

No tests, builds, containers, protocol calls, index/source/config changes, Plane operations, or scheduler/model changes performed by this reviewer. Sole written artifact: this file.

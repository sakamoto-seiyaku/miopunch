import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/tmp/miopunch-rtc-s11-20261004')
OUTPUT = Path('/tmp/mio-rtc-s11-sigterm-cleanup-20261004')
OUTPUT.mkdir(exist_ok=False)
CASE = OUTPUT/'prerequisite'
sys.path.insert(0,str(ROOT/'scripts'))
from check_browser_rtc import source_snapshot, sha256
source = source_snapshot()
argv = ['rtk','proxy','python3','scripts/check_browser_rtc_cross_network.py','--prerequisites-only','--output',str(CASE),
        '--target-dir','/tmp/miopunch-rtc-s11-target-20261004','--skip-build']
started = time.monotonic()
with (OUTPUT/'runner.log').open('w') as log:
    child = subprocess.Popen(argv,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    sent = None
    owner = None
    while time.monotonic()-started < 45 and child.poll() is None:
        path = CASE/'topology-commands.json'
        if path.exists():
            commands = json.loads(path.read_text())
            if any(row['name'] == 'capture-router' and row.get('exit') == 0 for row in commands):
                owner = json.loads((CASE/'topology.json').read_text())['owner']
                sent = time.monotonic()
                os.kill(child.pid,signal.SIGTERM)
                break
        time.sleep(0.02)
    if sent is None:
        os.kill(child.pid,signal.SIGTERM)
    try:
        exit_code = child.wait(timeout=15)
    except subprocess.TimeoutExpired:
        os.killpg(child.pid,signal.SIGKILL)
        exit_code = child.wait(timeout=1)
        raise RuntimeError('owned signal cleanup exceeded remaining15s reserve')
actual = json.loads((CASE/'results.json').read_text())
absence = {}
for role, command in (('containers',['docker','ps','-a','--filter','label=miopunch.run='+owner,'--format','{{.ID}}']),
                      ('networks',['docker','network','ls','--filter','label=miopunch.run='+owner,'--format','{{.ID}}'])):
    result = subprocess.run(['rtk','proxy',*command],cwd=ROOT,text=True,capture_output=True,timeout=3)
    (OUTPUT/(role+'-absence.log')).write_text(result.stdout+result.stderr)
    absence[role] = {'exit':result.returncode,'empty':not result.stdout.strip()}
receipt = {'passed':exit_code == 1 and sent is not None and not actual['passed'] and actual.get('failure') == 'owned STEP11 runner cancelled'
           and actual['sourceUnchanged'] and all(row.get('passed',row.get('exit')==0) for row in actual['cleanup'])
           and all(value['exit']==0 and value['empty'] for value in absence.values()),
    'scope':'actual outer SIGTERM after five owned namespaces/four bridges/six capture starts; cancellation/cleanup only, no member/direct qualification',
    'argv':argv,'childPid':child.pid,'exit':exit_code,'signal':15,'sourceBefore':source,'sourceAfter':source_snapshot(),
    'signalAfterSeconds':sent-started if sent else None,'cleanupAfterSignalSeconds':time.monotonic()-sent if sent else None,
    'caseProtocolSeconds':actual['totalProtocolSeconds'],'remainingProtocolSecondsAtSignal':120-(sent-started) if sent else None,
    'cleanupReserveSeconds':15,'owner':owner,'actualAbsence':absence,'driverSha256':sha256(Path(__file__)),
    'caseReceiptSha256':sha256(CASE/'results.json')}
receipt['sourceUnchanged'] = receipt['sourceBefore'] == receipt['sourceAfter']
receipt['passed'] &= receipt['sourceUnchanged']
(OUTPUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS' if receipt['passed'] else 'FAIL',flush=True)
raise SystemExit(0 if receipt['passed'] else 1)

import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

ROOT = Path('/tmp/miopunch-rtc-s11-20261004')
OUTPUT = Path('/tmp/mio-rtc-s11-mqtt-focused-validation-20261004')
TARGET = Path('/tmp/miopunch-rtc-s11-target-20261004')
OUTPUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT/'scripts'))
from check_browser_rtc import source_snapshot, sha256
from rtc_cross_network_topology import IMAGE
owner = 'mio-rtc-s11-mqtt-focused-'+str(time.time_ns())
receipt = {'sourceBefore':source_snapshot(),'passed':False,'commands':[],'cleanup':[], 'driverSha256':sha256(Path(__file__)),
    'scope':'only the two public MQTT branches unexercised in the no-broker current-suite run; actual owned local broker, no silent skip'}

def command(label, argv, environment=None, timeout=90):
    start = time.monotonic()
    result = subprocess.run(['rtk','proxy',*argv],cwd=ROOT,env=environment,text=True,capture_output=True,timeout=timeout)
    log = OUTPUT/(label+'.log')
    log.write_text(result.stdout+result.stderr)
    receipt['commands'].append({'name':label,'argv':['rtk','proxy',*argv],'exit':result.returncode,'seconds':time.monotonic()-start,'logSha256':sha256(log)})
    if result.returncode:
        raise RuntimeError(label+' failed')
    return result.stdout+result.stderr

try:
    command('broker-start',['docker','run','--detach','--name',owner,'--label','miopunch.run='+owner,'--cap-drop','ALL',
        '--user',f'{os.getuid()}:{os.getgid()}','--publish','127.0.0.1::1883','--mount',f'type=bind,src={ROOT}/scripts/mosquitto-test.conf,target=/mosquitto-test.conf,readonly',
        '--entrypoint','mosquitto',IMAGE,'-c','/mosquitto-test.conf'],timeout=10)
    address = command('broker-port',['docker','port',owner,'1883/tcp'],timeout=5).strip()
    host, port = address.rsplit(':',1)
    deadline = time.monotonic()+5
    while True:
        try:
            with socket.create_connection((host,int(port)),timeout=0.3):
                break
        except OSError:
            if time.monotonic() >= deadline:
                raise
            time.sleep(0.05)
    environment = dict(os.environ, MIOPUNCH_MQTT_BROKER=address)
    receipt['ownedBroker'] = {'container':owner,'address':address,'image':IMAGE}
    for target, name in (
        ('public_resources','mqtt_bootstrap_can_release_only_the_original_connection_over_an_allowed_relay'),
        ('manual_admission','another_invitation_holder_observes_ciphertext_but_cannot_take_an_approved_result'),
    ):
        result = command(target,['cargo','test','--locked','--offline','-j','2','--target-dir',str(TARGET),
            '--features','rtc-probe,replica-test-hooks','--test',target,name,'--','--exact','--nocapture'],environment)
        if '1 passed' not in result or 'SKIPPED' in result:
            raise RuntimeError('exact actual MQTT test missing/skipped: '+target)
    receipt['passed'] = True
except BaseException as error:
    receipt['failure'] = str(error)
finally:
    for label, argv in (('broker-stop',['docker','rm','--force',owner]),('broker-absent',['docker','ps','-a','--filter','label=miopunch.run='+owner,'--format','{{.ID}}'])):
        try:
            text = command(label,argv,timeout=10)
            passed = label != 'broker-absent' or not text.strip()
            receipt['cleanup'].append({'name':label,'passed':passed})
            receipt['passed'] &= passed
        except BaseException as error:
            receipt['cleanup'].append({'name':label,'passed':False,'error':str(error)})
            receipt['passed'] = False
    receipt['sourceAfter'] = source_snapshot()
    receipt['sourceUnchanged'] = receipt['sourceBefore'] == receipt['sourceAfter']
    receipt['passed'] &= receipt['sourceUnchanged']
    (OUTPUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(0 if receipt['passed'] else 1)

import ctypes
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time

ROOT = Path('/tmp/miopunch-rtc-s11-20261004')
OUTPUT = Path('/tmp/mio-rtc-s11-cleanup-regression-20261004')
OUTPUT.mkdir(exist_ok=False)
TARGET = Path('/tmp/miopunch-rtc-s11-target-20261004')
sys.path.insert(0,str(ROOT/'scripts'))
from check_browser_rtc import source_snapshot, sha256
from check_browser_rtc_cross_network import trust, stop_processes
from rtc_cross_network_process import OwnedProcess
from rtc_cross_network_topology import OwnedLab

def interrupted(*_):
    raise KeyboardInterrupt('owned cleanup regression cancelled')
signal.signal(signal.SIGTERM,interrupted)
receipt = {'passed':False,'sourceBefore':source_snapshot(),'driverSha256':sha256(Path(__file__)),
    'scope':'only real owned teardown/group-timeout/control-stop regressions; no member/ICE/NAT-path/performance qualification',
    'injectionScope':'helper elapsed-clock offsets only, explicitly recorded; production120/105/15 and all product12/10/2 unchanged; no protocol actors launched'}
overall_started = time.monotonic()

def stat(pid):
    try:
        value = Path(f'/proc/{pid}/stat').read_text()
        fields = value[value.rindex(')')+2:].split()
        return {'pid':pid,'state':fields[0],'startTicks':int(fields[19])}
    except FileNotFoundError:
        return None

try:
    # Subreaper is this test process only; reap its own deliberately orphaned
    # timeout descendants instead of leaving zombies for the host init.
    assert ctypes.CDLL(None).prctl(36,1,0,0,0)==0
    group_output = OUTPUT/'process-group'
    group_output.mkdir()
    with tempfile.TemporaryDirectory(prefix='mio-rtc-s11-group-test-') as directory:
        lab = OwnedLab(group_output,Path(directory),TARGET,mode='prerequisites')
        identity = group_output/'identity.json'
        child_code = 'import signal,time,os;signal.signal(signal.SIGTERM,signal.SIG_IGN);print(os.getpid(),flush=True);time.sleep(30)'
        parent_code = "import subprocess,time,json,os,pathlib; child=subprocess.Popen(['python3','-c',"+repr(child_code)+"],stdout=subprocess.PIPE,text=True);pid=int(child.stdout.readline());pathlib.Path("+repr(str(identity))+").write_text(json.dumps({'parentPid':os.getpid(),'childPid':pid}));time.sleep(30)"
        started = time.monotonic()
        try:
            lab.command('owned-timeout-group',['python3','-c',parent_code],budget=0.7,capture=True)
            raise AssertionError('group timeout did not occur')
        except subprocess.TimeoutExpired:
            pass
        pids = json.loads(identity.read_text())
        reaped = {}
        for key,pid in pids.items():
            try:
                waited,status = os.waitpid(pid,os.WNOHANG)
                reaped[key] = {'pid':waited,'status':status}
            except ChildProcessError:
                reaped[key] = {'alreadyReapedByParent':True}
            assert stat(pid) is None, (key,stat(pid))
        receipt['processGroupTimeout'] = {'passed':True,'seconds':time.monotonic()-started,'ownedPids':pids,'reaped':reaped,
            'command':lab.commands[-1],'allKnownDescendantsAbsent':True}
    case_output = OUTPUT/'owned-expiry'
    case_output.mkdir()
    processes = []
    case = {'passed':False,'cleanup':[],'expectedCaseFailure':'deliberately injected already-expired helper clock; optional captures may be incomplete'}
    with tempfile.TemporaryDirectory(prefix='mio-rtc-s11-late-cleanup-') as directory:
        fixture = Path(directory)
        lab = OwnedLab(case_output,fixture,TARGET,mode='prerequisites')
        actual_case_started = lab.started
        try:
            trust(fixture)
            lab.start()
            # Genuine browser process/Playwright context, stopped while its
            # whitelisted native-start RPC is pending; no member actor exists.
            browser = OwnedProcess(lab,'browser',['/opt/node/bin/node','browser-probe/harness/run-rtc-cross-network.mjs'],
                'browser-driver',environment=[('LD_LIBRARY_PATH','/opt/hostlib')])
            processes.append(browser)
            browser.send(json.dumps({'configure':{'mode':'blocked','browser':{'relays':[],'disabled':[],'mqtt':[],'irc':[],'contact_routes':[]},
                'relay':'https://mio-relay.test:8443/','sourceRecord':None,'workMs':20000}}))
            call = browser.wait('rpc',budget=8)
            assert call['method']=='native-start'
            before_stop = time.monotonic()
            browser.send('stop')
            completion = browser.wait('browser-complete',budget=3)
            result = browser.stop()
            story = json.loads((case_output/'rtc-cross-network.json').read_text())
            assert not completion['passed'] and not story['passed'] and 'owned browser cancelled by SIGTERM' in story['failure'] and result['exit']==1
            receipt['controlledBrowserStop'] = {'passed':True,'seconds':time.monotonic()-before_stop,'actualProcessExit':result['exit'],
                'browserCompletion':completion,'failure':story['failure'],'scope':'real context stop/finally, before native/M exists'}
            slow_code = 'import json,os,time;print(json.dumps({"event":"slow-ready","pid":os.getpid()}),flush=True);input();time.sleep(30)'
            for role in ('browser','native'):
                process = OwnedProcess(lab,role,['python3','-c',slow_code],'slow-'+role)
                processes.append(process)
                process.wait('slow-ready')
            real_age = time.monotonic()-actual_case_started
            lab.started = time.monotonic()-105
            receipt['lateGracefulClockInjection'] = {'helperElapsedSeconds':105,'realWallSecondsAtInjection':real_age,
                'offsetSeconds':105-real_age,'outerTotalSeconds':lab.total,'workSeconds':105,'cleanupReserveSeconds':15}
            try:
                lab.remaining()
                raise AssertionError('work deadline was not enforced')
            except TimeoutError:
                pass
            before_stop = time.monotonic()
            stop_processes(processes,lab,case)
            receipt['slowStops'] = {'seconds':time.monotonic()-before_stop,'results':case['cleanup'],
                'failedCaseRetained':not case['passed'],'remainingTotalSeconds':lab.total-(time.monotonic()-lab.started)}
            assert all(row['exit']!=0 for row in case['cleanup'] if row['name'].startswith('slow-'))
            # Inject an expired helper clock AFTER real slow stop, without
            # waiting120s or making a fake network success/deadline claim.
            real_age = time.monotonic()-actual_case_started
            lab.started = time.monotonic()-120.01
            receipt['expiredClockInjection'] = {'helperElapsedSeconds':120.01,'realWallSecondsAtInjection':real_age,
                'offsetSeconds':120.01-real_age,'expectedQualifiedCase':False}
        finally:
            stop_processes(processes,lab,case)
            close_start = time.monotonic()
            closed = lab.close()
            receipt['physicalCleanup'] = {'seconds':time.monotonic()-close_start,'closeReturned':closed,'results':lab.cleanup_results,
                'expectedIncompleteCaptureFailure':not closed,'realTotalWallSeconds':time.monotonic()-actual_case_started,
                'simulatedOuterElapsedSeconds':time.monotonic()-lab.started}
        terminal = [row for row in lab.cleanup_results if row['name'] in ('remove-containers','remove-networks','containers-absent','networks-absent')]
        assert len(terminal)==4 and all(row['passed'] for row in terminal), terminal
        launched = [row for row in lab.commands if row['name'] in ('remove-containers','remove-networks','containers-absent','networks-absent')]
        assert all(row['terminalCleanup'] and row['remainingTotalSecondsAtLaunch']<0 and row['exit']==0 for row in launched)
        receipt['terminalCleanupCommands'] = launched
        absence = {}
        for role,argv in (('containers',['docker','ps','-a','--filter','label=miopunch.run='+lab.owner,'--format','{{.ID}}']),
                          ('networks',['docker','network','ls','--filter','label=miopunch.run='+lab.owner,'--format','{{.ID}}'])):
            result = subprocess.run(['rtk','proxy',*argv],cwd=ROOT,text=True,capture_output=True,timeout=3)
            (OUTPUT/(role+'-independent-absence.log')).write_text(result.stdout+result.stderr)
            absence[role] = {'exit':result.returncode,'empty':not result.stdout.strip()}
        assert all(row['exit']==0 and row['empty'] for row in absence.values())
        receipt['independentAbsence'] = absence
        receipt['owner'] = lab.owner
    receipt['passed'] = True
except BaseException as error:
    receipt['failure'] = repr(error)
finally:
    receipt['sourceAfter'] = source_snapshot()
    receipt['sourceUnchanged'] = receipt['sourceBefore']==receipt['sourceAfter']
    receipt['passed'] &= receipt['sourceUnchanged']
    receipt['actualWallSeconds'] = time.monotonic()-overall_started
    (OUTPUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS' if receipt['passed'] else 'FAIL',flush=True)
raise SystemExit(0 if receipt['passed'] else 1)

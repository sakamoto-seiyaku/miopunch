import ast
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import time

ROOT = Path('/home/js/Git/miopunch')
TARGET = Path('/tmp/miopunch-rtc-union-target-20261004')
OUTPUT = Path('/tmp/mio-rtc-union-current-validation-green-20261004')
OUTPUT.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT/'scripts'))
from check_browser_rtc import source_snapshot, sha256
from rtc_cross_network_topology import IMAGE
owner = 'mio-rtc-union-validation-'+str(time.time_ns())
receipt = {'fixedBase':'a48dbe0af23cb03dadf53bc3778cea6dfee6fca0',
           'isolatedAcceptedCommit':'fc87779f0baad182a786d220464c629a3dfdd013',
           'sourceBefore':source_snapshot(),'commands':[],'cleanup':[],'passed':False,
           'driverSha256':sha256(Path(__file__)),
           'scope':'merged admission, resource/profile aliases, member/current-proof/store/replica and CLI mode compatibility; real owned MQTT; native and WASM rtc/default; no unchanged slow NAT/Noq/Go/IRC replay'}

def save():
    (OUTPUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')

def command(label, argv, environment=None, timeout=600):
    start=time.monotonic()
    log=OUTPUT/(label+'.log')
    with log.open('w') as stream:
        worker=subprocess.Popen(['rtk','proxy',*argv],cwd=ROOT,env=environment,
            stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        try:
            worker.wait(timeout=timeout)
        except BaseException:
            os.killpg(worker.pid,signal.SIGTERM)
            try: worker.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(worker.pid,signal.SIGKILL);worker.wait()
            raise
    text=log.read_text()
    receipt['commands'].append({'name':label,'argv':['rtk','proxy',*argv],
        'exit':worker.returncode,'seconds':round(time.monotonic()-start,3),
        'logSha256':sha256(log),'testResults':[line for line in text.splitlines() if line.startswith('test result:')]})
    save();print(label,worker.returncode,flush=True)
    if worker.returncode: raise RuntimeError(label+' failed')
    return text

try:
    command('broker-start',['docker','run','--detach','--name',owner,'--label','miopunch.run='+owner,
        '--cap-drop','ALL','--user',f'{os.getuid()}:{os.getgid()}','--publish','127.0.0.1::1883',
        '--mount',f'type=bind,src={ROOT}/scripts/mosquitto-test.conf,target=/mosquitto-test.conf,readonly',
        '--entrypoint','mosquitto',IMAGE,'-c','/mosquitto-test.conf'],timeout=15)
    address=command('broker-port',['docker','port',owner,'1883/tcp'],timeout=5).strip()
    host,port=address.rsplit(':',1);deadline=time.monotonic()+8
    while True:
        try:
            with socket.create_connection((host,int(port)),timeout=0.5): break
        except OSError:
            if time.monotonic()>=deadline:raise
            time.sleep(.05)
    environment=dict(os.environ,MIOPUNCH_MQTT_BROKER=address)
    receipt['ownedBroker']={'container':owner,'address':address,'image':IMAGE,'capabilitiesDropped':'ALL'}
    check=['cargo','check','--locked','--offline','-j','2','--target-dir',str(TARGET)]
    command('native-all-targets',check+['--workspace','--all-targets','--features','rtc-probe,replica-test-hooks'])
    command('native-default',check+['--lib'])
    base=['cargo','test','--locked','--offline','-j','2','--target-dir',str(TARGET),'--features','rtc-probe,replica-test-hooks']
    command('library',base+['--workspace','--lib'],environment)
    command('fixture-cli',base+['--bin','browser_wss_member_native'],environment)
    for label,targets in [
        ('admission-and-resources',['manual_admission','precode','admission_completion','admission_gate','admission_proof','resources','public_resources','udp_observation','rtc_ice_profile']),
        ('member-current-proof',['member_attempt','member_path_protocol','rtc_control_release','rtc_path_qualification','rtc_release_validation','rtc_invalidation','rtc_invalidation_barrier','rtc_association']),
        ('member-store-replica',['management_auth','management_store','native_network','offline_replica','daily_management']),
    ]:
        text=command(label,base+sum((['--test',target] for target in targets),[])+['--','--nocapture'],environment)
        if 'SKIPPED actual invitation-holder MQTT check' in text:raise RuntimeError('actual MQTT holder check skipped')
    for label,feature in [('wasm-rtc',['--features','rtc-probe']),('wasm-default',[])]:
        command(label,check+['-p','miopunch-browser-probe','--target','wasm32-unknown-unknown',*feature])
    command('format',['cargo','fmt','--all','--','--check'],timeout=30)
    command('diff-check',['git','diff','--check'],timeout=10)
    command('staged-diff-check',['git','diff','--cached','--check'],timeout=10)
    command('evidence-parser-redaction',['python3','scripts/test_rtc_cross_network_evidence.py'],timeout=15)
    command('stun-public-socket',['python3','scripts/test_stun_udp_observer.py'],timeout=15)
    for name in ['run-rtc','run-wss-admission-materials','run-rtc-member-replica','run-rtc-cross-network','owned-cross-network-services','cross-network-preflight','owned-mixed-mqtt-proxy']:
        command('node-syntax-'+name,['node','--check','browser-probe/harness/'+name+'.mjs'],timeout=10)
    paths=[p for p in receipt['sourceBefore'] if p.endswith('.py')]
    command('python-syntax',['python3','-c','import ast;from pathlib import Path;[ast.parse(Path(p).read_text()) for p in '+repr(paths)+']'],timeout=15)
    receipt['passed']=True
except BaseException as error:
    receipt['failure']=str(error)
finally:
    for label,argv in [('broker-remove',['docker','rm','--force',owner]),('broker-absent',['docker','ps','-a','--filter','label=miopunch.run='+owner,'--format','{{.ID}}'])]:
        try:
            text=command(label,argv,timeout=10)
            passed=label!='broker-absent' or not text.strip()
            receipt['cleanup'].append({'name':label,'passed':passed})
            receipt['passed'] &= passed
        except BaseException as error:
            receipt['cleanup'].append({'name':label,'passed':False,'error':str(error)})
            receipt['passed']=False
    receipt['sourceAfter']=source_snapshot()
    receipt['sourceUnchanged']=receipt['sourceBefore']==receipt['sourceAfter']
    receipt['passed'] &= receipt['sourceUnchanged']
    save()
print(json.dumps({'passed':receipt['passed'],'failure':receipt.get('failure'),'output':str(OUTPUT)}),flush=True)
raise SystemExit(0 if receipt['passed'] else 1)

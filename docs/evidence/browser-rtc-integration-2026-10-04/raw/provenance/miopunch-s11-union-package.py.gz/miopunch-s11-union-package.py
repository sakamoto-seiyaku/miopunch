import gzip
import hashlib
import json
from pathlib import Path
import re
import struct
import sys

ROOT=Path('/home/js/Git/miopunch')
TARGET=Path('/tmp/miopunch-rtc-union-target-20261004')
DEST=ROOT/'docs/evidence/browser-rtc-integration-2026-10-04'
DEST.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(ROOT/'scripts'))
from check_browser_rtc import source_snapshot,sha256
from check_browser_rtc_cross_network import artifacts

OMITTED=object()
private_fields=re.compile(r'sdp|ufrag|username|password|icepwd|fingerprint|certificate|exporter',re.I)
archives=[]

def scrub(value,key='',omitted=None):
    if omitted is None:omitted=[]
    if isinstance(value,str) and private_fields.search(key):
        omitted.append(key);return OMITTED
    if isinstance(value,dict):
        result={}
        for name,item in value.items():
            if name in ('invitation','code') and isinstance(item,str):
                omitted.append(name);continue
            public=scrub(item,name,omitted)
            if public is not OMITTED:result[name]=public
        return result
    if isinstance(value,list):return [scrub(item,'',omitted) for item in value]
    return value

def safe_pcap(raw):
    if len(raw)<24 or raw[:4]!=b'\xd4\xc3\xb2\xa1':raise ValueError('unexpected pcap format')
    output=bytearray(raw[:24]);position=24;changed=total=0
    while position<len(raw):
        seconds,micros,captured,original=struct.unpack('<IIII',raw[position:position+16]);position+=16
        frame=raw[position:position+captured];position+=captured
        if len(frame)!=captured or captured>256 or frame[12:14]!=b'\x08\x00':raise ValueError('unexpected bounded IPv4 frame')
        offset=14+(frame[14]&15)*4;protocol=frame[23]
        if protocol==17:
            end=offset+8
            if len(frame)>=end+20 and frame[end+4:end+8]==b'\x21\x12\xa4\x42':end+=20
        elif protocol==6:end=offset+(frame[offset+12]>>4)*4
        else:end=offset+8
        end=min(captured,end);changed+=end!=captured;total+=1
        output.extend(struct.pack('<IIII',seconds,micros,end,original));output.extend(frame[:end])
    return bytes(output),{'pcapRecords':total,'payloadTruncatedRecords':changed,
        'retained':'original Ethernet/IP/UDP/TCP/ICMP headers, timestamps, original wire lengths; STUN20B envelope only',
        'removed':'all other transport payload and STUN attributes; no ICE credentials, DTLS certificate or application payload'}

def transform(path,raw):
    if path.suffix=='.pcap':return safe_pcap(raw)
    omitted=[]
    if path.suffix=='.json':
        original=json.loads(raw);public=scrub(original,omitted=omitted)
        if public!=original:return (json.dumps(public,indent=2)+'\n').encode(),{'omittedPrivateFields':omitted}
        return raw,{}
    if path.suffix in ('.jsonl','.log'):
        output=[];changed=False
        for line in raw.decode().splitlines(True):
            prefix=line[:line.find('{')] if '{' in line else ''
            try:
                value=json.loads(line[len(prefix):]);public=scrub(value,omitted=omitted)
                if public!=value:output.append(prefix+json.dumps(public)+'\n');changed=True
                else:output.append(line)
            except (ValueError,TypeError):
                if re.search(r'a=ice-(?:ufrag|pwd):|a=fingerprint:|-----BEGIN .*PRIVATE KEY-----',line):
                    omitted.append('raw description/private key line');changed=True
                else:output.append(line)
        return ''.join(output).encode() if changed else raw,{'omittedPrivateFields':omitted} if omitted else {}
    return raw,{}

def archive(path,name,classification):
    original=path.read_bytes();public,change=transform(path,original)
    stored=DEST/'raw'/(name+'.gz');stored.parent.mkdir(parents=True,exist_ok=True)
    with stored.open('wb') as stream:
        with gzip.GzipFile(fileobj=stream,mode='wb',filename='',mtime=0) as compressed:compressed.write(public)
    archives.append({'name':name,'originalPath':str(path),'archive':str(stored.relative_to(DEST)),
        'classification':classification,'originalSha256':hashlib.sha256(original).hexdigest(),'originalBytes':len(original),
        'storedRawSha256':hashlib.sha256(public).hexdigest(),'storedRawBytes':len(public),
        'gzipSha256':sha256(stored),'gzipBytes':stored.stat().st_size,'byteExact':public==original,'transformation':change})

for tag,location,classification in [
    ('material','/tmp/mio-rtc-union-material-final-20261004','actual merged empty first-A and material boundary qualification'),
    ('default9','/tmp/mio-rtc-union-member-replica-final-20261004','actual merged default-profile nonempty replica and genuine IDB abort'),
    ('controlled11','/tmp/mio-rtc-union-cross-network-final-20261004','actual merged closedseed controlled direct/peerUDPdrop/relay'),
    ('current-checks','/tmp/mio-rtc-union-current-validation-green-20261004','actual passing merged affected checks and real owned MQTT'),
    ('first-check-failure','/tmp/mio-rtc-union-current-validation-20261004','original native String/&str integration type error; no runtime PASS; own broker removed'),
    ('common-pipeline','/tmp/mio-rtc-union-final-runtime-20261004','fresh normal feature build and same-five three-case current-source pipeline'),
]:
    directory=Path(location)
    for path in sorted(directory.rglob('*')):
        if path.is_file() and path.suffix in ('.json','.jsonl','.log','.pcap'):
            archive(path,tag+'/'+str(path.relative_to(directory)),classification)
for name in ['miopunch-s11-union-validation-first.py','miopunch-s11-union-validation.py','miopunch-s11-union-final-runtime.py','miopunch-s11-union-package.py']:
    archive(Path('/tmp')/name,'provenance/'+name,'exact owned integration driver; no live private fixture files')

common=json.load(open('/tmp/mio-rtc-union-final-runtime-20261004/results.json'))
checks=json.load(open('/tmp/mio-rtc-union-current-validation-green-20261004/results.json'))
material=json.load(open('/tmp/mio-rtc-union-material-final-20261004/results.json'))
replica=json.load(open('/tmp/mio-rtc-union-member-replica-final-20261004/results.json'))
cross=json.load(open('/tmp/mio-rtc-union-cross-network-final-20261004/results.json'))
first=json.load(open('/tmp/mio-rtc-union-current-validation-20261004/results.json'))
current=source_snapshot();built=artifacts(TARGET)
assert all(value['passed'] for value in [common,checks,material,replica,cross])
assert all(value['sourceBefore']==value['sourceAfter']==current for value in [common,checks,material,replica,cross])
assert built==common['builtArtifactSet']==material['builtArtifacts']==replica['builtArtifacts']==cross['builtArtifactSet']
assert cross['immutableSeedUnchanged'] and cross['allConditionsQualified']
assert all(c['exit']==0 for c in checks['commands']) and all(c['passed'] for c in checks['cleanup'])
old10=json.load(open(ROOT/'docs/evidence/browser-wss-admission-materials-2026-10-04/receipt.json'))['runtimeSources']
old11=json.load(open('/tmp/miopunch-s11-postcommit-proof-20261004.json'))['currentSource']
assert set(current)==set(old10)|set(old11) and len(current)==85
assert sha256(ROOT/'docs/evidence/browser-rtc-cross-network-2026-10-04/receipt.json')=='c0b524cebfafaf58cb3588c11c3f358387769676e90e2bd29cfe5f173116927d'
lines=[line for command in checks['commands'] for line in command['testResults']]
passing=sum(int(re.search(r'(\d+) passed',line)[1]) for line in lines)
ignored=sum(int(re.search(r'(\d+) ignored',line)[1]) for line in lines)
assert passing==307 and ignored==1
keys=list(built)
receipt={'case':'STEP10+STEP11 semantic integration and fresh merged 10/9/11 qualification',
    'fixedBase':'a48dbe0af23cb03dadf53bc3778cea6dfee6fca0','acceptedIsolatedStep11':'fc87779f0baad182a786d220464c629a3dfdd013',
    'formalAcceptanceOwner':'root; this evidence does not resolve Plane or mark the full goal complete',
    'currentSource':current,'sourceCount':len(current),'sourceUnion':'exact accepted10 68 plus isolated11 76 union85; no WIP discovery dependency',
    'allCurrentSourcesFrozen':True,'builtArtifactSet':built,'sameCompiledSetAllThreeCases':True,
    'artifactScope':'three compiled native executables plus generated SDK JS/WASM; Python/Node harnesses are source inputs',
    'executedSubsets':{'material':[p for p in keys if Path(p).name not in ('browser_network_native','browser-probe-native')],
        'default9':keys,'controlled11':{record['mode']:record['executedArtifactPaths'] for record in [cross['preparation'],*cross['cases']]}},
    'material':{'passed':True,'protocolSeconds':material['totalProtocolSeconds'],'mode':material['mode'],'cleanup':material['cleanup'],
        'facts':'real empty A, exact targeted approval, strict IDB commit and local Complete/sender SAVE separate, same-profile reopen/new independently proved RTC M; genuine abort/Pending rightful resume/BOLA/one-use original native DATA_DIR reopen/expired original Delivery/Complete survives failed new M'},
    'default9':{'passed':True,'protocolSeconds':replica['totalProtocolSeconds'],'cleanup':replica['cleanup'],
        'facts':'real PONG, independent nonempty original signed36B record save/reopen and targeted genuine target IDB abort/no Complete/no Receipt; default empty profile',
        'intentionalSetupProbe':'mdns before exit1/joinedfalse, owned multicast route then after probe0/true; not all setup commands0'},
    'controlled11':{'allConditionsQualified':cross['allConditionsQualified'],'qualifiedConditions':cross['qualifiedConditions'],
        'immutableClosedSeedUnchanged':cross['immutableSeedUnchanged'],
        'caseSeconds':{record['mode']:record['totalProtocolSeconds'] for record in [cross['preparation'],*cross['cases']]},
        'cleanup':{record['mode']:record['cleanup'] for record in [cross['preparation'],*cross['cases']]},
        'comparison':scrub(cross['comparison']),'comparisonLimits':cross['comparisonLimits'],
        'scope':'actual five controlled namespaces/four bridges/two permissive NATs/six captures and native/browser selected nonrelay tuple translation; real peerUDP DROP/no handle/no fallback; matched explicitly allowed relay. Each 120=105+15, protected9s removal tail; all5 setup NET_ADMIN/only NAT-router extra NET_RAW, UID1000 actors effective0'},
    'checks':{'passed':True,'commandCount':len(checks['commands']),'commands':checks['commands'],
        'nativePassingEntries':passing,'existingIgnored':ignored,
        'countLimits':'123 workspace library entries+2 new fixture CLI tests+182 relevant target entries; inert crash-worker helpers included, not extra independent business coverage; actual MQTT branches ran once in their full targets',
        'cleanup':checks['cleanup']},
    'firstFailure':{'originalPath':'/tmp/mio-rtc-union-current-validation-20261004/results.json','originalSha256':sha256(Path('/tmp/mio-rtc-union-current-validation-20261004/results.json')),
        'passed':first['passed'],'failure':first['failure'],'sourceUnchanged':first['sourceUnchanged'],'cleanup':first['cleanup'],
        'fix':'native CLI now borrows relay URL; .to_owned() preserves Resource.url owned String. This is integration compilation failure, not protocol/NAT failure.'},
    'archives':archives,'reviews':{'status':'pending independent fixed-base Standards and Spec reviews','requiredFindingsNotYetKnown':True},
    'safeEvidenceScope':'credential-valued string fields omitted only where present; ordinary nulls and numeric process exit code retained; pcap payload strips explicitly not byte-exact originals',
    'limits':['controlled Linux Chromium153 foreground, not physical WAN/cellular/NAT-class/success-rate benefit',
        'one finite paired36B transfer and five member RTTs, not sustained throughput; shared host CPU/RSS sampling excludes unsampled final ticks/kernel and double-counts shared RSS',
        'outer encrypted captures cannot identify STREAM; tuple/windows correlate separately observed SDK/QUIC proof and original record save',
        'no full unknown-history/rotation/migration/freeze/IWA/UI/default infrastructure/TURN adoption or stopped IRC qualification',
        'old isolated STEP11 and accepted STEP10 evidence remain historical, byte-identical and do not claim this merged run']}
(DEST/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'archives':len(archives),'transformed':sum(not row['byteExact'] for row in archives),
    'pcapRecords':sum(row['transformation'].get('pcapRecords',0) for row in archives),
    'receiptSha256':sha256(DEST/'receipt.json'),'sourceCount':len(current),'passingEntries':passing}))

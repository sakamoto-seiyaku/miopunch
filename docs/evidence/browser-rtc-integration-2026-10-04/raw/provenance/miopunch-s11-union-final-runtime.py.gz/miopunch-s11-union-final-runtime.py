import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path('/home/js/Git/miopunch')
TARGET=Path('/tmp/miopunch-rtc-union-target-20261004')
OUTPUT=Path('/tmp/mio-rtc-union-final-runtime-20261004')
OUTPUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'scripts'))
from check_browser_rtc import source_snapshot,sha256
from check_browser_rtc_cross_network import build,artifacts
receipt={'passed':False,'fixedBase':'a48dbe0af23cb03dadf53bc3778cea6dfee6fca0',
    'isolatedAcceptedCommit':'fc87779f0baad182a786d220464c629a3dfdd013',
    'sourceBefore':source_snapshot(),'commands':[],'driverSha256':sha256(Path(__file__)),
    'scope':'fresh normal compiled union after affected tests, one common actual five-artifact set for first WSS admission/critical material boundaries, default-profile independently nonempty replica/real abort, and closedseed controlled direct/peerUDP-drop/matched-relay-cost'}

def save():
    (OUTPUT/'results.json').write_text(json.dumps(receipt,indent=2)+'\n')

try:
    build(TARGET,OUTPUT/'build')
    receipt['builtArtifactSet']=artifacts(TARGET)
    save()
    for label,destination,budget in [
        ('wss-admission-materials','/tmp/mio-rtc-union-material-final-20261004',160),
        ('rtc-member-replica','/tmp/mio-rtc-union-member-replica-final-20261004',160),
        ('rtc-cross-network','/tmp/mio-rtc-union-cross-network-final-20261004',510),
    ]:
        argv=['rtk','proxy','python3','scripts/check_browser_paths.py','--case',label,
            '--output',destination,'--target-dir',str(TARGET),'--skip-build']
        started=time.monotonic();log=OUTPUT/(label+'.log')
        with log.open('w') as stream:
            result=subprocess.run(argv,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,timeout=budget)
        child=json.loads((Path(destination)/'results.json').read_text())
        receipt['commands'].append({'case':label,'argv':argv,'exit':result.returncode,
            'seconds':round(time.monotonic()-started,3),'output':destination,
            'actualPassed':child['passed'],'sourceUnchanged':child['sourceUnchanged'],
            'childSourcesMatchUnion':child['sourceBefore']==receipt['sourceBefore'] and child['sourceAfter']==receipt['sourceBefore'],
            'builtArtifactSetAfter':artifacts(TARGET),'logSha256':sha256(log)})
        save();print(json.dumps(receipt['commands'][-1]),flush=True)
        entry=receipt['commands'][-1]
        if result.returncode or not child['passed'] or not entry['childSourcesMatchUnion'] or artifacts(TARGET)!=receipt['builtArtifactSet']:
            raise RuntimeError(label+' actual case/provenance failed')
    receipt['passed']=True
except BaseException as error:
    receipt['failure']=str(error)
finally:
    receipt['sourceAfter']=source_snapshot()
    receipt['sourceUnchanged']=receipt['sourceBefore']==receipt['sourceAfter']
    receipt['artifactsCurrent']=receipt.get('builtArtifactSet')==artifacts(TARGET)
    receipt['passed'] &= receipt['sourceUnchanged'] and receipt['artifactsCurrent']
    save()
print(json.dumps({'passed':receipt['passed'],'failure':receipt.get('failure'),'output':str(OUTPUT)}),flush=True)
raise SystemExit(0 if receipt['passed'] else 1)

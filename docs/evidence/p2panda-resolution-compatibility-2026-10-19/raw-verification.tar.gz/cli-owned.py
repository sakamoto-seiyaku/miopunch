import json,select,socket,subprocess,sys,tempfile,time
from pathlib import Path
exe=sys.argv[1];out=Path('/evidence');rows=[];live=[];report={'qualified':False,'forcedTermination':False,'cases':rows}
def run(args,timeout=12):
 r=subprocess.run([exe,*map(str,args)],capture_output=True,text=True,timeout=timeout)
 return r
with tempfile.TemporaryDirectory(prefix='m100-cli-') as private:
 root=Path(private)
 try:
  for case,bind,wrong in [('loopback','127.0.0.1',False),('wildcard','0.0.0.0',False),('wrong-identity-then-valid','127.0.0.1',True)]:
   began=time.monotonic();server_dir=root/case/'server'
   server=subprocess.Popen([exe,'serve','wrapped',str(server_dir),bind],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);live.append(server)
   assert select.select([server.stdout],[],[],12)[0],'server readiness timeout'
   line=server.stdout.readline();fields=line.strip().split();assert len(fields)==3 and fields[0]=='READY',line
   identity,address=fields[1:];port=int(address.rsplit(':',1)[1]);address='127.0.0.1:'+str(port)
   record={'case':case,'bind':bind,'ready':line.strip()}
   if wrong:
    other=run(['identity',root/case/'unrelated']);assert other.returncode==0;other_id=other.stdout.strip();assert other_id!=identity
    rejected=run(['send','wrapped',root/case/'rejected-client',other_id,address]);assert rejected.returncode!=0 and 'PONG' not in rejected.stdout
    record['wrongIdentity']={'exit':rejected.returncode,'stdout':rejected.stdout,'stderr':rejected.stderr}
   result=run(['send','wrapped',root/case/'client',identity,address]);assert result.returncode==0 and result.stdout=='PONG\n',(result.returncode,result.stdout,result.stderr)
   code=server.wait(timeout=8);stderr=server.stderr.read();assert code==0,stderr
   again=run(['identity',server_dir]);assert again.returncode==0 and again.stdout.strip()==identity
   with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as observer:observer.bind(('127.0.0.1',port))
   record.update(clientExit=result.returncode,clientStdout=result.stdout,clientStderr=result.stderr,serverExit=code,serverStderr=stderr,serverPortReleased=True,identityReopened=True,seconds=time.monotonic()-began);rows.append(record)
  report['qualified']=True
 finally:
  for p in live:
   if p.poll() is None:report['forcedTermination']=True;p.terminate();p.wait(timeout=3)
  report['everyServerExitedNaturally']=all(p.returncode==0 for p in live)
report['privateIdentityDirectoryRemoved']=not root.exists();report['qualified']=report['qualified'] and not report['forcedTermination'] and report['everyServerExitedNaturally'] and report['privateIdentityDirectoryRemoved']
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'qualified':report['qualified'],'cases':len(rows),'allServersNatural':report['everyServerExitedNaturally'],'privateIdentityDirectoryRemoved':report['privateIdentityDirectoryRemoved']}));assert report['qualified']

/home/js/Git/miopunch/target/debug/deps/want-c557133b89f8da43.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libwant-c557133b89f8da43.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libwant-c557133b89f8da43.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs:

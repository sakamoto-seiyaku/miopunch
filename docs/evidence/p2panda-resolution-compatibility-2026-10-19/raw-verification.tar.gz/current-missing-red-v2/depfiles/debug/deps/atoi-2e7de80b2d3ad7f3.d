/home/js/Git/miopunch/target/debug/deps/atoi-2e7de80b2d3ad7f3.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libatoi-2e7de80b2d3ad7f3.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libatoi-2e7de80b2d3ad7f3.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs:

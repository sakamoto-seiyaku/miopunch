/home/js/Git/miopunch/target/debug/deps/idna_adapter-72913c4c1748b0b7.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libidna_adapter-72913c4c1748b0b7.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libidna_adapter-72913c4c1748b0b7.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs:

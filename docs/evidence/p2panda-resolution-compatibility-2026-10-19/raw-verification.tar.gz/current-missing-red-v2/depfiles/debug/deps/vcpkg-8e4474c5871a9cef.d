/home/js/Git/miopunch/target/debug/deps/vcpkg-8e4474c5871a9cef.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/vcpkg-0.2.15/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libvcpkg-8e4474c5871a9cef.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/vcpkg-0.2.15/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libvcpkg-8e4474c5871a9cef.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/vcpkg-0.2.15/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/vcpkg-0.2.15/src/lib.rs:

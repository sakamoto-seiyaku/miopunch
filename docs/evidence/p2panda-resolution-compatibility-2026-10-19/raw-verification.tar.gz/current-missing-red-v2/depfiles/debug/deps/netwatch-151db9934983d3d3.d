/home/js/Git/miopunch/target/debug/deps/netwatch-151db9934983d3d3.d: /home/js/Git/miopunch/vendor/netwatch/src/lib.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/ip.rs /home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/udp.rs

/home/js/Git/miopunch/target/debug/deps/libnetwatch-151db9934983d3d3.rlib: /home/js/Git/miopunch/vendor/netwatch/src/lib.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/ip.rs /home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/udp.rs

/home/js/Git/miopunch/target/debug/deps/libnetwatch-151db9934983d3d3.rmeta: /home/js/Git/miopunch/vendor/netwatch/src/lib.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs /home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/ip.rs /home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs /home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs /home/js/Git/miopunch/vendor/netwatch/src/udp.rs

/home/js/Git/miopunch/vendor/netwatch/src/lib.rs:
/home/js/Git/miopunch/vendor/netwatch/src/interfaces.rs:
/home/js/Git/miopunch/vendor/netwatch/src/interfaces/netdev_impl.rs:
/home/js/Git/miopunch/vendor/netwatch/src/interfaces/linux.rs:
/home/js/Git/miopunch/vendor/netwatch/src/ip.rs:
/home/js/Git/miopunch/vendor/netwatch/src/ip_family.rs:
/home/js/Git/miopunch/vendor/netwatch/src/netmon.rs:
/home/js/Git/miopunch/vendor/netwatch/src/netmon/actor.rs:
/home/js/Git/miopunch/vendor/netwatch/src/netmon/linux.rs:
/home/js/Git/miopunch/vendor/netwatch/src/udp.rs:

/home/js/Git/miopunch/target/debug/deps/smallvec-f5a74e6392ed5976.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsmallvec-f5a74e6392ed5976.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsmallvec-f5a74e6392ed5976.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs:

/home/js/Git/miopunch/target/debug/deps/crc_catalog-a77c2ae421c76c0a.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/poly.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/algorithm.rs

/home/js/Git/miopunch/target/debug/deps/libcrc_catalog-a77c2ae421c76c0a.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/poly.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/algorithm.rs

/home/js/Git/miopunch/target/debug/deps/libcrc_catalog-a77c2ae421c76c0a.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/poly.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/algorithm.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/poly.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/crc-catalog-2.5.0/src/algorithm.rs:

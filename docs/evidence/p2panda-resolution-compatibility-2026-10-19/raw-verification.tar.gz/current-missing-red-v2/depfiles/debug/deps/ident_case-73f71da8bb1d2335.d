/home/js/Git/miopunch/target/debug/deps/ident_case-73f71da8bb1d2335.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ident_case-1.0.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libident_case-73f71da8bb1d2335.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ident_case-1.0.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libident_case-73f71da8bb1d2335.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ident_case-1.0.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/ident_case-1.0.1/src/lib.rs:

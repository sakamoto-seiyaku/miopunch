/home/js/Git/miopunch/target/debug/deps/data_encoding-94143112f77179cf.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-2.11.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libdata_encoding-94143112f77179cf.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-2.11.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libdata_encoding-94143112f77179cf.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-2.11.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-2.11.1/src/lib.rs:

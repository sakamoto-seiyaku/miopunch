/home/js/Git/miopunch/target/debug/deps/noq_udp-ee15fc76a017c25d.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/cmsg/mod.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/cmsg/unix.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/unix.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/linux.rs

/home/js/Git/miopunch/target/debug/deps/libnoq_udp-ee15fc76a017c25d.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/cmsg/mod.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/cmsg/unix.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/unix.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/linux.rs

/home/js/Git/miopunch/target/debug/deps/libnoq_udp-ee15fc76a017c25d.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/cmsg/mod.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/cmsg/unix.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/unix.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/linux.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/cmsg/mod.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/cmsg/unix.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/unix.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/noq-udp-1.3.0/src/linux.rs:

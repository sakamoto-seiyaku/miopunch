/home/js/Git/miopunch/target/debug/deps/synstructure-c7c4132244d3d4da.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs

/home/js/Git/miopunch/target/debug/deps/libsynstructure-c7c4132244d3d4da.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs

/home/js/Git/miopunch/target/debug/deps/libsynstructure-c7c4132244d3d4da.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs:

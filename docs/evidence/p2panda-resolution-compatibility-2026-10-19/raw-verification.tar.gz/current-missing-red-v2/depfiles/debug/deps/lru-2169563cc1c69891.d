/home/js/Git/miopunch/target/debug/deps/lru-2169563cc1c69891.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lru-0.18.5/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/liblru-2169563cc1c69891.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lru-0.18.5/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/liblru-2169563cc1c69891.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lru-0.18.5/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lru-0.18.5/src/lib.rs:

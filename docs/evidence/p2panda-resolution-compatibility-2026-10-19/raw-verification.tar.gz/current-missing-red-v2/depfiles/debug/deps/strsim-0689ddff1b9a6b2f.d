/home/js/Git/miopunch/target/debug/deps/strsim-0689ddff1b9a6b2f.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strsim-0.11.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libstrsim-0689ddff1b9a6b2f.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strsim-0.11.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libstrsim-0689ddff1b9a6b2f.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strsim-0.11.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strsim-0.11.1/src/lib.rs:

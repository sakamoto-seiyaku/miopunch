/home/js/Git/miopunch/target/debug/deps/proc_macro_crate-fb00b896c28115e5.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/proc-macro-crate-3.5.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libproc_macro_crate-fb00b896c28115e5.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/proc-macro-crate-3.5.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libproc_macro_crate-fb00b896c28115e5.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/proc-macro-crate-3.5.0/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/proc-macro-crate-3.5.0/src/lib.rs:

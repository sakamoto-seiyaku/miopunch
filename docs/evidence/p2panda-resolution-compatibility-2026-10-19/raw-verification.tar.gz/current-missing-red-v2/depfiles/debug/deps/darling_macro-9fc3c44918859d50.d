/home/js/Git/miopunch/target/debug/deps/darling_macro-9fc3c44918859d50.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling_macro-0.24.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libdarling_macro-9fc3c44918859d50.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling_macro-0.24.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling_macro-0.24.1/src/lib.rs:

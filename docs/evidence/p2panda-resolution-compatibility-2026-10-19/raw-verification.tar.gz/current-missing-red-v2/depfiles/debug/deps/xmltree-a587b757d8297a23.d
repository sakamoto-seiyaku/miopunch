/home/js/Git/miopunch/target/debug/deps/xmltree-a587b757d8297a23.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/xmltree-0.10.3/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libxmltree-a587b757d8297a23.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/xmltree-0.10.3/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libxmltree-a587b757d8297a23.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/xmltree-0.10.3/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/xmltree-0.10.3/src/lib.rs:

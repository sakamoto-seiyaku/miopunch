/home/js/Git/miopunch/target/debug/deps/enum_assoc-d9424c91bd6c45d6.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/README.md

/home/js/Git/miopunch/target/debug/deps/libenum_assoc-d9424c91bd6c45d6.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/README.md

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1/README.md:

# env-dep:CARGO_MANIFEST_DIR=/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/enum-assoc-1.4.1

/home/js/Git/miopunch/target/debug/deps/rustc_version-323077a5721690e9.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustc_version-0.4.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/librustc_version-323077a5721690e9.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustc_version-0.4.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/librustc_version-323077a5721690e9.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustc_version-0.4.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustc_version-0.4.1/src/lib.rs:

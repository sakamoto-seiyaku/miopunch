/home/js/Git/miopunch/target/debug/deps/stable_deref_trait-dfc35d43a069e674.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stable_deref_trait-1.2.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libstable_deref_trait-dfc35d43a069e674.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stable_deref_trait-1.2.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libstable_deref_trait-dfc35d43a069e674.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stable_deref_trait-1.2.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stable_deref_trait-1.2.1/src/lib.rs:

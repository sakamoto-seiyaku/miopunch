/home/js/Git/miopunch/target/debug/deps/httpdate-961af9c850a6b970.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/httpdate-1.0.3/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/httpdate-1.0.3/src/date.rs

/home/js/Git/miopunch/target/debug/deps/libhttpdate-961af9c850a6b970.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/httpdate-1.0.3/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/httpdate-1.0.3/src/date.rs

/home/js/Git/miopunch/target/debug/deps/libhttpdate-961af9c850a6b970.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/httpdate-1.0.3/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/httpdate-1.0.3/src/date.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/httpdate-1.0.3/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/httpdate-1.0.3/src/date.rs:

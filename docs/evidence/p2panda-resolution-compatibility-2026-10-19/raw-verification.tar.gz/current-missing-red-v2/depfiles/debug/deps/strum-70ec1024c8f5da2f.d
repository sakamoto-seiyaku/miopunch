/home/js/Git/miopunch/target/debug/deps/strum-70ec1024c8f5da2f.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs

/home/js/Git/miopunch/target/debug/deps/libstrum-70ec1024c8f5da2f.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs

/home/js/Git/miopunch/target/debug/deps/libstrum-70ec1024c8f5da2f.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs:

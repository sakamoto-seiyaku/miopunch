/home/js/Git/miopunch/target/debug/deps/futures-cb5d278003678a23.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-0.3.34/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libfutures-cb5d278003678a23.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-0.3.34/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libfutures-cb5d278003678a23.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-0.3.34/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-0.3.34/src/lib.rs:

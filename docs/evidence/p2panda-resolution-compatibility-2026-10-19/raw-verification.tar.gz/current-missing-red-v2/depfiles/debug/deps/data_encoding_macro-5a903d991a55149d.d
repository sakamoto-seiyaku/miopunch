/home/js/Git/miopunch/target/debug/deps/data_encoding_macro-5a903d991a55149d.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libdata_encoding_macro-5a903d991a55149d.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libdata_encoding_macro-5a903d991a55149d.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs:

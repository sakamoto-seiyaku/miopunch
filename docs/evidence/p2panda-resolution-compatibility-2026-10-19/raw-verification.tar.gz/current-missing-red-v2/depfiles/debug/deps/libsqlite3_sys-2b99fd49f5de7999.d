/home/js/Git/miopunch/target/debug/deps/libsqlite3_sys-2b99fd49f5de7999.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.30.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.30.1/src/error.rs /home/js/Git/miopunch/target/debug/build/libsqlite3-sys-fba17ba4b9971047/out/bindgen.rs

/home/js/Git/miopunch/target/debug/deps/liblibsqlite3_sys-2b99fd49f5de7999.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.30.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.30.1/src/error.rs /home/js/Git/miopunch/target/debug/build/libsqlite3-sys-fba17ba4b9971047/out/bindgen.rs

/home/js/Git/miopunch/target/debug/deps/liblibsqlite3_sys-2b99fd49f5de7999.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.30.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.30.1/src/error.rs /home/js/Git/miopunch/target/debug/build/libsqlite3-sys-fba17ba4b9971047/out/bindgen.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.30.1/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/libsqlite3-sys-0.30.1/src/error.rs:
/home/js/Git/miopunch/target/debug/build/libsqlite3-sys-fba17ba4b9971047/out/bindgen.rs:

# env-dep:OUT_DIR=/home/js/Git/miopunch/target/debug/build/libsqlite3-sys-fba17ba4b9971047/out

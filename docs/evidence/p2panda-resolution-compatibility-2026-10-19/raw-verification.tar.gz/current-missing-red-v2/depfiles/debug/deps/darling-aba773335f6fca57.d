/home/js/Git/miopunch/target/debug/deps/darling-aba773335f6fca57.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/macros_public.rs

/home/js/Git/miopunch/target/debug/deps/libdarling-aba773335f6fca57.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/macros_public.rs

/home/js/Git/miopunch/target/debug/deps/libdarling-aba773335f6fca57.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/macros_public.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/macros_public.rs:

/home/js/Git/miopunch/target/debug/deps/futures_sink-d9ef687921e9b956.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libfutures_sink-d9ef687921e9b956.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libfutures_sink-d9ef687921e9b956.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs:

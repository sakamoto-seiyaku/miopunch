/home/js/Git/miopunch/target/debug/deps/smallvec-0a5788f72b197b11.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsmallvec-0a5788f72b197b11.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libsmallvec-0a5788f72b197b11.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs:

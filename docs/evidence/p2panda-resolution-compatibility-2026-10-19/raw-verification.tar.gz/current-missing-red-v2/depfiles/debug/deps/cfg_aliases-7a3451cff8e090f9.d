/home/js/Git/miopunch/target/debug/deps/cfg_aliases-7a3451cff8e090f9.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg_aliases-0.2.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libcfg_aliases-7a3451cff8e090f9.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg_aliases-0.2.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libcfg_aliases-7a3451cff8e090f9.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg_aliases-0.2.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg_aliases-0.2.2/src/lib.rs:

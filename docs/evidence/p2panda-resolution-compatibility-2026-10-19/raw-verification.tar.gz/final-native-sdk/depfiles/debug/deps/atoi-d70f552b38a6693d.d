/home/js/Git/miopunch/target/debug/deps/atoi-d70f552b38a6693d.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libatoi-d70f552b38a6693d.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libatoi-d70f552b38a6693d.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs:

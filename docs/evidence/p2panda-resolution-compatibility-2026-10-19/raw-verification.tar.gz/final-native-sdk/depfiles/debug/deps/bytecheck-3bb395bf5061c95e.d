/home/js/Git/miopunch/target/debug/deps/bytecheck-3bb395bf5061c95e.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bytecheck-0.8.3/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bytecheck-0.8.3/src/../example.md

/home/js/Git/miopunch/target/debug/deps/libbytecheck-3bb395bf5061c95e.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bytecheck-0.8.3/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bytecheck-0.8.3/src/../example.md

/home/js/Git/miopunch/target/debug/deps/libbytecheck-3bb395bf5061c95e.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bytecheck-0.8.3/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bytecheck-0.8.3/src/../example.md

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bytecheck-0.8.3/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bytecheck-0.8.3/src/../example.md:

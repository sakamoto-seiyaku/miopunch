/home/js/Git/miopunch/target/debug/deps/event_listener_strategy-be8e1956d2c86002.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/event-listener-strategy-0.5.4/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libevent_listener_strategy-be8e1956d2c86002.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/event-listener-strategy-0.5.4/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libevent_listener_strategy-be8e1956d2c86002.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/event-listener-strategy-0.5.4/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/event-listener-strategy-0.5.4/src/lib.rs:

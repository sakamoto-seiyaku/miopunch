/home/js/Git/miopunch/target/debug/deps/cobs-90b19e57bfb2b099.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/dec.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/enc.rs

/home/js/Git/miopunch/target/debug/deps/libcobs-90b19e57bfb2b099.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/dec.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/enc.rs

/home/js/Git/miopunch/target/debug/deps/libcobs-90b19e57bfb2b099.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/dec.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/enc.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/dec.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cobs-0.3.0/src/enc.rs:

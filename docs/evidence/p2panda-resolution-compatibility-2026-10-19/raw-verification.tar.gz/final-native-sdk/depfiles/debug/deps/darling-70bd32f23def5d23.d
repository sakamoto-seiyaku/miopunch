/home/js/Git/miopunch/target/debug/deps/darling-70bd32f23def5d23.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/macros_public.rs

/home/js/Git/miopunch/target/debug/deps/libdarling-70bd32f23def5d23.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/macros_public.rs

/home/js/Git/miopunch/target/debug/deps/libdarling-70bd32f23def5d23.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/macros_public.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling-0.24.1/src/macros_public.rs:

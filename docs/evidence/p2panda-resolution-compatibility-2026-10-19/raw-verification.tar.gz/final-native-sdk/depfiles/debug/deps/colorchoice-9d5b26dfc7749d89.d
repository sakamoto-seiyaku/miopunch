/home/js/Git/miopunch/target/debug/deps/colorchoice-9d5b26dfc7749d89.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libcolorchoice-9d5b26dfc7749d89.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libcolorchoice-9d5b26dfc7749d89.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/colorchoice-1.0.5/src/lib.rs:

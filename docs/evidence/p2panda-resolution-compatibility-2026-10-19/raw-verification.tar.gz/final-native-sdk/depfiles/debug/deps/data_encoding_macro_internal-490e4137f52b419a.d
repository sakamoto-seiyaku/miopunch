/home/js/Git/miopunch/target/debug/deps/data_encoding_macro_internal-490e4137f52b419a.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-internal-0.1.19/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libdata_encoding_macro_internal-490e4137f52b419a.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-internal-0.1.19/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-internal-0.1.19/src/lib.rs:

/home/js/Git/miopunch/target/debug/deps/darling_macro-e0a521e1f619a767.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling_macro-0.24.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libdarling_macro-e0a521e1f619a767.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling_macro-0.24.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/darling_macro-0.24.1/src/lib.rs:

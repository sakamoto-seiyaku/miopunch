/home/js/Git/miopunch/target/debug/deps/clap-1e7917e0f39fb921.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/../examples/demo.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/../examples/demo.md

/home/js/Git/miopunch/target/debug/deps/libclap-1e7917e0f39fb921.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/../examples/demo.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/../examples/demo.md

/home/js/Git/miopunch/target/debug/deps/libclap-1e7917e0f39fb921.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/../examples/demo.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/../examples/demo.md

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/../examples/demo.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/clap-4.6.7/src/../examples/demo.md:

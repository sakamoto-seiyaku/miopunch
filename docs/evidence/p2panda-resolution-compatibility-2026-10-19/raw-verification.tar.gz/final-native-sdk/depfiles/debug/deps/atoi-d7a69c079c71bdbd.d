/home/js/Git/miopunch/target/debug/deps/atoi-d7a69c079c71bdbd.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libatoi-d7a69c079c71bdbd.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libatoi-d7a69c079c71bdbd.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atoi-2.0.0/src/lib.rs:

import gzip,hashlib,json,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m100-20261019');sys.path.insert(0,str(R/'scripts'));import cargo_cache as cache
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
names=['regression-red-v2','regression-count-red','regression-green-initial','focused-final-v1'];rows=[]
for name in names:
 receipt=H/name/'receipt.json';r=json.loads(receipt.read_text());assert r['exit']==0 and r['qualifiedForFrozenRun']
 for path,h in r['artifacts'].items():
  p=Path(path);assert p.name=='p2panda_resolution' and sha(p)==h
  rows.append({'originalPath':str(p),'originalSha256':h,'originalBytes':p.stat().st_size,'buildReceipt':str(receipt),'buildReceiptSha256':sha(receipt)})
(H/'intermediate-test-compression-review.json').write_text(json.dumps({'reason':'Lossless storage of four superseded M100 intermediate regression test executables only. Keep the original and red fixed public consumers, final focused test, every Native/Browser SDK, all receipts, sources and raw logs.','files':rows},indent=2)+'\n')
out=H/'historical-regression-artifacts';out.mkdir()
with cache.cache_lease(R/'target',min_free=0) as before:
 assert not cache.active_compilers(R)
 for row in rows:
  p=Path(row['originalPath']);assert sha(p)==row['originalSha256'];dest=out/(p.parent.parent.name+'-'+row['originalSha256']+'.bin.gz')
  with p.open('rb') as src,gzip.open(dest,'wb',compresslevel=1) as dst:
   while b:=src.read(1024*1024):dst.write(b)
  h=hashlib.sha256()
  with gzip.open(dest,'rb') as f:
   while b:=f.read(1024*1024):h.update(b)
  assert h.hexdigest()==row['originalSha256'];row.update(compressedPath=str(dest),compressedSha256=sha(dest),compressedBytes=dest.stat().st_size,roundTripSha256=h.hexdigest());p.unlink()
 after=cache.disk_state(R/'target')
(H/'intermediate-test-compression.json').write_text(json.dumps({'reviewSha256':sha(H/'intermediate-test-compression-review.json'),'before':before,'after':after,'artifacts':rows,'allSdkAndOriginalBoundaryArtifactsRetained':True,'noCargoCacheChanged':True},indent=2)+'\n');print(json.dumps({'compressed':len(rows),'savedBytes':sum(r['originalBytes']-r['compressedBytes'] for r in rows),'after':after}))

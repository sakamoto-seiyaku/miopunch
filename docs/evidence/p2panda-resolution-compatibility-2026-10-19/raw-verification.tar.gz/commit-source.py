import hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m100-20261019')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
U=Path('/tmp/mio81-final-peer-assertion-sdk-root-20261007/build-current-sdk.py');assert sha(U)=='2b7e969a1f90fc93eacc80d8b62890f0bb0ef8f40dc140d9398ef1a6029671e1'
spec=importlib.util.spec_from_file_location('sdk_commit_guard',U);sdk=importlib.util.module_from_spec(spec);sys.modules[spec.name]=sdk;spec.loader.exec_module(sdk)
own=json.loads((H/'implementation-owned-files.json').read_text())
protected=json.loads((H/'protected-wip.json').read_text());expected={r['path']:r['status'] for r in protected};assert not set(expected)&set(own)
def git(*args):return subprocess.check_output(['rtk','proxy','git',*args],cwd=R).decode()
def state():
 raw=subprocess.check_output(['rtk','proxy','git','status','--porcelain=v1','-z','--untracked-files=all'],cwd=R);return {line[3:].decode():line[:2].decode() for line in raw.split(b'\0') if line}
def guard():
 assert sdk.current_sources()==json.loads((H/'runtime-source-guard.json').read_text())['sources']
 assert all(sha(R/r['path'])==r['sha256'] for r in protected)
 actual=state();assert {p:s for p,s in actual.items() if p not in own}==expected
guard();base=git('rev-parse','HEAD').strip();assert base==(H/'source-baseline.txt').read_text().strip();assert not git('diff','--cached','--name-only').strip()
files={p:sha(R/p) for p in own};(H/'owned-source-files.json').write_text(json.dumps(files,indent=2)+'\n')
subprocess.run(['rtk','proxy','git','add','--',*own],cwd=R,check=True);assert set(git('diff','--cached','--name-only').splitlines())==set(own);subprocess.run(['rtk','proxy','git','diff','--cached','--check'],cwd=R,check=True);guard();assert all(sha(R/p)==d for p,d in files.items())
subprocess.run(['rtk','proxy','git','commit','-m','MIOPUNCH-100: preserve p2panda defaults with explicit resolving'],cwd=R,check=True)
commit=git('rev-parse','HEAD').strip();guard();assert state()==expected and not git('diff','--cached','--name-only').strip();assert all(sha(R/p)==d for p,d in files.items())
(H/'source-commit.txt').write_text(commit+'\n');(H/'source-commit-receipt.json').write_text(json.dumps({'base':base,'commit':commit,'files':files,'protectedWipCount':len(protected),'protectedWipHashesAndDirtySetUnchanged':True,'indexEmptyAfterCommit':True,'currentSdkSourceDigest':sdk.json_digest(sdk.current_sources())},indent=2)+'\n');print(json.dumps({'commit':commit,'ownedFiles':len(files),'protectedWipUnchanged':len(protected)}))

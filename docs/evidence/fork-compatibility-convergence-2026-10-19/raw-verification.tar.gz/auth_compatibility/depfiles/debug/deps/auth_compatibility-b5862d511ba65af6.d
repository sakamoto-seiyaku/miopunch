/home/js/Git/miopunch/target/debug/deps/auth_compatibility-b5862d511ba65af6.d: /home/js/Git/miopunch/tests/auth_compatibility.rs /home/js/Git/miopunch/tests/auth_consumers/original.rs

/home/js/Git/miopunch/target/debug/deps/auth_compatibility-b5862d511ba65af6: /home/js/Git/miopunch/tests/auth_compatibility.rs /home/js/Git/miopunch/tests/auth_consumers/original.rs

/home/js/Git/miopunch/tests/auth_compatibility.rs:
/home/js/Git/miopunch/tests/auth_consumers/original.rs:

import gzip,hashlib,json,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m102-20261019');sys.path.insert(0,str(R/'scripts'));import cargo_cache as cache
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
review=H/'obsolete-old-test-cache-compression-review.json';rows=json.loads(review.read_text())['plans']
for row in rows:
 p=Path(row['originalPath']);assert p.parent==R/'target/debug/deps' and sha(p)==row['originalSha256']
 assert sha(row['depfile'])==row['depfileSha256'] and row['actualTestSource'] in Path(row['depfile']).read_text()
 assert p.stat().st_ino==row['inode'] and p.stat().st_mtime_ns==row['mtimeNs'] and p.stat().st_nlink==1
 # Earlier evidence scan is retained in the M101 reviewed inventory; no
 # current text may acquire a direct reference while that review was deferred.
 for d in [R/'docs',R/'src',R/'scripts',R/'tests']:
  for f in d.rglob('*'):
   if not f.is_file() or f.suffix not in {'.md','.json','.py','.rs','.sh'}:continue
   b=f.read_bytes();assert p.name.encode() not in b and row['originalSha256'].encode() not in b, str(f)
with cache.cache_lease(R/'target',min_free=0) as before:
 assert not cache.active_compilers(R)
 for d in Path('/proc').iterdir():
  if not d.name.isdigit():continue
  try:assert str((d/'exe').resolve(strict=True)) not in {r['originalPath'] for r in rows}
  except OSError:pass
 for row in rows:
  p=Path(row['originalPath']);assert sha(p)==row['originalSha256'];row['originalMode']=p.stat().st_mode&0o777
  dest=H/(p.name+'.gz');assert not dest.exists()
  with p.open('rb') as src,gzip.open(dest,'wb',compresslevel=1) as dst:
   while b:=src.read(1024*1024):dst.write(b)
  with gzip.open(dest,'rb') as src:assert hashlib.file_digest(src,'sha256').hexdigest()==row['originalSha256']
  row.update(compressedPath=str(dest),compressedSha256=sha(dest),compressedBytes=dest.stat().st_size,roundTripVerified=True)
  assert sha(p)==row['originalSha256'];p.unlink()
 after=cache.disk_state(R/'target')
(H/'obsolete-old-test-cache-compression.json').write_text(json.dumps({'reviewSha256':sha(review),'before':before,'after':after,'artifacts':rows,'allSdkAndCurrentPublicArtifactsExempt':True},indent=2)+'\n')
print(json.dumps({'artifacts':len(rows),'before':before,'after':after}))

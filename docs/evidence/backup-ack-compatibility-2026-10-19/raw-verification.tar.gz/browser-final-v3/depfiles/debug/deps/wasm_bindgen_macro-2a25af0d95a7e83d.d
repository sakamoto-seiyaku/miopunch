/home/js/Git/miopunch/target/debug/deps/wasm_bindgen_macro-2a25af0d95a7e83d.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-macro-0.2.129/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libwasm_bindgen_macro-2a25af0d95a7e83d.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-macro-0.2.129/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-macro-0.2.129/src/lib.rs:

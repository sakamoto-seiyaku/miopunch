/home/js/Git/miopunch/target/debug/deps/synstructure-340d75ebdbdb51e2.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs

/home/js/Git/miopunch/target/debug/deps/libsynstructure-340d75ebdbdb51e2.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs

/home/js/Git/miopunch/target/debug/deps/libsynstructure-340d75ebdbdb51e2.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/synstructure-0.14.0/src/macros.rs:

/home/js/Git/miopunch/target/debug/deps/rustc_version-b3353ad100b0df6b.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustc_version-0.4.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/librustc_version-b3353ad100b0df6b.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustc_version-0.4.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/librustc_version-b3353ad100b0df6b.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustc_version-0.4.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustc_version-0.4.1/src/lib.rs:

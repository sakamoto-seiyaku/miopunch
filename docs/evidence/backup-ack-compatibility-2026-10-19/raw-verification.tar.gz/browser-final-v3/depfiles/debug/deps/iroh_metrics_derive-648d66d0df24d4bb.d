/home/js/Git/miopunch/target/debug/deps/iroh_metrics_derive-648d66d0df24d4bb.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-metrics-derive-1.0.1/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libiroh_metrics_derive-648d66d0df24d4bb.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-metrics-derive-1.0.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/iroh-metrics-derive-1.0.1/src/lib.rs:

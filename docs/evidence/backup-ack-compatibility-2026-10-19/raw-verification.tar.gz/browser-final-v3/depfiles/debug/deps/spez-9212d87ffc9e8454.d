/home/js/Git/miopunch/target/debug/deps/spez-9212d87ffc9e8454.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/parse.rs

/home/js/Git/miopunch/target/debug/deps/libspez-9212d87ffc9e8454.so: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/parse.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/spez-0.1.2/src/parse.rs:

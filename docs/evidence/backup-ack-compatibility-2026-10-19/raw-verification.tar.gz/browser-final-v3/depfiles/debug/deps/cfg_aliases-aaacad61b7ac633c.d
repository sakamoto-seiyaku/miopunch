/home/js/Git/miopunch/target/debug/deps/cfg_aliases-aaacad61b7ac633c.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg_aliases-0.2.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libcfg_aliases-aaacad61b7ac633c.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg_aliases-0.2.2/src/lib.rs

/home/js/Git/miopunch/target/debug/deps/libcfg_aliases-aaacad61b7ac633c.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg_aliases-0.2.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg_aliases-0.2.2/src/lib.rs:

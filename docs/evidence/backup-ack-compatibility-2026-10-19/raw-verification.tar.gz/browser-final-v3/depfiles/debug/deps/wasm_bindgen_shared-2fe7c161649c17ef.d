/home/js/Git/miopunch/target/debug/deps/wasm_bindgen_shared-2fe7c161649c17ef.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/identifier.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/tys.rs

/home/js/Git/miopunch/target/debug/deps/libwasm_bindgen_shared-2fe7c161649c17ef.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/identifier.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/tys.rs

/home/js/Git/miopunch/target/debug/deps/libwasm_bindgen_shared-2fe7c161649c17ef.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/identifier.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/tys.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/identifier.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-shared-0.2.129/src/tys.rs:

# env-dep:CARGO_PKG_VERSION=0.2.129
# env-dep:WBG_VERSION

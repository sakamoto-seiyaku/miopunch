/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/data_encoding_macro-d5662702eca9e1c1.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libdata_encoding_macro-d5662702eca9e1c1.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libdata_encoding_macro-d5662702eca9e1c1.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/data-encoding-macro-0.1.21/src/lib.rs:

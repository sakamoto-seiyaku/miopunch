/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/equivalent-08ad735b5f1949fd.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/equivalent-1.0.2/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libequivalent-08ad735b5f1949fd.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/equivalent-1.0.2/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libequivalent-08ad735b5f1949fd.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/equivalent-1.0.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/equivalent-1.0.2/src/lib.rs:

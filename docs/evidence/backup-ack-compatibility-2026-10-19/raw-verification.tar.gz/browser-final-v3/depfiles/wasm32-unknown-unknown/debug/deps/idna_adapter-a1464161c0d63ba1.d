/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/idna_adapter-a1464161c0d63ba1.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libidna_adapter-a1464161c0d63ba1.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libidna_adapter-a1464161c0d63ba1.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/idna_adapter-1.2.2/src/lib.rs:

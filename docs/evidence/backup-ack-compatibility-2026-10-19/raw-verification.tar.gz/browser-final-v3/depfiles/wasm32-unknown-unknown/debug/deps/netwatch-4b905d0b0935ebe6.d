/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/netwatch-4b905d0b0935ebe6.d: vendor/netwatch/src/lib.rs vendor/netwatch/src/interfaces.rs vendor/netwatch/src/interfaces/wasm_browser.rs vendor/netwatch/src/ip.rs vendor/netwatch/src/ip_family.rs vendor/netwatch/src/netmon.rs vendor/netwatch/src/netmon/actor.rs vendor/netwatch/src/netmon/wasm_browser.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libnetwatch-4b905d0b0935ebe6.rlib: vendor/netwatch/src/lib.rs vendor/netwatch/src/interfaces.rs vendor/netwatch/src/interfaces/wasm_browser.rs vendor/netwatch/src/ip.rs vendor/netwatch/src/ip_family.rs vendor/netwatch/src/netmon.rs vendor/netwatch/src/netmon/actor.rs vendor/netwatch/src/netmon/wasm_browser.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libnetwatch-4b905d0b0935ebe6.rmeta: vendor/netwatch/src/lib.rs vendor/netwatch/src/interfaces.rs vendor/netwatch/src/interfaces/wasm_browser.rs vendor/netwatch/src/ip.rs vendor/netwatch/src/ip_family.rs vendor/netwatch/src/netmon.rs vendor/netwatch/src/netmon/actor.rs vendor/netwatch/src/netmon/wasm_browser.rs

vendor/netwatch/src/lib.rs:
vendor/netwatch/src/interfaces.rs:
vendor/netwatch/src/interfaces/wasm_browser.rs:
vendor/netwatch/src/ip.rs:
vendor/netwatch/src/ip_family.rs:
vendor/netwatch/src/netmon.rs:
vendor/netwatch/src/netmon/actor.rs:
vendor/netwatch/src/netmon/wasm_browser.rs:

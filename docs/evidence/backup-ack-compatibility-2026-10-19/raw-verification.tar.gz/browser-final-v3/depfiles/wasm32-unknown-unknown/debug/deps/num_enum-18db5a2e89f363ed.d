/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/num_enum-18db5a2e89f363ed.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num_enum-0.7.6/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libnum_enum-18db5a2e89f363ed.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num_enum-0.7.6/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libnum_enum-18db5a2e89f363ed.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num_enum-0.7.6/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/num_enum-0.7.6/src/lib.rs:

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/send_wrapper-883ab71fbded2604.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/send_wrapper-0.6.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/send_wrapper-0.6.0/src/futures.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libsend_wrapper-883ab71fbded2604.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/send_wrapper-0.6.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/send_wrapper-0.6.0/src/futures.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libsend_wrapper-883ab71fbded2604.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/send_wrapper-0.6.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/send_wrapper-0.6.0/src/futures.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/send_wrapper-0.6.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/send_wrapper-0.6.0/src/futures.rs:

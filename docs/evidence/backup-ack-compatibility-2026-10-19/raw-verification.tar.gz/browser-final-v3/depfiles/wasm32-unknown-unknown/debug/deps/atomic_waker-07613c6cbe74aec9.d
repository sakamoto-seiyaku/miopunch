/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/atomic_waker-07613c6cbe74aec9.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atomic-waker-1.1.2/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libatomic_waker-07613c6cbe74aec9.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atomic-waker-1.1.2/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libatomic_waker-07613c6cbe74aec9.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atomic-waker-1.1.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atomic-waker-1.1.2/src/lib.rs:

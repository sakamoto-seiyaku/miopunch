/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/pin_project_lite-36b76668ee027fd6.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libpin_project_lite-36b76668ee027fd6.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libpin_project_lite-36b76668ee027fd6.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs:

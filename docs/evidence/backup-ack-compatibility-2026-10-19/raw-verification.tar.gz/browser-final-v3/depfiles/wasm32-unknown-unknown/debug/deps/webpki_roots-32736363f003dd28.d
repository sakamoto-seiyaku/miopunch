/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/webpki_roots-32736363f003dd28.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/webpki-roots-1.0.9/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libwebpki_roots-32736363f003dd28.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/webpki-roots-1.0.9/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libwebpki_roots-32736363f003dd28.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/webpki-roots-1.0.9/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/webpki-roots-1.0.9/src/lib.rs:

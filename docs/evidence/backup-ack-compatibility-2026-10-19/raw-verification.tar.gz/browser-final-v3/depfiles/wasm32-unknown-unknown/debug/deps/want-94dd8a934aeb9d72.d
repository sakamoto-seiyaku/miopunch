/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/want-94dd8a934aeb9d72.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libwant-94dd8a934aeb9d72.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libwant-94dd8a934aeb9d72.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs:

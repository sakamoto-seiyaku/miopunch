/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/unicode_properties-78c7426c4b2478c3.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/tables.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libunicode_properties-78c7426c4b2478c3.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/tables.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libunicode_properties-78c7426c4b2478c3.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/tables.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-properties-0.1.4/src/tables.rs:

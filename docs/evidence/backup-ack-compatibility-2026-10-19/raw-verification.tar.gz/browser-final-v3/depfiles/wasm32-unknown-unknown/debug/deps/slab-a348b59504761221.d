/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/slab-a348b59504761221.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/slab-0.4.12/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/slab-0.4.12/src/builder.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libslab-a348b59504761221.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/slab-0.4.12/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/slab-0.4.12/src/builder.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libslab-a348b59504761221.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/slab-0.4.12/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/slab-0.4.12/src/builder.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/slab-0.4.12/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/slab-0.4.12/src/builder.rs:

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/wasm_bindgen_futures-2628c072a73e604f.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-futures-0.4.79/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libwasm_bindgen_futures-2628c072a73e604f.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-futures-0.4.79/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libwasm_bindgen_futures-2628c072a73e604f.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-futures-0.4.79/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/wasm-bindgen-futures-0.4.79/src/lib.rs:

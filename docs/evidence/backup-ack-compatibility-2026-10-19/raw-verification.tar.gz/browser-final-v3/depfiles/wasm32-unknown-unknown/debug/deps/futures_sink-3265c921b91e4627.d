/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/futures_sink-3265c921b91e4627.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libfutures_sink-3265c921b91e4627.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libfutures_sink-3265c921b91e4627.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs:

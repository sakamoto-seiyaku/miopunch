/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/strum-707387be0f00286f.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libstrum-707387be0f00286f.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libstrum-707387be0f00286f.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/strum-0.28.0/src/additional_attributes.rs:

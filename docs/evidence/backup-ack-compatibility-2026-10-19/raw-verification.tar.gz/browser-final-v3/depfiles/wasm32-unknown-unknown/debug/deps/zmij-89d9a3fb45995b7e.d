/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/zmij-89d9a3fb45995b7e.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/traits.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libzmij-89d9a3fb45995b7e.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/traits.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libzmij-89d9a3fb45995b7e.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/traits.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/zmij-1.0.23/src/traits.rs:

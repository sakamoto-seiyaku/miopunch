/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/stringprep-c974ac861f6f5a6f.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/rfc3454.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/tables.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libstringprep-c974ac861f6f5a6f.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/rfc3454.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/tables.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libstringprep-c974ac861f6f5a6f.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/lib.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/rfc3454.rs /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/tables.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/lib.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/rfc3454.rs:
/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/stringprep-0.1.5/src/tables.rs:

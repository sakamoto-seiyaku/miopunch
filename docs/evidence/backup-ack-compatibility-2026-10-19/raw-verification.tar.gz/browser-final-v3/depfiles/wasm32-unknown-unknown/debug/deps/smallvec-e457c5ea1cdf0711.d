/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/smallvec-e457c5ea1cdf0711.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libsmallvec-e457c5ea1cdf0711.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libsmallvec-e457c5ea1cdf0711.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.16.2/src/lib.rs:

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/form_urlencoded-b57cc69f07ba7933.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/form_urlencoded-1.2.2/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libform_urlencoded-b57cc69f07ba7933.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/form_urlencoded-1.2.2/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libform_urlencoded-b57cc69f07ba7933.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/form_urlencoded-1.2.2/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/form_urlencoded-1.2.2/src/lib.rs:

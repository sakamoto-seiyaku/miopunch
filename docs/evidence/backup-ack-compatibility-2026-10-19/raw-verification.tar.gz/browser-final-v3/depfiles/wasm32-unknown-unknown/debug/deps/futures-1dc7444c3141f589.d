/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/futures-1dc7444c3141f589.d: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-0.3.34/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libfutures-1dc7444c3141f589.rlib: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-0.3.34/src/lib.rs

/home/js/Git/miopunch/target/wasm32-unknown-unknown/debug/deps/libfutures-1dc7444c3141f589.rmeta: /home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-0.3.34/src/lib.rs

/home/js/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-0.3.34/src/lib.rs:

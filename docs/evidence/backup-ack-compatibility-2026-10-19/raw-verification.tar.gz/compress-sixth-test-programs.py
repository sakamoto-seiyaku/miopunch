import gzip,hashlib,json,shutil,sys
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m102-20261019');sys.path.insert(0,str(R/'scripts'));import cargo_cache as cache
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
review=H/'historical-sixth-test-compression-review.json';data=json.loads(review.read_text());rows=data['artifacts'];exempt=set()
for context in H.glob('*-context.json'):
 d=json.loads(context.read_text())
 for group in ['artifactPins','fixedInputs','selectorPins']:exempt.update(d.get(group,{}))
for graph in ['native-final-v3','ordinary-final-v3','proto-final-v3']:
 exempt.update(json.loads((H/graph/'receipt.json').read_text())['artifacts'])
for row in rows:
 p=Path(row['originalPath']);receipt=Path(row['buildReceipt'])
 assert str(p) not in exempt and sha(p)==row['originalSha256'] and sha(receipt)==row['buildReceiptSha256']
 d=json.loads(receipt.read_text());assert d['artifacts'][str(p)]==row['originalSha256']
 records=[json.loads(line) for line in (receipt.parent/'cargo.jsonl').read_text().splitlines() if line.strip()]
 matches=[r for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('target',{}).get('name')==p.name and r.get('profile',{}).get('test') is True]
 assert matches,p
 assert matches[0]['target']['kind']==(['lib'] if row.get('isLibUnitTest') else ['test'])
 row['actualCargoTargetKind']=matches[0]['target']['kind'];row['actualCargoTargetSource']=matches[0]['target']['src_path']
review.write_text(json.dumps(data,indent=2)+'\n')
known=json.loads((H/'historical-intermediate-test-compression.json').read_text())['artifacts'];out=H/'historical-sixth-test-programs';out.mkdir()
with cache.cache_lease(R/'target',min_free=0) as before:
 assert not cache.active_compilers(R)
 for row in rows:
  p=Path(row['originalPath']);assert sha(p)==row['originalSha256']
  prior=next((r for r in known if r['originalSha256']==row['originalSha256']),None)
  if prior:
   dest=Path(prior['compressedPath']);assert sha(dest)==prior['compressedSha256'];row['reusedLosslessArchive']=True
  else:
   dest=out/(p.parents[2].name+'-'+p.parent.parent.name+'-'+p.name+'.gz');assert not dest.exists()
   with p.open('rb') as src,gzip.open(dest,'wb',compresslevel=1) as dst:shutil.copyfileobj(src,dst,1024*1024)
  with gzip.open(dest,'rb') as src:assert hashlib.file_digest(src,'sha256').hexdigest()==row['originalSha256']
  row.update(compressedPath=str(dest),compressedSha256=sha(dest),compressedBytes=dest.stat().st_size,roundTripVerified=True)
  assert sha(p)==row['originalSha256'];p.unlink()
  (H/'historical-sixth-test-compression-progress.json').write_text(json.dumps(rows,indent=2)+'\n')
 after=cache.disk_state(R/'target')
(H/'historical-sixth-test-compression.json').write_text(json.dumps({'reviewSha256':sha(review),'before':before,'after':after,'artifacts':rows,'allOriginalSdkAndPublicConsumerArtifactsRawRetained':True,'allTestProgramBytesLosslesslyPreserved':True,'allDeclaredCurrentBuildInputPinsExempt':True,'noDependencyLibrariesChanged':True},indent=2)+'\n')
print(json.dumps({'artifacts':len(rows),'before':before,'after':after}))

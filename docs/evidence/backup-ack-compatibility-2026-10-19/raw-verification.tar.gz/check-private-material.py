import hashlib,json,tarfile
from pathlib import Path
R=Path('/home/js/Git/miopunch');H=Path('/tmp/miopunch-m102-20261019');O=R/'docs/evidence/backup-ack-compatibility-2026-10-19'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
raw=H/'final-sdk-story-v3/runtime/private-runtime-receipt.json';r=json.loads(raw.read_text());values=set()
def collect(v):
 if isinstance(v,dict):
  for key,x in v.items():
   if isinstance(x,str) and len(x)>=24 and any(term in key.lower() for term in ['invitation','admission_secret','private_key','genesis_credential','precode']):values.add(x.encode())
   collect(x)
 elif isinstance(v,list):
  for x in v:collect(x)
collect(r);assert values
manifest=json.loads((O/'archive-manifest.json').read_text());assert manifest['allMembersReadBackAndVerified']
assert not any(any(n.startswith(case+'/runtime/') for case in ['final-sdk-story','final-sdk-story-v3']) or '/private-fixture/' in n or '/nssdb/' in n or n.endswith('.key') for n in manifest['members'])
hits=[]
for p in O.rglob('*'):
 if not p.is_file() or p.name=='private-material-checks.json' or p.suffix=='.gz':continue
 data=p.read_bytes()
 if any(value in data for value in values):hits.append(p.name)
with tarfile.open(O/'raw-verification.tar.gz') as tar:
 for member in tar:
  data=tar.extractfile(member).read()
  if any(value in data for value in values):hits.append('archive:'+member.name)
assert not hits,hits
report={'privateRuntimeReceiptExcluded':True,'privateFixtureKeysNssAndStoreLogsExcluded':True,'uniqueActualPrivateInvitationValuesScanned':len(values),'matches':len(hits),'allPublicFilesAndArchiveMembersScanned':True,'archiveSha256':sha(O/'raw-verification.tar.gz'),'privateReceiptSha256Only':sha(raw),'generatedKeysAndNssRemovedAfterQualifiedActorCleanup':json.loads((H/'final-sdk-story-v3/private-material-cleanup.json').read_text())['remainingPrivateKeys']==0}
(O/'private-material-checks.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

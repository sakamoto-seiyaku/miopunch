//! Resource policy through public nodes, real admission, relay actors and TLS.
use std::{collections::BTreeSet, net::Ipv4Addr, time::Duration};

use iroh::{Endpoint, EndpointAddr, endpoint::presets};
use iroh_relay::server::{RelayConfig as ServerRelayConfig, Server, ServerConfig};
use miopunch_native_probe::{
    admission_gate::{ADMISSION_REQUEST_ALPN, ProtocolScope},
    manual_admission::{AdmissionStage, ManualExchange},
    native_network::NativeNetwork,
    resources::{Resource, ResourceConfig, ResourceTable, ResourceUse},
};

const BUSINESS: &[u8] = b"miopunch/resources-business/1";

async fn relay() -> Server {
    let mut config = ServerConfig::default();
    config.relay = Some(ServerRelayConfig::new((Ipv4Addr::LOCALHOST, 0)));
    Server::spawn(config).await.unwrap()
}

fn resource(url: &iroh::RelayUrl) -> Resource {
    Resource {
        url: url.to_string(),
        uses: BTreeSet::from([ResourceUse::DataRelay]),
        limitation: "controlled loopback HTTP relay; actual endpoint TLS/QUIC, no public availability claim".into(),
    }
}

async fn bind(node: &NativeNetwork) -> Endpoint {
    let config = node.resource_configuration().unwrap();
    node.bind_endpoint_with(
        Endpoint::builder(presets::Minimal)
            .clear_ip_transports()
            .relay_mode(iroh::RelayMode::Custom(config.relay_map(ResourceUse::DataRelay).unwrap()))
            .alpns(vec![ADMISSION_REQUEST_ALPN.to_vec(), BUSINESS.to_vec()]),
    ).await.unwrap()
}

async fn connect(client: &Endpoint, server: &Endpoint, url: &iroh::RelayUrl, alpn: &[u8]) -> (iroh::endpoint::Connection, iroh::endpoint::Connection) {
    tokio::time::timeout(Duration::from_secs(15), async {
        let (out, incoming) = tokio::join!(
            client.connect(EndpointAddr::new(server.id()).with_relay_url(url.clone()), alpn),
            async { server.accept().await.unwrap().await },
        );
        (out.unwrap(), incoming.unwrap())
    }).await.expect("bounded real relay-only TLS connection")
}

async fn admission_and_business(self_hosted: bool) {
    let service = relay().await;
    let url = service.http_url().unwrap();
    let dir = tempfile::tempdir().unwrap();
    let mut admin = NativeNetwork::create(dir.path().join("admin")).await.unwrap();
    let mut joining = NativeNetwork::join(dir.path().join("joining"), admin.manual_invitation().unwrap()).await.unwrap();
    let mut config = ResourceConfig::with_defaults(ResourceTable { revision: 1, resources: vec![resource(&url)] });
    if self_hosted {
        config = ResourceConfig::default();
        config.replacement = Some(vec![resource(&url)]);
    }
    admin.save_resource_configuration(&config).unwrap();
    joining.save_resource_configuration(&config).unwrap();
    let admin_endpoint = bind(&admin).await;
    let join_endpoint = bind(&joining).await;
    let (client, server) = connect(&join_endpoint, &admin_endpoint, &url, ADMISSION_REQUEST_ALPN).await;
    let (result, served) = tokio::join!(joining.request_manual_admission(&client), admin.serve_manual_admission(&server));
    assert!(matches!(result.unwrap(), ManualExchange::AwaitingApproval));
    assert_eq!(served.unwrap(), AdmissionStage::AwaitingApproval);
    let request = admin.manual_requests().await.unwrap().pop().unwrap();
    admin.approve_manual_admission(&request).await.unwrap();
    let receive = async {
        let ManualExchange::Materials(materials) = joining.request_manual_admission(&client).await.unwrap() else { panic!("actual materials") };
        joining.complete_manual_admission(materials).await.unwrap()
    };
    let (saved, served) = tokio::join!(receive, admin.serve_manual_admission(&server));
    assert_eq!(saved, AdmissionStage::Complete);
    assert_eq!(served.unwrap(), AdmissionStage::Complete);
    client.close(0u32.into(), b"admitted");
    server.close(0u32.into(), b"admitted");
    join_endpoint.close().await;
    joining.close().await;
    let joining = NativeNetwork::open(dir.path().join("joining")).await.unwrap();
    assert_eq!(joining.admission_stage(), AdmissionStage::Complete);
    admin.admission_gate().register_protocol(BUSINESS, ProtocolScope::Member);
    joining.admission_gate().register_protocol(BUSINESS, ProtocolScope::Member);
    let join_endpoint = bind(&joining).await;
    let (client, server) = connect(&join_endpoint, &admin_endpoint, &url, BUSINESS).await;
    assert!(joining.admission_gate().allows(&client, ProtocolScope::Member));
    let (mut send, _) = client.open_bi().await.unwrap();
    send.write_all(b"resource-configured member communication").await.unwrap();
    send.finish().unwrap();
    let (_, mut receive) = server.accept_bi().await.unwrap();
    assert_eq!(receive.read_to_end(128).await.unwrap(), b"resource-configured member communication");
    eprintln!("MIO38_REAL configuration={} admission=Complete reopened=true data=received relay={} server_metrics={:?}", if self_hosted { "self-hosted" } else { "default-test" }, url, service.metrics());
    client.close(0u32.into(), b"done");
    server.close(0u32.into(), b"done");
    join_endpoint.close().await;
    admin_endpoint.close().await;
    joining.close().await;
    admin.close().await;
    service.shutdown().await.unwrap();
}

#[tokio::test]
async fn first_real_default_test_configuration_admits_and_communicates() {
    admission_and_business(false).await;
}

#[tokio::test]
async fn first_real_self_hosted_replacement_admits_and_communicates() {
    admission_and_business(true).await;
}

#[tokio::test]
async fn priority_disabled_relay_from_address_book_is_never_accessed() {
    use p2panda_core::SigningKey;
    use p2panda_net::addrs::{NodeInfo, TrustedTransportInfo};
    let service = relay().await;
    let url = service.http_url().unwrap();
    let target = SigningKey::generate().verifying_key();
    let mut config = ResourceConfig::with_defaults(ResourceTable {
        revision: 1,
        resources: vec![resource(&url)],
    });
    config.disabled.insert((url.to_string(), ResourceUse::DataRelay));
    let book = p2panda_net::AddressBook::builder().spawn().await.unwrap();
    let mut info = NodeInfo::new(target).bootstrap();
    info.update_transports(TrustedTransportInfo::from(EndpointAddr::new(
        iroh::EndpointId::from_bytes(target.as_bytes()).unwrap(),
    ).with_relay_url(url.clone())).into()).unwrap();
    book.insert_node_info(info).await.unwrap();
    let panda = p2panda_net::Endpoint::builder(book)
        .endpoint_builder_hook(move |builder| config.configure(builder).unwrap())
        .spawn().await.unwrap();
    let raw = panda.endpoint().await.unwrap();
    let attempted = tokio::time::timeout(Duration::from_secs(3), panda.connect(target, BUSINESS)).await;
    assert!(!matches!(attempted, Ok(Ok(_))));
    let connections = service.metrics().server.http_connections.get();
    let relay_bytes = service.metrics().server.bytes_recv.get();
    eprintln!("MIO38_DISABLED source=address-book http_connections={connections} relay_bytes={relay_bytes}");
    raw.close().await;
    drop(panda);
    service.shutdown().await.unwrap();
    assert_eq!(connections, 0, "the disabled relay must not even be dialed");
    assert_eq!(relay_bytes, 0, "no datagram may reach the disabled relay");
}

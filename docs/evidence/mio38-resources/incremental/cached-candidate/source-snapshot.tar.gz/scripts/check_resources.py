#!/usr/bin/env python3
"""Source-fixed resource verification; preserve every real command exit."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    sources = sorted({path.relative_to(ROOT).as_posix() for prefix in ["src", "tests", "browser-probe/src", "vendor/iroh/src", "vendor/p2panda-net/src", "vendor/p2panda-auth/src", "vendor/noq/src", "vendor/noq-proto/src", "vendor/netwatch/src"] for path in (ROOT / prefix).rglob("*.rs")})
    sources += ["Cargo.toml", "Cargo.lock", "browser-probe/Cargo.toml", "scripts/check_resources.py"]
    sources += [path.relative_to(ROOT).as_posix() for path in (ROOT / "vendor").glob("*/Cargo.toml")]
    hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources}
    (output / "prestart-source-sha256.json").write_text(json.dumps(hashes, indent=2) + "\n")
    with tarfile.open(output / "source-snapshot.tar.gz", "w:gz") as archive:
        for name in sources:
            archive.add(ROOT / name, arcname=name)
    command = args.command or ["cargo", "test", "--locked", "--test", "resources", "--", "--test-threads=1", "--nocapture"]
    if command[0] == "--":
        command = command[1:]
    receipt = {"started_utc": datetime.now(timezone.utc).isoformat(), "argv": ["rtk", "proxy", *command], "source_sha256": hashes}
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    with (output / "command.log").open("w") as log:
        result = subprocess.run(receipt["argv"], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    receipt.update(exit_code=result.returncode, finished_utc=datetime.now(timezone.utc).isoformat(), source_unchanged=all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == value for name, value in hashes.items()))
    # Freeze the executable from the actual Cargo run before any later compile.
    log_text = (output / "command.log").read_text()
    frozen = Path("/tmp/mio38-frozen-executables")
    frozen.mkdir(exist_ok=True)
    receipt["executables"] = []
    for name in re.findall(r"Running [^\n]+\(([^\n)]+)\)", log_text):
        executable = ROOT / name
        digest = hashlib.sha256(executable.read_bytes()).hexdigest()
        saved = frozen / (executable.name + "-" + digest)
        if not saved.exists():
            shutil.copy2(executable, saved)
        receipt["executables"].append({"actual_path": name, "frozen_path": str(saved), "sha256": digest, "frozen_after_actual_run": True})
    totals = [tuple(map(int, row)) for row in re.findall(r"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored", log_text)]
    receipt["test_totals"] = {label: sum(row[i] for row in totals) for i, label in enumerate(["passed", "failed", "ignored"])}
    (output / "command-exit.json").write_text(json.dumps(receipt, indent=2) + "\n")
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in ["exit_code", "source_unchanged"]}), flush=True)
    if not receipt["source_unchanged"] or (command[:2] == ["cargo", "test"] and not sum(row[0] + row[1] for row in totals)):
        return 2
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())

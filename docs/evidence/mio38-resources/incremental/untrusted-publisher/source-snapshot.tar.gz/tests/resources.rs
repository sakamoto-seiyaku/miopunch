//! Resource policy through public nodes, real admission, relay actors and TLS.
use std::{collections::BTreeSet, net::Ipv4Addr, time::Duration};

use iroh::{Endpoint, EndpointAddr, endpoint::presets};
use iroh_relay::server::{RelayConfig as ServerRelayConfig, Server, ServerConfig};
use miopunch_native_probe::{
    admission_gate::{ADMISSION_REQUEST_ALPN, ProtocolScope},
    manual_admission::{AdmissionStage, ManualExchange},
    native_network::NativeNetwork,
    resources::{Resource, ResourceConfig, ResourceTable, ResourceUse},
};

const BUSINESS: &[u8] = b"miopunch/resources-business/1";

async fn relay() -> Server {
    let mut config = ServerConfig::default();
    config.relay = Some(ServerRelayConfig::new((Ipv4Addr::LOCALHOST, 0)));
    Server::spawn(config).await.unwrap()
}

fn resource(url: &iroh::RelayUrl) -> Resource {
    Resource {
        url: url.to_string(),
        uses: BTreeSet::from([ResourceUse::DataRelay]),
        limitation: "controlled loopback HTTP relay; actual endpoint TLS/QUIC, no public availability claim".into(),
    }
}

async fn bind(node: &NativeNetwork) -> Endpoint {
    let config = node.resource_configuration().unwrap();
    node.bind_endpoint_with(
        Endpoint::builder(presets::Minimal)
            .clear_ip_transports()
            .relay_mode(iroh::RelayMode::Custom(config.relay_map(ResourceUse::DataRelay).unwrap()))
            .alpns(vec![ADMISSION_REQUEST_ALPN.to_vec(), BUSINESS.to_vec()]),
    ).await.unwrap()
}

async fn connect(client: &Endpoint, server: &Endpoint, url: &iroh::RelayUrl, alpn: &[u8]) -> (iroh::endpoint::Connection, iroh::endpoint::Connection) {
    tokio::time::timeout(Duration::from_secs(15), async {
        let (out, incoming) = tokio::join!(
            client.connect(EndpointAddr::new(server.id()).with_relay_url(url.clone()), alpn),
            async { server.accept().await.unwrap().await },
        );
        (out.unwrap(), incoming.unwrap())
    }).await.expect("bounded real relay-only TLS connection")
}

async fn admission_and_business(self_hosted: bool) {
    let service = relay().await;
    let url = service.http_url().unwrap();
    let dir = tempfile::tempdir().unwrap();
    let mut admin = NativeNetwork::create(dir.path().join("admin")).await.unwrap();
    let mut joining = NativeNetwork::join(dir.path().join("joining"), admin.manual_invitation().unwrap()).await.unwrap();
    let mut config = ResourceConfig::with_defaults(ResourceTable { revision: 1, resources: vec![resource(&url)] });
    if self_hosted {
        config = ResourceConfig::default();
        config.replacement = Some(vec![resource(&url)]);
    }
    admin.save_resource_configuration(&config).unwrap();
    joining.save_resource_configuration(&config).unwrap();
    let admin_endpoint = bind(&admin).await;
    let join_endpoint = bind(&joining).await;
    let (client, server) = connect(&join_endpoint, &admin_endpoint, &url, ADMISSION_REQUEST_ALPN).await;
    let (result, served) = tokio::join!(joining.request_manual_admission(&client), admin.serve_manual_admission(&server));
    assert!(matches!(result.unwrap(), ManualExchange::AwaitingApproval));
    assert_eq!(served.unwrap(), AdmissionStage::AwaitingApproval);
    let request = admin.manual_requests().await.unwrap().pop().unwrap();
    admin.approve_manual_admission(&request).await.unwrap();
    let receive = async {
        let ManualExchange::Materials(materials) = joining.request_manual_admission(&client).await.unwrap() else { panic!("actual materials") };
        joining.complete_manual_admission(materials).await.unwrap()
    };
    let (saved, served) = tokio::join!(receive, admin.serve_manual_admission(&server));
    assert_eq!(saved, AdmissionStage::Complete);
    assert_eq!(served.unwrap(), AdmissionStage::Complete);
    client.close(0u32.into(), b"admitted");
    server.close(0u32.into(), b"admitted");
    join_endpoint.close().await;
    joining.close().await;
    let joining = NativeNetwork::open(dir.path().join("joining")).await.unwrap();
    assert_eq!(joining.admission_stage(), AdmissionStage::Complete);
    admin.admission_gate().register_protocol(BUSINESS, ProtocolScope::Member);
    joining.admission_gate().register_protocol(BUSINESS, ProtocolScope::Member);
    let join_endpoint = bind(&joining).await;
    let (client, server) = connect(&join_endpoint, &admin_endpoint, &url, BUSINESS).await;
    assert!(joining.admission_gate().allows(&client, ProtocolScope::Member));
    let (mut send, _) = client.open_bi().await.unwrap();
    send.write_all(b"resource-configured member communication").await.unwrap();
    send.finish().unwrap();
    let (_, mut receive) = server.accept_bi().await.unwrap();
    assert_eq!(receive.read_to_end(128).await.unwrap(), b"resource-configured member communication");
    eprintln!("MIO38_REAL configuration={} admission=Complete reopened=true data=received relay={} server_metrics={:?}", if self_hosted { "self-hosted" } else { "default-test" }, url, service.metrics());
    client.close(0u32.into(), b"done");
    server.close(0u32.into(), b"done");
    join_endpoint.close().await;
    admin_endpoint.close().await;
    joining.close().await;
    admin.close().await;
    service.shutdown().await.unwrap();
}

#[tokio::test]
async fn first_real_default_test_configuration_admits_and_communicates() {
    admission_and_business(false).await;
}

#[tokio::test]
async fn first_real_self_hosted_replacement_admits_and_communicates() {
    admission_and_business(true).await;
}

#[tokio::test]
async fn priority_disabled_relay_from_address_book_is_never_accessed() {
    use p2panda_core::SigningKey;
    use p2panda_net::addrs::{NodeInfo, TrustedTransportInfo};
    let service = relay().await;
    let url = service.http_url().unwrap();
    let target = SigningKey::generate().verifying_key();
    let mut config = ResourceConfig::with_defaults(ResourceTable {
        revision: 1,
        resources: vec![resource(&url)],
    });
    config.disabled.insert((url.to_string(), ResourceUse::DataRelay));
    let book = p2panda_net::AddressBook::builder().spawn().await.unwrap();
    let mut info = NodeInfo::new(target).bootstrap();
    info.update_transports(TrustedTransportInfo::from(EndpointAddr::new(
        iroh::EndpointId::from_bytes(target.as_bytes()).unwrap(),
    ).with_relay_url(url.clone())).into()).unwrap();
    book.insert_node_info(info).await.unwrap();
    let panda = p2panda_net::Endpoint::builder(book)
        .endpoint_builder_hook(move |builder| config.configure(builder).unwrap())
        .spawn().await.unwrap();
    let raw = panda.endpoint().await.unwrap();
    let attempted = tokio::time::timeout(Duration::from_secs(3), panda.connect(target, BUSINESS)).await;
    assert!(!matches!(attempted, Ok(Ok(_))));
    let connections = service.metrics().server.http_connections.get();
    let relay_bytes = service.metrics().server.bytes_recv.get();
    eprintln!("MIO38_DISABLED source=address-book http_connections={connections} relay_bytes={relay_bytes}");
    raw.close().await;
    drop(panda);
    service.shutdown().await.unwrap();
    assert_eq!(connections, 0, "the disabled relay must not even be dialed");
    assert_eq!(relay_bytes, 0, "no datagram may reach the disabled relay");
}

#[tokio::test]
async fn disabled_relay_in_default_startup_table_is_never_accessed() {
    let service = relay().await;
    let url = service.http_url().unwrap();
    let dir = tempfile::tempdir().unwrap();
    let node = NativeNetwork::create(dir.path().join("node")).await.unwrap();
    let mut config = ResourceConfig::with_defaults(ResourceTable { revision: 1, resources: vec![resource(&url)] });
    config.disabled.insert((url.to_string(), ResourceUse::DataRelay));
    node.save_resource_configuration(&config).unwrap();
    // An independently supplied builder still contains the disabled URL. It
    // cannot turn that table into permission to probe or dial the resource.
    let endpoint = node.bind_endpoint_with(Endpoint::builder(presets::Minimal)
        .relay_mode(iroh::RelayMode::Custom(iroh::RelayConfig::from(url.clone()).into()))).await.unwrap();
    tokio::time::sleep(Duration::from_secs(2)).await;
    let connections = service.metrics().server.http_connections.get();
    eprintln!("MIO38_DISABLED source=default-table http_connections={connections}");
    endpoint.close().await;
    node.close().await;
    service.shutdown().await.unwrap();
    assert_eq!(connections, 0, "startup observation must obey its separate permission too");
}

#[tokio::test]
async fn disabled_relay_from_invitation_hint_is_never_accessed() {
    let service = relay().await;
    let url = service.http_url().unwrap();
    let dir = tempfile::tempdir().unwrap();
    let admin = NativeNetwork::create(dir.path().join("admin")).await.unwrap();
    let invitation = admin.manual_invitation().unwrap();
    let joining = NativeNetwork::join(dir.path().join("joining"), invitation).await.unwrap();
    let mut config = ResourceConfig::with_defaults(ResourceTable { revision: 1, resources: vec![resource(&url)] });
    config.disabled.insert((url.to_string(), ResourceUse::DataRelay));
    joining.save_resource_configuration(&config).unwrap();
    let endpoint = joining.bind_endpoint_with(Endpoint::builder(presets::Minimal)
        .relay_mode(iroh::RelayMode::Custom(iroh::RelayMap::empty()))).await.unwrap();
    let target = EndpointAddr::new(invitation.contact).with_relay_url(url);
    let attempted = tokio::time::timeout(Duration::from_secs(2), endpoint.connect(target, ADMISSION_REQUEST_ALPN)).await;
    assert!(!matches!(attempted, Ok(Ok(_))));
    let connections = service.metrics().server.http_connections.get();
    let bytes = service.metrics().server.bytes_recv.get();
    eprintln!("MIO38_DISABLED source=invitation-hint http_connections={connections} relay_bytes={bytes}");
    endpoint.close().await;
    joining.close().await;
    admin.close().await;
    service.shutdown().await.unwrap();
    assert_eq!((connections, bytes), (0, 0));
}

#[tokio::test]
async fn disabled_relay_from_lookup_result_is_never_accessed() {
    let service = relay().await;
    let url = service.http_url().unwrap();
    let target = iroh::SecretKey::generate().public();
    let mut config = ResourceConfig::with_defaults(ResourceTable { revision: 1, resources: vec![resource(&url)] });
    config.disabled.insert((url.to_string(), ResourceUse::DataRelay));
    let lookup = iroh::address_lookup::memory::MemoryLookup::from_endpoint_info([
        EndpointAddr::new(target).with_relay_url(url),
    ]);
    let endpoint = config.configure(Endpoint::builder(presets::Minimal)
        .relay_mode(iroh::RelayMode::Custom(iroh::RelayMap::empty())).address_lookup(lookup))
        .unwrap().bind().await.unwrap();
    let attempted = tokio::time::timeout(Duration::from_secs(2), endpoint.connect(target, BUSINESS)).await;
    assert!(!matches!(attempted, Ok(Ok(_))));
    let connections = service.metrics().server.http_connections.get();
    let bytes = service.metrics().server.bytes_recv.get();
    eprintln!("MIO38_DISABLED source=lookup-result http_connections={connections} relay_bytes={bytes}");
    endpoint.close().await;
    service.shutdown().await.unwrap();
    assert_eq!((connections, bytes), (0, 0));
}

#[tokio::test]
async fn disabled_relay_retained_in_cache_is_never_accessed() {
    use std::sync::{Arc, atomic::{AtomicU64, Ordering}};
    let service = relay().await;
    let url = service.http_url().unwrap();
    let target = iroh::SecretKey::generate().public();
    let mut config = ResourceConfig::with_defaults(ResourceTable { revision: 1, resources: vec![resource(&url)] });
    config.disabled.insert((url.to_string(), ResourceUse::DataRelay));
    let denied = Arc::new(AtomicU64::new(0));
    let observed = denied.clone();
    let policy = iroh::endpoint::RelayResourcePolicy::new(move |url, usage| {
        let usage = match usage {
            iroh::endpoint::RelayResourceUse::DataRelay => ResourceUse::DataRelay,
            iroh::endpoint::RelayResourceUse::Observation => ResourceUse::Observation,
        };
        let allowed = config.allows(url.as_str(), usage);
        if !allowed && usage == ResourceUse::DataRelay {
            observed.fetch_add(1, Ordering::Relaxed);
        }
        allowed
    });
    let endpoint = Endpoint::builder(presets::Minimal)
        .relay_mode(iroh::RelayMode::Custom(iroh::RelayMap::empty()))
        .relay_resource_policy(policy).bind().await.unwrap();
    let hinted = EndpointAddr::new(target).with_relay_url(url.clone());
    let _ = tokio::time::timeout(Duration::from_secs(1), endpoint.connect(hinted, BUSINESS)).await;
    let cached = endpoint.remote_info(target).await.unwrap();
    assert!(cached.addrs().any(|info| info.addr() == &iroh::TransportAddr::Relay(url.clone())));
    endpoint.address_lookup().unwrap().clear();
    assert!(endpoint.address_lookup().unwrap().is_empty());
    let before = denied.load(Ordering::Relaxed);
    assert!(before > 0);
    let attempted = tokio::time::timeout(Duration::from_secs(2), endpoint.connect(target, BUSINESS)).await;
    assert!(!matches!(attempted, Ok(Ok(_))));
    assert!(denied.load(Ordering::Relaxed) > before, "the identity-only retry must reach actual dispatch using the cached candidate");
    let connections = service.metrics().server.http_connections.get();
    let bytes = service.metrics().server.bytes_recv.get();
    eprintln!("MIO38_DISABLED source=cache cached=true lookup_services=0 dispatch_denials={} http_connections={connections} relay_bytes={bytes}", denied.load(Ordering::Relaxed));
    endpoint.close().await;
    service.shutdown().await.unwrap();
    assert_eq!((connections, bytes), (0, 0));
}

#[tokio::test]
async fn a_known_actor_route_cannot_replace_an_allowed_candidate_with_a_forbidden_relay() {
    use std::sync::{Arc, atomic::{AtomicBool, AtomicU64, Ordering}};
    let old_service = relay().await;
    let alternate_service = relay().await;
    let old = old_service.http_url().unwrap();
    let alternate = alternate_service.http_url().unwrap();
    let denied = Arc::new(AtomicBool::new(false));
    let denied_checks = Arc::new(AtomicU64::new(0));
    let alternate_checks = Arc::new(AtomicU64::new(0));
    let client_policy = {
        let denied = denied.clone();
        let denied_checks = denied_checks.clone();
        let alternate_checks = alternate_checks.clone();
        let old = old.clone();
        let alternate = alternate.clone();
        iroh::endpoint::RelayResourcePolicy::new(move |url, usage| {
            if !matches!(usage, iroh::endpoint::RelayResourceUse::DataRelay) { return false; }
            if url == &old {
                if denied.load(Ordering::Relaxed) {
                    denied_checks.fetch_add(1, Ordering::Relaxed);
                    return false;
                }
                return true;
            }
            if url == &alternate {
                alternate_checks.fetch_add(1, Ordering::Relaxed);
                return true;
            }
            false
        })
    };
    let map: iroh::RelayMap = iroh::RelayConfig::from(old.clone()).into();
    let client = Endpoint::builder(presets::Minimal).clear_ip_transports()
        .relay_mode(iroh::RelayMode::Custom(map.clone())).relay_resource_policy(client_policy)
        .alpns(vec![BUSINESS.to_vec()]).bind().await.unwrap();
    let server_old = old.clone();
    let server = Endpoint::builder(presets::Minimal).clear_ip_transports()
        .relay_mode(iroh::RelayMode::Custom(map)).relay_resource_policy(
            iroh::endpoint::RelayResourcePolicy::new(move |url, usage| url == &server_old && matches!(usage, iroh::endpoint::RelayResourceUse::DataRelay)))
        .alpns(vec![BUSINESS.to_vec()]).bind().await.unwrap();
    let (out, incoming) = connect(&client, &server, &old, BUSINESS).await;
    let (mut send, _) = out.open_bi().await.unwrap();
    send.write_all(b"warm the actual authenticated endpoint route").await.unwrap();
    send.finish().unwrap();
    let (_, mut recv) = incoming.accept_bi().await.unwrap();
    assert_eq!(recv.read_to_end(128).await.unwrap(), b"warm the actual authenticated endpoint route");
    out.close(0u32.into(), b"fixture route warm");
    incoming.close(0u32.into(), b"fixture route warm");
    let _ = tokio::join!(out.closed(), incoming.closed());
    tokio::time::sleep(Duration::from_millis(500)).await;
    // This mutable low-level predicate is only a route-injection fixture. The
    // product's ResourceConfig snapshots do not implement a runtime hot update.
    denied.store(true, Ordering::Relaxed);
    let before = old_service.metrics().server.bytes_recv.get();
    let attempted = tokio::time::timeout(Duration::from_secs(2), client.connect(
        EndpointAddr::new(server.id()).with_relay_url(alternate.clone()), BUSINESS)).await;
    assert!(!matches!(attempted, Ok(Ok(_))));
    let after = old_service.metrics().server.bytes_recv.get();
    let new_access = alternate_service.metrics().server.http_connections.get();
    eprintln!("MIO38_ACTOR_ROUTE warm_real_tls=true forbidden_before={before} forbidden_after={after} denied_checks={} candidate_checks={} candidate_http={new_access}", denied_checks.load(Ordering::Relaxed), alternate_checks.load(Ordering::Relaxed));
    client.close().await;
    server.close().await;
    old_service.shutdown().await.unwrap();
    alternate_service.shutdown().await.unwrap();
    assert!(before > 0);
    assert_eq!(after, before, "a warm known actor route must not carry another datagram after denial");
    assert!(denied_checks.load(Ordering::Relaxed) > 0);
    assert!(alternate_checks.load(Ordering::Relaxed) > 0, "the different allowed candidate must reach the actor");
    assert!(new_access > 0, "the allowed candidate is actually dialed instead of the forbidden known route");
}

#[tokio::test]
async fn data_relay_disable_preserves_independently_allowed_address_observation() {
    use iroh::Watcher;
    let (certs, tls) = iroh_relay::server::testing::self_signed_tls_certs_and_config();
    let mut quic = iroh_relay::server::QuicConfig::new((Ipv4Addr::LOCALHOST, 0));
    quic.server_config = Some(tls);
    let mut server_config = ServerConfig::default();
    server_config.quic = Some(quic);
    let service = Server::spawn(server_config).await.unwrap();
    let url: iroh::RelayUrl = "https://127.0.0.1/".parse().unwrap();
    let mut entry = resource(&url);
    entry.uses.insert(ResourceUse::Observation);
    let mut config = ResourceConfig::with_defaults(ResourceTable { revision: 1, resources: vec![entry] });
    config.disabled.insert((url.to_string(), ResourceUse::DataRelay));
    let observers: iroh::RelayMap = iroh::RelayConfig::new(url, Some(iroh_relay::RelayQuicConfig::new(service.quic_addr().unwrap().port()))).into();
    let endpoint = config.configure(Endpoint::builder(presets::Minimal)
        .clear_ip_transports().bind_addr((Ipv4Addr::LOCALHOST, 0)).unwrap()
        .relay_mode(iroh::RelayMode::Custom(iroh::RelayMap::empty()))
        .observation_servers(observers)
        .ca_tls_config(iroh_relay::tls::CaTlsConfig::custom_roots(certs)))
        .unwrap().bind().await.unwrap();
    let mut watch = endpoint.udp_observation();
    let observation = tokio::time::timeout(Duration::from_secs(10), async {
        loop {
            let state = watch.get();
            if state.is_fresh() { break state; }
            watch.updated().await.unwrap();
        }
    }).await.unwrap();
    assert!(endpoint.home_relay_status().get().is_empty());
    let metrics = service.metrics().clone();
    endpoint.close().await;
    service.shutdown().await.unwrap();
    let incoming = metrics.server.qad_incoming.get();
    let connections = metrics.server.qad_connections.get();
    let http = metrics.server.http_connections.get();
    let data = metrics.server.bytes_recv.get();
    eprintln!("MIO38_INDEPENDENT_USE data_relay=disabled observation={observation:?} actual_qad_incoming={incoming} established_qad={connections} relay_http={http} relay_bytes={data}");
    assert!(incoming > 0);
    assert_eq!((http, data), (0, 0));
}

#[tokio::test]
async fn external_mapping_observer_map_cannot_bypass_permission() {
    let (certs, tls) = iroh_relay::server::testing::self_signed_tls_certs_and_config();
    let mut services = Vec::new();
    let mut entries = Vec::new();
    let mut observers = Vec::new();
    for index in 0..3 {
        let mut quic = iroh_relay::server::QuicConfig::new((Ipv4Addr::LOCALHOST, 0));
        quic.server_config = Some(tls.clone());
        let mut server_config = ServerConfig::default();
        server_config.quic = Some(quic);
        let service = Server::spawn(server_config).await.unwrap();
        let url: iroh::RelayUrl = format!("https://127.0.0.1:{}/", 44300 + index).parse().unwrap();
        let mut entry = resource(&url);
        entry.uses = BTreeSet::from([ResourceUse::Observation]);
        entries.push(entry);
        observers.push(iroh::RelayConfig::new(url, Some(iroh_relay::RelayQuicConfig::new(service.quic_addr().unwrap().port()))));
        services.push(service);
    }
    let forbidden_url = observers[0].url.clone();
    let forbidden_destination = services[0].quic_addr().unwrap();
    let mut config = ResourceConfig::with_defaults(ResourceTable { revision: 1, resources: entries });
    config.disabled.insert((forbidden_url.to_string(), ResourceUse::Observation));
    let endpoint = config.configure(Endpoint::builder(presets::Minimal)
        .clear_ip_transports().bind_addr((Ipv4Addr::LOCALHOST, 0)).unwrap()
        .observation_servers(iroh::RelayMap::empty())
        .ca_tls_config(iroh_relay::tls::CaTlsConfig::custom_roots(certs)))
        .unwrap().bind().await.unwrap();
    let bound = endpoint.bound_sockets();
    let mapping = endpoint.observe_udp_mapping_sequence(&iroh::RelayMap::from_iter(observers)).await.unwrap();
    assert_eq!(mapping.samples.len(), 2);
    assert!(mapping.samples.iter().all(|sample| sample.observer != forbidden_url.to_string() && sample.destination != forbidden_destination));
    assert!(mapping.samples.iter().all(|sample| bound.contains(&sample.mapped)));
    assert_eq!(endpoint.bound_sockets(), bound, "observation retains the original real QUIC socket");
    let metrics: Vec<_> = services.iter().map(|service| service.metrics().clone()).collect();
    endpoint.close().await;
    for service in services { service.shutdown().await.unwrap(); }
    let counts: Vec<_> = metrics.iter().map(|metrics| metrics.server.qad_incoming.get()).collect();
    eprintln!("MIO38_MAPPING external_map=3 allowed_samples=2 actual_qad_incoming={counts:?} original_socket={bound:?}");
    assert_eq!(counts[0], 0);
    assert!(counts[1] > 0 && counts[2] > 0);
}

#[tokio::test]
async fn trusted_table_update_preserves_local_replacement_and_disable_on_restart() {
    use miopunch_native_probe::resources::SignedResourceTable;
    use p2panda_core::SigningKey;
    let disabled = relay().await;
    let local = relay().await;
    let new_default = relay().await;
    let disabled_url = disabled.http_url().unwrap();
    let local_url = local.http_url().unwrap();
    let new_url = new_default.http_url().unwrap();
    let publisher = SigningKey::generate();
    let mut config = ResourceConfig::with_defaults(ResourceTable { revision: 1, resources: vec![resource(&disabled_url)] });
    config.trusted_update_key = Some(publisher.verifying_key());
    config.replacement = Some(vec![resource(&local_url), resource(&disabled_url)]);
    config.disabled.insert((disabled_url.to_string(), ResourceUse::DataRelay));
    let table = ResourceTable { revision: 2, resources: vec![resource(&disabled_url), resource(&new_url)] };
    let signed = SignedResourceTable::sign(&publisher, &table).unwrap();
    config.apply_signed_update(&signed).unwrap();
    assert_eq!(config.defaults.revision, 2);
    assert!(config.allows(local_url.as_str(), ResourceUse::DataRelay));
    assert!(!config.allows(disabled_url.as_str(), ResourceUse::DataRelay));
    assert!(!config.allows(new_url.as_str(), ResourceUse::DataRelay));
    let dir = tempfile::tempdir().unwrap();
    let path = dir.path().join("node");
    let node = NativeNetwork::create(&path).await.unwrap();
    node.save_resource_configuration(&config).unwrap();
    node.close().await;
    let node = NativeNetwork::open(&path).await.unwrap();
    assert_eq!(node.resource_configuration().unwrap(), config);
    let endpoint = node.bind_configured_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    tokio::time::timeout(Duration::from_secs(5), endpoint.online()).await.unwrap();
    assert_eq!(endpoint.addr().relay_urls().cloned().collect::<Vec<_>>(), vec![local_url]);
    let actual = [disabled.metrics().clone(), local.metrics().clone(), new_default.metrics().clone()];
    endpoint.close().await;
    node.close().await;
    disabled.shutdown().await.unwrap();
    local.shutdown().await.unwrap();
    new_default.shutdown().await.unwrap();
    let accesses: Vec<_> = actual.iter().map(|metrics| metrics.server.http_connections.get()).collect();
    eprintln!("MIO38_UPDATE signature=verified revision=2 restarted=true http_connections_disabled_local_newdefault={accesses:?}");
    assert_eq!(accesses[0], 0);
    assert!(accesses[1] > 0);
    assert_eq!(accesses[2], 0);
}

#[tokio::test]
async fn equivalent_url_spelling_cannot_bypass_a_local_disable() {
    let service = relay().await;
    let url = service.http_url().unwrap();
    let mut config = ResourceConfig::with_defaults(ResourceTable { revision: 1, resources: vec![resource(&url)] });
    config.disabled.insert((url.as_str().trim_end_matches('/').to_owned(), ResourceUse::DataRelay));
    let dir = tempfile::tempdir().unwrap();
    let node = NativeNetwork::create(dir.path().join("node")).await.unwrap();
    node.save_resource_configuration(&config).unwrap();
    let endpoint = node.bind_configured_endpoint(Ipv4Addr::LOCALHOST).await.unwrap();
    tokio::time::sleep(Duration::from_millis(250)).await;
    let metrics = service.metrics().clone();
    endpoint.close().await;
    node.close().await;
    service.shutdown().await.unwrap();
    let connections = metrics.server.http_connections.get();
    eprintln!("MIO38_URL_ALIAS disabled_without_slash=true actual_http_connections={connections}");
    assert_eq!(connections, 0);
}

#[test]
fn an_update_signed_by_an_untrusted_publisher_cannot_change_configuration() {
    use miopunch_native_probe::resources::SignedResourceTable;
    use p2panda_core::SigningKey;
    let publisher = SigningKey::generate();
    let stranger = SigningKey::generate();
    let mut config = ResourceConfig::default();
    config.trusted_update_key = Some(publisher.verifying_key());
    config.disabled_uses.insert(ResourceUse::DataRelay);
    let before = config.clone();
    let proposed = ResourceTable { revision: 2, resources: vec![] };
    let forged = SignedResourceTable::sign(&stranger, &proposed).unwrap();
    assert_eq!(config.apply_signed_update(&forged).unwrap_err().kind(), std::io::ErrorKind::PermissionDenied);
    assert_eq!(config, before);
}

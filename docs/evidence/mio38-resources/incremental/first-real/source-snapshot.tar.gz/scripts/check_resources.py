#!/usr/bin/env python3
"""Source-fixed resource verification; preserve every real command exit."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    sources = sorted({path.relative_to(ROOT).as_posix() for prefix in ["src", "tests", "browser-probe/src", "vendor/iroh/src", "vendor/p2panda-net/src"] for path in (ROOT / prefix).rglob("*.rs")})
    sources += ["Cargo.toml", "Cargo.lock", "scripts/check_resources.py"]
    hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in sources}
    (output / "prestart-source-sha256.json").write_text(json.dumps(hashes, indent=2) + "\n")
    with tarfile.open(output / "source-snapshot.tar.gz", "w:gz") as archive:
        for name in sources:
            archive.add(ROOT / name, arcname=name)
    command = args.command or ["cargo", "test", "--locked", "--test", "resources", "--", "--test-threads=1", "--nocapture"]
    if command[0] == "--":
        command = command[1:]
    receipt = {"started_utc": datetime.now(timezone.utc).isoformat(), "argv": ["rtk", "proxy", *command], "source_sha256": hashes}
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    with (output / "command.log").open("w") as log:
        result = subprocess.run(receipt["argv"], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    receipt.update(exit_code=result.returncode, finished_utc=datetime.now(timezone.utc).isoformat(), source_unchanged=all(hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == value for name, value in hashes.items()))
    (output / "command-exit.json").write_text(json.dumps(receipt, indent=2) + "\n")
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in ["exit_code", "source_unchanged"]}), flush=True)
    return result.returncode if receipt["source_unchanged"] else 2


if __name__ == "__main__":
    raise SystemExit(main())

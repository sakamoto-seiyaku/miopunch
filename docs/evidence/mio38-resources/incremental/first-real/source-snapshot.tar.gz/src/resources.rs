//! Startup resource configuration. Candidate provenance never grants permission.

use std::collections::BTreeSet;
use std::path::Path;
use std::time::Duration;

use iroh::{RelayConfig, RelayMap, RelayUrl};
use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Serialize, Deserialize)]
pub enum ResourceUse {
    Observation,
    Lookup,
    Signaling,
    DataRelay,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct Resource {
    pub url: String,
    pub uses: BTreeSet<ResourceUse>,
    pub limitation: String,
}

/// Disabled preserves the current native assembly's absence of LAN publication.
/// Passive listens only; Active explicitly publishes this node's identity/address.
#[derive(Clone, Copy, Debug, Default, Eq, PartialEq, Serialize, Deserialize)]
pub enum LanDiscovery {
    #[default]
    Disabled,
    Passive,
    Active,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ResourceTable {
    pub revision: u64,
    pub resources: Vec<Resource>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct ResourceConfig {
    pub defaults: ResourceTable,
    /// None uses defaults; Some (including empty) replaces them entirely.
    pub replacement: Option<Vec<Resource>>,
    pub disabled: BTreeSet<(String, ResourceUse)>,
    pub disabled_uses: BTreeSet<ResourceUse>,
    pub lan_discovery: LanDiscovery,
}

impl Default for ResourceConfig {
    fn default() -> Self {
        Self::with_defaults(ResourceTable {
            revision: 1,
            resources: iroh::defaults::prod::default_relay_map()
                .urls()
                .map(|url| Resource {
                    url: url.to_string(),
                    uses: BTreeSet::from([ResourceUse::Observation, ResourceUse::DataRelay]),
                    limitation: "number0 public relay: best effort, no availability guarantee; QAD and end-to-end encrypted relay, not membership authority".into(),
                })
                .collect(),
        })
    }
}

impl ResourceConfig {
    pub fn with_defaults(defaults: ResourceTable) -> Self {
        Self {
            defaults,
            replacement: None,
            disabled: BTreeSet::new(),
            disabled_uses: BTreeSet::new(),
            lan_discovery: LanDiscovery::Disabled,
        }
    }

    pub fn allows(&self, url: &str, usage: ResourceUse) -> bool {
        !self.disabled_uses.contains(&usage)
            && !self.disabled.contains(&(url.to_owned(), usage))
            && self
                .replacement
                .as_ref()
                .unwrap_or(&self.defaults.resources)
                .iter()
                .any(|resource| resource.url == url && resource.uses.contains(&usage))
    }

    pub fn relay_map(&self, usage: ResourceUse) -> Result<RelayMap, std::io::Error> {
        self.replacement
            .as_ref()
            .unwrap_or(&self.defaults.resources)
            .iter()
            .filter(|resource| self.allows(&resource.url, usage))
            .map(|resource| {
                resource.url.parse::<RelayUrl>().map(RelayConfig::from).map_err(|err| {
                    std::io::Error::new(std::io::ErrorKind::InvalidInput, err)
                })
            })
            .collect::<Result<Vec<_>, _>>()
            .map(RelayMap::from_iter)
    }

    /// A trusted client-release table update; never consumes an untrusted lookup
    /// response. Local replacement and disables remain separate from the table.
    pub fn update_release_table(&mut self, table: ResourceTable) -> Result<(), std::io::Error> {
        if table.revision <= self.defaults.revision {
            return Err(std::io::Error::new(std::io::ErrorKind::InvalidInput, "resource table rollback"));
        }
        self.defaults = table;
        Ok(())
    }

    pub fn load(path: &Path) -> Result<Self, std::io::Error> {
        match std::fs::read(path) {
            Ok(bytes) => serde_json::from_slice(&bytes).map_err(std::io::Error::other),
            Err(err) if err.kind() == std::io::ErrorKind::NotFound => Ok(Self::default()),
            Err(err) => Err(err),
        }
    }

    pub fn configure(&self, builder: iroh::endpoint::Builder) -> Result<iroh::endpoint::Builder, std::io::Error> {
        let config = self.clone();
        Ok(builder.relay_resource_policy(iroh::endpoint::RelayResourcePolicy::new(move |url, usage| {
            config.allows(url.as_str(), match usage {
                iroh::endpoint::RelayResourceUse::DataRelay => ResourceUse::DataRelay,
                iroh::endpoint::RelayResourceUse::Observation => ResourceUse::Observation,
            })
        })))
    }
}

/// Failure concerns reachable paths, never proof that all members are offline.
#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ContactState {
    Ready,
    TemporarilyUnreachable { retry_after: Duration },
}

#[derive(Default)]
pub struct ContactBackoff {
    failures: u32,
}

impl ContactBackoff {
    pub fn failed(&mut self) -> ContactState {
        let seconds = 1u64 << self.failures.min(5);
        self.failures = self.failures.saturating_add(1);
        ContactState::TemporarilyUnreachable { retry_after: Duration::from_secs(seconds) }
    }

    pub fn new_configuration(&mut self) {
        self.failures = 0;
    }
}
